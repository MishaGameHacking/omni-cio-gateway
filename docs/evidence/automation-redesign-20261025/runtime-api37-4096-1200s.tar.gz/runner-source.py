#!/usr/bin/env python3
"""One disposable API37/4K diagnostic leaf; never a publication authorization."""
from __future__ import annotations
import datetime, fcntl, hashlib, importlib.util, json, os, pathlib, pwd, re
import signal, subprocess, sys, time, traceback
import xml.etree.ElementTree as ET

ROOT=pathlib.Path("/srv/analyst-ai/workspace"); STATE=pathlib.Path("/var/lib/analyst-ai-build")
PUBLIC37="1c91b77a8c86453b60ff2340723f3280f64b6e34769ecc984b4663499bb9aa74"
HARNESS="926140ca9b46abf140f3f5dbbcac04fc43aab2b83ac406c87d6bd97705ef323e"
def require(condition, message):
    if not condition: raise RuntimeError(message)
require(len(sys.argv)==3 and re.fullmatch(r"[0-9a-f]{64}",sys.argv[1]),"source_hash_and_unit_required")
EXPECTED,UNIT=sys.argv[1:]
require(re.fullmatch(r"analyst-ai-runtime-leaf-4k(?:-[A-Za-z0-9_.-]+)?\.service",UNIT),"dedicated_leaf_unit_required")
require(os.geteuid()==pwd.getpwnam("analyst-build").pw_uid,"analyst_build_user_required")
relative=next((line[3:] for line in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::")),None)
require(relative=="/system.slice/"+UNIT,"dedicated_leaf_cgroup_required")
CG=pathlib.Path("/sys/fs/cgroup")/relative.lstrip("/")
require(hasattr(os,"pidfd_open") and hasattr(signal,"pidfd_send_signal"),"pidfd_cleanup_required")
def members():
    return {int(value) for path in CG.rglob("cgroup.procs") for value in path.read_text().split()}
retained=members(); require(os.getpid() in retained,"own_cgroup_membership_required")
def cleanup(process):
    for sig,seconds in ((signal.SIGTERM,8),(signal.SIGKILL,4)):
        for pid in members()-retained:
            fd=None
            try:
                fd=os.pidfd_open(pid)
                groups=pathlib.Path("/proc/"+str(pid)+"/cgroup").read_text().splitlines()
                if any(line=="0::"+relative or line.startswith("0::"+relative+"/") for line in groups):
                    signal.pidfd_send_signal(fd,sig)
            except (ProcessLookupError,FileNotFoundError): pass
            finally:
                if fd is not None: os.close(fd)
        deadline=time.monotonic()+seconds
        while members()-retained and time.monotonic()<deadline:
            if process is not None: process.poll()
            time.sleep(.2)
        if not members()-retained: break
    if process is not None: process.wait(timeout=5)
    return len(members()-retained)
def interrupted(signum, frame): raise InterruptedError("leaf_unit_interrupted")
signal.signal(signal.SIGTERM,interrupted); signal.signal(signal.SIGINT,interrupted)
path=ROOT/"deploy/timeweb_workspace.py"; code=path.read_bytes().replace(b"\r\n",b"\n")
require(hashlib.sha1(b"blob "+str(len(code)).encode()+b"\0"+code).hexdigest()=="8693065a2f67987ef58c64c3436749dd8b946996","workspace_guards_changed")
spec=importlib.util.spec_from_file_location("tracked_workspace",path); ws=importlib.util.module_from_spec(spec); spec.loader.exec_module(ws)
folder=STATE/"runs"/(datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")+"-runtime-leaf-4k")
folder.mkdir(parents=True,exist_ok=False); report_path=folder/"leaf-result.json"; work=folder/"install-api37-4096"
report={"stage":"runtime-leaf","status":"running","publication_authorized":False,"source_sha256":EXPECTED,
        "android_api":37,"page_size_bytes":4096,"boot_timeout_seconds":1200,"attempts":1,
        "subprocess_timeout_seconds":7200,"unit":UNIT,"started_at":ws.stamp(),"log_directory":str(folder)}
process=None; frozen=None
lock=(STATE/"workspace.lock").open("a")
try:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    ws.require_capacity("runtime"); require(ws.source_hash()==EXPECTED,"sources_do_not_match_requested_hash")
    ws.previous("check",EXPECTED); build=ws.previous("build",EXPECTED)
    harness=ROOT/".github/scripts/test_apk_installation.py"
    require(ws.sha(harness)==HARNESS,"tracked_boot_budget_harness_changed")
    apk=ROOT/"app/build/outputs/apk/preview/app-preview.apk"; verification=apk.with_name("apk-verification.json")
    fixture=ROOT/"app/build/outputs/apk/debug/app-debug.apk"
    require(not apk.is_symlink() and not verification.is_symlink() and not fixture.is_symlink(),"apk_path_must_be_regular")
    candidate=json.loads(verification.read_text()); digest=ws.sha(apk)
    require(build.get("apk_sha256")==digest and build.get("apk")==str(apk),"apk_changed_since_current_build")
    require(type(candidate.get("version_code")) is int and candidate["version_code"]==38,"candidate38_required")
    old,baseline=ws.resolve_upgrade_baseline(candidate,digest)
    require(baseline=={"package_name":ws.PREVIEW_PACKAGE,"version_code":37,"apk_sha256":PUBLIC37,"certificate_sha256":ws.CERT},"public37_baseline_changed")
    manifest=ws.public_release_directory()/"current.json"
    sys.path.insert(0,str(ROOT/".github/scripts")); sys.path.insert(0,str(ROOT))
    from kernel_page_size import system_image
    from installation_report import validate_results
    from automation_artifacts import verify_automation_artifacts
    image=system_image(37,4096); image_metadata=ws.SDK.joinpath(*image.split(";"))/"package.xml"
    require(any(element.tag.rsplit("}",1)[-1]=="localPackage" and element.get("path")==image
                for element in ET.parse(image_metadata).iter()),"installed_4k_image_identity_mismatch")
    frozen={"apk":digest,"verification":ws.sha(verification),"fixture":ws.sha(fixture),
            "public_apk":ws.sha(old),"public_manifest":ws.sha(manifest),"image_metadata":ws.sha(image_metadata)}
    require(frozen["public_apk"]==baseline["apk_sha256"],"public_upgrade_apk_changed")
    lavapipe=list(pathlib.Path("/usr/share/vulkan/icd.d").glob("lvp_icd*.json"))
    require(len(lavapipe)==1,"lavapipe_not_installed")
    env=dict(os.environ); env.update({"ANDROID_HOME":str(ws.SDK),"ANDROID_SDK_ROOT":str(ws.SDK),
        "GRADLE_USER_HOME":"/var/cache/analyst-ai/gradle","JAVA_HOME":"/usr/lib/jvm/java-17-openjdk-amd64",
        "TELEGRAM_CLIENT_ID":"123456","TELEGRAM_CLIENT_SECRET":"test-only","BACKEND_PUBLIC_URL":"https://example.invalid",
        "FERNET_KEY":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=","ANALYSIS_SCHEDULER_ENABLED":"false",
        "AI_EXTERNAL_PROCESSING_APPROVED":"false","DATABASE_PATH":str(folder/"tests.sqlite3"),"PYTHONUNBUFFERED":"1",
        "RUN_PROFILE_UI_TESTS":"1","VK_ICD_FILENAMES":str(lavapipe[0])})
    command=["xvfb-run","-a",str(ws.PY),str(harness),"--sdk",str(ws.SDK),"--apk",str(apk),"--previous",str(old),
             "--api","37","--page-bytes","4096","--work-dir",str(work),"--boot-timeout-seconds","1200","--attempts","1"]
    report.update(command=command,upgrade_baseline=baseline,candidate_version_code=38,frozen_hashes=frozen,
                  system_image=image,lavapipe_icd=str(lavapipe[0]),harness_sha256=HARNESS)
    ws.write(report_path,report)
    with (folder/"preflight.log").open("w") as log:
        subprocess.run(["git","diff","--check"],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60,check=True)
    with (folder/"runtime.log").open("w") as log,(folder/"resources.jsonl").open("w") as samples:
        process=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        deadline=time.monotonic()+7200
        while True:
            sample={"at":ws.stamp()}
            try:
                sample.update({name:(CG/name).read_text().strip() for name in (
                    "memory.current","memory.peak","memory.swap.current","memory.events","memory.high","memory.max","memory.swap.max","cpu.stat")
                    if (CG/name).is_file()})
            except OSError as error: sample["error_type"]=type(error).__name__
            samples.write(json.dumps(sample,sort_keys=True)+"\n"); samples.flush()
            remaining=deadline-time.monotonic()
            if remaining<=0: raise TimeoutError("leaf_subprocess_deadline_exceeded")
            try: report["exit_code"]=process.wait(timeout=min(30,remaining))
            except subprocess.TimeoutExpired: continue
            require(time.monotonic()<=deadline,"leaf_subprocess_deadline_exceeded")
            break
    require(report["exit_code"]==0,"tracked_installation_leaf_failed")
    results_path=work/"install-results.json"; require(results_path.is_file() and not results_path.is_symlink(),"real_install_results_required")
    rows=json.loads(results_path.read_text())
    validate_results(rows,upgrade_required=True,profile_required=True,android_api=37,page_size_bytes=4096,candidate_version_code=38)
    ws.require_upgrade_baseline_transcript(results_path,baseline)
    candidate_tests={"candidate_clean_install","bootstrap_activity_launch","upgrade_to_candidate","upgrade_bootstrap_launch","kernel_page_size"}
    require(all(row.get("apk_sha256")==digest for row in rows if row["test"] in candidate_tests),"candidate_runtime_digest_mismatch")
    require(next(row for row in rows if row["test"]=="debug_ui_fixture_install")["apk_sha256"]==frozen["fixture"],"ui_fixture_digest_mismatch")
    ui=next(row for row in rows if row["test"]=="profile_ui"); archive=work/ui["automation_artifact_directory"]
    require(not archive.is_symlink() and archive.resolve(strict=True).is_relative_to(work.resolve(strict=True)),"automation_archive_escapes_leaf")
    verify_automation_artifacts(ui["automation_report"],archive)
    report["status"]="leaf_passed"
except BaseException as error:
    report.update(status="blocked" if str(error).startswith("insufficient_") else "failed",error_type=type(error).__name__,error=str(error)[:1000])
    (folder/"failure.log").write_text(traceback.format_exc())
finally:
    try:
        report["remaining_owned_processes"]=cleanup(process)
        require(report["remaining_owned_processes"]==0,"owned_process_cleanup_incomplete")
    except BaseException as error:
        report["cleanup_error_type"]=type(error).__name__; report["status"]="failed"
    try:
        report["source_sha256_after"]=ws.source_hash()
        require(report["source_sha256_after"]==EXPECTED,"sources_changed_during_leaf")
        if frozen is not None:
            after={"apk":ws.sha(apk),"verification":ws.sha(verification),"fixture":ws.sha(fixture),
                   "public_apk":ws.sha(old),"public_manifest":ws.sha(manifest),"image_metadata":ws.sha(image_metadata)}
            report["hashes_after"]=after; require(after==frozen,"frozen_inputs_changed_during_leaf")
            _,current=ws.resolve_upgrade_baseline(candidate,digest); require(current==baseline,"public_upgrade_baseline_changed_during_leaf")
    except BaseException as error:
        report["final_guard_error"]=str(error)[:1000]; report["status"]="failed"
    for label,p in (("install_results",work/"install-results.json"),("attempt_install_results",work/"attempt-1/install-results.json"),
                    ("boot_observation",work/"attempt-1/boot-observation.json")):
        if p.is_file() and not p.is_symlink():
            try: report[label]={"path":str(p),"sha256":ws.sha(p),"data":json.loads(p.read_text())}
            except (OSError,ValueError) as error: report[label]={"path":str(p),"error_type":type(error).__name__}
    report["finished_at"]=ws.stamp(); ws.write(report_path,report); lock.close()
    print("RUNTIME_LEAF_RESULT="+json.dumps({"status":report["status"],"report":str(report_path),"publication_authorized":False}),flush=True)
raise SystemExit(0 if report["status"]=="leaf_passed" else 1)
