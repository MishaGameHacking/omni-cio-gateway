# UX47: bounded source proposal и владение файлами

Статус: направление и источники данных одобрены root 26 октября 2026; исходники готовятся только в scratch. Фактический применяемый base будет успешной сохранённой версией 46, с проверкой old SHA всех изменяемых файлов. Frozen46 overlays, действующий репозиторий, backend policies и зависимости не изменяются этой подготовкой.

## Мой production scope

| Файл / группа | Конкретная перемена | Сохраняемый контракт |
|---|---|---|
| `MainActivity.kt` | Человеческие названия из catalog; один source-bound запрос навигации для исходящих переходов; различение главного назначения и контекстного открытия объекта; точная auth error ветка от quote | AppScreen names, encrypted schema, user isolation, AuthTab/session/nonce, реальный context ID |
| `ui/AnalystNavigationPanels.kt` | Общий каталог вторичных задач; guard доступен всем действующим WorkspaceRoute; одноразовое продолжение; одинаковая достижимость phone/wide | DrawerState predictive Back, закрытие перед переходом, текущий source route, stable content slot, no swipe stealing |
| `ui/AnalystBottomBar.kt` | Три понятных подписанных назначения; меню отдельным действием; адаптация без скрытия названий | Три serialized roots, native selected state, минимум 48dp, системные insets |
| `ui/workspace/WorkspaceNavigation.kt` и новый `WorkspacePageCatalog.kt` | Метаданные названия/назначения/раздела; адаптеры для существующих route IDs | Enum IDs и readback/history не переименовываются |
| `ui/workspace/WorkspaceUi.kt` | Единая лаконичная иерархия заголовка/Back/Menu, доступный реальный action; существующие локальные заголовки не подменяются чужим родителем | Один владелец композиции; safe viewport/IME; конкретная страница владеет своим действием |
| `ui/home/HomeScreen.kt` + новый `HomeSystemControls.kt` | Перенос фактического automation controller с ack/409 на Home; рабочие входы Strategy/AnalysisProfile/Timeline; контекстные blocker actions | Тот же PUT и expected_version, тот же status GET/poll; анализ не равен торговле |
| Новый `ui/home/HomeFinancialOverview.kt` | Маленькая проекция уже сохранённого `/workspace`: капитал, actual period/flows, разделённые выплаты | Никакого нового broker/model запроса; null/partial/currency/as_of/source сохранены; не называть residual чистой прибылью |
| `ui/profile/ProfileScreen.kt` | Удаление перемещённых команд, ясные группы приложения/доступа, точное «Недавно открыто» | Приватность/appearance/OS prefs, logout confirmation, session/broker access |
| `ui/analysis/AnalysisScreens.kt` | Регистрация existing draft в общем exit guard; pending save не покидается/не отменяется молча; объяснение действующей стратегии | Исходные fields/GET/PUT, active-strategy 409, ack, прежние numeric values |
| `ui/workspace/NotificationWorkspaceScreens.kt` | Несохранённый delivery draft получает тот же source-bound leave policy | expected_version, 409, сохранённый ack и OS permission отдельно |

На точной проверке кодовых зависимостей список может получить только необходимые узкие call-site/metadata adapters; расширение на новые функции сначала сообщается root. Ни инструментальные графики, ни поля стратегии, ни frozen46 theme/pixel/lifecycle files не переписываются этой задачей без отдельного основания.

## Общие API и границы между авторами

- **Navigation owner:** plan_audit. Сохраняются `AnalystNavigationPanels` и `RegisterPanelExit(route, request)`. Уход из редактора принимает continuation; открытие меню само по себе не запускает guard. Дополнительные глобальные ссылки проходят тот же source-bound path, без двойного подтверждения и без выполнения устаревшей continuation.
- **MainActivity auth delta:** quote передаёт точный небольшой diff; весь MainActivity изменяет plan_audit. Подтверждённый текст для `owner_access_denied`: «Эта установка Analyst AI доступна только её владельцу. Войдите через Telegram-аккаунт владельца.» Никакой новой browser-busy сигнатуры сейчас не требуется.
- **Auth slice:** quote — `TelegramLoginScreen.kt`, auth HTML в `telegram_browser_app.py`, `app.py`, `owner_app.py`. Он сохраняет frozen46 цвета, CSP/nonce/redirect/session/policy и существующий `TelegramLoginScreen` API.
- **Progress/update slice:** ci_investigation — backward-compatible `SpectrumLoadingIndicator`/`SpectrumProgressBar`, реальные update phases и их renderer/driver проверки. Home и jobs не передают численный progress там, где backend его не сообщает.
- **Palette:** только опубликованные/проверенные роли46; новых цветов и layout golden вне реального Windows результата не вводится.
- **Native adapters:** отдельный source patch и manifest. Они изменяют только маршрут достижения перемещённого контрола/его ясное название, сохраняя owner/bounds/48dp, assertions о mutation/ack/version/foreground/Back и количество кейсов.

## Конечный набор функциональных доказательств

1. **Финансовая проекция**: available exact currency/amount; partial с неизвестными суммами; unavailable без подстановки нулей; actual period отличается от requested; received отдельно от announced/expected; private amounts скрываются и в семантике. Fixture использует реальную production projection, а не дублирующую тестовую формулу.
2. **Серверное управление на Home**: исходный enabled, PUT expected version, pending/ack, 409/readback, transport error и повтор без лишней mutation. Существующий набор automation26 остаётся тем же; исторический `settings` case теперь реально открывает Home перед операцией.
3. **Защита draft**: actual AnalysisProfile/Notification editor request exit; cancel сохраняет выбранные значения, discard выполняет только исходное однократное назначение; callback от прежнего route или disposed binding не навигирует; pending save не теряется. Strategy и Appearance retain свои прежние cases.
4. **Навигация**: три подписи видимы при font100/200; выбранное назначение соответствует источнику; drawer и rail доступны; одного открытия/закрытия меню недостаточно для изменения prefs; Back/cancel ведут в фактический контекст; list/detail offsets остаются независимыми.
5. **Общий runtime gate**: прежние original15/automation26/native safety bounds, обе page sizes, source/APK/driver provenance и очистка lease остаются обязательными. Новая UX-проверка не заменяет их.

Количество дополнительных native cases будет зафиксировано после завершения конкретных компонентов, до Windows запуска. Цель — проверять реальные переходы и записи, а не размножать screenshots одной реализации. Нельзя считать compiler/host pass подтверждением телефонной геометрии.

## Следующие обязательства, которые этим узким patch не объявляются выполненными

Все числовые настройки без клавиатуры остаются исходным требованием. Для Strategy/Goals нужны точные step/preset controls с сохранением дробного старого значения, для времени — picker, для timezone — настоящий выбор из допустимых зон. UI-замена должна идти вместе с finite native доказательством значений/preview/409 и отдельно согласованным file scope. Дополнительные новые mandate, budget и executor API относятся к будущим этапам бизнес-плана. Нельзя скрывать незакрытую задачу новым названием экрана или выдавать будущую функцию за рабочую.
