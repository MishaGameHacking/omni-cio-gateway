package ru.omnicio.app.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import ru.omnicio.app.ui.spatial.SpatialIcon
import ru.omnicio.app.ui.spectrum.*
import ru.omnicio.app.ui.theme.LocalSpectrumMotionPreference

@Composable
fun TelegramLoginScreen(loading: Boolean, errorMessage: String?, onLoginClick: () -> Unit,
    modifier: Modifier = Modifier, loadingLabel: String = "Проверяем сохранённый сеанс…") {
    SpectrumBackground(modifier.fillMaxSize()) {
        Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets.safeDrawing) { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding),
                contentAlignment = Alignment.TopCenter,
            ) {
                Column(
                    Modifier.widthIn(max = 560.dp).fillMaxWidth().fillMaxHeight()
                        .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    horizontalAlignment = Alignment.Start,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        SpatialIcon("brand", Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.primary, motionAllowed = false)
                        Text("Analyst AI", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (loading) "Открываем Analyst AI" else "Вход в Analyst AI",
                            style = MaterialTheme.typography.headlineLarge,
                            modifier = Modifier.semantics { heading() })
                        Text(if (loading) "Проверяем доступ к вашему рабочему пространству."
                            else "Подтвердите свой Telegram-аккаунт, чтобы открыть личное рабочее пространство.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    SpectrumCard {
                        errorMessage?.let {
                            Text(it, style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                        }
                        if (loading) {
                            Row(
                                Modifier.semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Polite },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                SpectrumLoadingIndicator(description = loadingLabel,
                                    motionAllowed = LocalSpectrumMotionPreference.current.enabled)
                                Text(loadingLabel, Modifier.weight(1f).clearAndSetSemantics {},
                                    style = MaterialTheme.typography.bodyLarge)
                            }
                        } else {
                            SpectrumPrimaryButton("Войти через Telegram", onLoginClick, Modifier.fillMaxWidth())
                            Text("Откроется защищённое окно Telegram. Подтвердите аккаунт и вернитесь в Analyst AI.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (!loading) {
                        Text("Пароль Telegram остаётся в Telegram.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
