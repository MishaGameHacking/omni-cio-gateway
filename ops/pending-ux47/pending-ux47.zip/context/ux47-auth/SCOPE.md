# UX47 auth — proposed narrow scope

Read-only preparation, 2026-10-26. Root approval of this exact source slice is
pending. Frozen46, runtime46 deployment, actual application and tests have not
been changed or executed. Parent owns final assembly and Windows execution.

## Four owned production files

| Path | Proposed presentation change | Preserved authority |
| --- | --- | --- |
| `app/src/main/java/ru/omnicio/app/ui/auth/TelegramLoginScreen.kt` | Clear app/login purpose, short next step, one Telegram CTA, explicit error/status grouping, shared loading indicator with real `loadingLabel`, scrollable bounded content and wrapping text atfont200 | Existing loading/error/onLogin API; no invented auth status or progress percentage |
| `backend/telegram_browser_app.py` (`_login_page` only) | SDK/waiting/server-confirmation/return/error presentation, effective hidden fallback, responsive text and growing controls; fresh trusted start link after uncertain POST result | Existing nonce, state, ID-token payload, origin, verifier, transaction consumption, session endpoints and response headers |
| `backend/app.py` (`mobile_login_result` only) | Distinct confirmed-Telegram versus incomplete-login heading, clear return CTA/manual fallback, responsive text | Exact escaped one-time/error deep link, automatic `location.replace`, response code, CSP and cache/referrer policy |
| `backend/owner_app.py` (`DENIAL_STYLE`, `_denial` HTML only) | Clear owner denial heading and return action, responsive text; recalculate exact static style hash | Unchanged MESSAGE/JSON403 body, DENIED code, owner policy, link, no scripts, exact hashed-style CSP |

All colors continue to use frozen46 Material/CSS role tokens. CI owns the
shared loading/progress implementation and update/help UI. This slice adds
no color constants or independent loading animation system.

## Concrete seams found in existing source

- Browser login assigns `display:flex` to every anchor, including the initially
  `hidden` open-app fallback. Add an explicit hidden rule so presentation
  cannot reveal an unactionable auth URI before a real result arrives.
- After a POST/transport error, the old button is re-enabled even though the
  one-use state may already have been consumed. A visible trusted start link
  creates a fresh transaction through the existing route; it must not replay
  or regenerate credentials in client code.
- Android handles unknown deep-link errors generically, including the real
  backend `owner_access_denied`. A narrow text mapping belongs to parent/
  plan_audit's MainActivity overlay; it does not require a new auth API.
- Current mobile return/owner-denial pages lack a precise status heading.
  "Telegram подтверждён" accurately precedes Android session exchange;
  a web callback must not claim the application session already exists.

These are source findings and proposed remedies, not claims of a completed
browser/native rendering test.

## Shared MainActivity delta

Plan_audit owns the file and will combine the exact approved case with its
navigation changes. Suggested existing-code mapping:

```kotlin
"owner_access_denied" ->
    "Эта установка Analyst AI доступна только её владельцу. Войдите через Telegram-аккаунт владельца."
```

No changes to AuthTabIntent, redirect deduplication, code/error capture,
session restoration/exchange, serialized routes or navigation guards.

## Verification boundary for a later approved patch

- Preserve and rerun existing backend auth, owner and frozen46 color/header
  tests on Windows. New HTML assertions must call the actual page functions.
- Add focused behavioral frontend checks over the actual emitted inline JS
  using the existing Windows Node runtime and a simulated transport/DOM. No
  Telegram requests, real nonce/token, live login or user session is needed.
  Cover hidden fallback, one outstanding submission, recoverable cancellation,
  fresh retry after uncertain POST, valid return, rejection of invalid deep link
  and exact nonce/header/body retention. Do not test only marker strings.
- Browser layout at narrow width and200% text still needs actual browser proof
  on Windows; static CSS assertions do not prove geometry.
- A finite synthetic Android AuthUiProbe/route can exercise the unchanged real
  component in ready/restore/exchange/error/owner-denied states atfont1/2. Add it
  only after parent agrees the shared native47 fixture/router scope. It cannot
  claim actual Telegram authentication or alter original15 stage IDs.

## Primary references

- [Telegram Login JS API](https://core.telegram.org/bots/telegram-login): the existing auth/init callback and nonce model, profile scope and required popup-compatible COOP.
- [HTML rendering standard](https://html.spec.whatwg.org/multipage/rendering.html): author styles may override hidden rendering.
- Frozen46 production HTML is under `context/theme46-assets/source/backend/`.
- Android auth component currently matches actual44 source inventory and was
  not replaced by candidate45 or frozen46; its theme roles resolve through46.
