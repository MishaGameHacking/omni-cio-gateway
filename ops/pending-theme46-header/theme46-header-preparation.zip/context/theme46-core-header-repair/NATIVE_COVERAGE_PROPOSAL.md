# Theme46 native colors: finite prepared acceptance

Status: source prepared; no application, compiler, host test or native test has run in this environment. All execution remains on the owner's Windows laptop. This is an additional gate required after the combined46 build, not a native result or N00 acceptance.

## Exact matrix: 52 captured frames

LIGHT/DARK × AURORA/OCEAN/IRIS × font100/font200 × four groups yields 48 PNG/XML pairs. Four further real-calendar cases use AURORA in both modes at both font scales: **52 pairs total**. `coverage-matrix.json` enumerates every identity. Snapshot begin/restore launches take no screenshots. Missing, duplicate and failed frames cannot count as success.

| Group | Actual production components/actions | What the pixels establish |
|---|---|---|
| Actions, 12 | Primary, secondary and text buttons; native SpectrumSwitch and custom SpatialToggleVisual checked/unchecked/disabled; choice and tabs. Real taps change state. Android DOWN holds the primary; UP must increment its counter. | Primary glyph/pressed fill inside its actual native content rectangle; disabled ink/fill; choice/tab pairs; thumb/track centers. White page corners cannot supply white glyphs. |
| Fields, 12 | Real SpectrumTextField with harmless ТЕМА, readonly error and disabled fields; semantic success/warning/error/info badges; enabled/disabled slider. Android selects all four characters and hides the IME while retaining selection. | Selected text/background, field outline/base fill, badge pairs and slider inks. The receipt does not claim cursor or selection-handle visibility from a palette marker. |
| Canvas, 12 | SpatialBars with negative, zero, missing and three positive values; real selection of observation 4; six-sector SpatialRing; functional monochrome and enabled/disabled decorative brand artwork. | Every actual bar's single-series/signed role, missing-data axis, two selection edges, six sector centers, and absence of saturated support color in disabled art. |
| Overlay, 12 | Actual Material drawer, wide rail or Spectrum dialog. Each variant has four frames covering both modes/scales, accents balanced. Drawer select/close/reopen, rail select and native separate-window dialog open/close are real actions. | Only the visible variant's selected/unselected or body/primary pairs. A bottom bar exists in the narrow fixture, but obscured/hidden bottom-bar pixels are not claimed. |
| Calendar, 4 | Real PeriodControls opens production DateRangePicker with a past synthetic period; bounded native scrolling exposes selected and disabled dates; real Cancel returns to the initial window without changing the period. | Complete native date labels, selected/enabled state, owned scroll ancestry and fully visible 48 dp day cells bind central selected/disabled pixels. No claim covers offscreen dates, range interiors, year/input mode or a date-selection tap. |

Only the four rail frames use the existing owned-emulator viewport helper at 960×1600 / 160 dpi; actual original viewport and font settings are read back and restored. Other frames keep the existing portrait phone viewport. There is no forced Compose-wide flag, reduced font, relaxed target size or test-only enlargement of the production picker.

## Provenance and failure behavior

`exercise_theme_states(probe, admitted)` requires the active FrameReader/current PID's canonical emulator lease, API37 and page size 4096 or 16384. Its five admitted build fields are source_inventory_sha256, debug_apk_sha256, driver_apk_sha256, version_code and version_name, supplied from the successful exact-source build receipt. It reads back actual installed debug/driver APK hashes and app version before mutations.

Each frame observes 74 live values: 48 Material roles, 19 semantic roles, 6 series and the actual pressed-primary color. Effective/saved mode/accent/motion, actual density/font, fresh nonce and native window must agree. The independent expected JSON comes from the approved palette plus complete accent maps; it never replaces the app scheme.

Text pairs require unrounded contrast≥4.5; significant controls and disabled readability use the project's explicit≥3 target. Required inks/fills must exist in the actual component region. Monochrome/disabled pixels must lie on the real ink-to-surface antialiasing segment. Foreign, hidden, clipped, malformed, ambiguous, wrong-state or wrong-window evidence fails closed. Dialog state and separate-window identity settle together.

Before the first color preference write, a fresh run-owned ThemeLifecycleSession snapshots the exact nine presentation keys and their presence. A lost first marker still attempts restore with a fresh deadline. Font and app restorations are independent attempts. Snapshot hash/presence, original global night policy, real close action and zero final owned windows are required; cleanup failure leaves the receipt incomplete. The separate lifecycle gate owns opposite-OS preview/apply/cancel, editor continuity, cold-start resources and bars.

The private `theme-state-evidence.json` binds build, observations, actions, bounds, color counts/contrast and PNG/XML hashes. It explicitly says original15_changed=false and full_acceptance_claimed=false. Original15/original14 actions, counts, package/viewport rules and thresholds remain unchanged.

## Prepared regression coverage; real gates still pending

The new host module has 30 tests of actual native parsers/pixel functions using the original 320×640 fixture viewport. Negatives include wrong compiled/saved colors, stale/conflicting marker, foreign/clipped target, wrong dark thumb, saturated disabled art, index-zero-only series color, invented missing zero, page-white corners masquerading as button/calendar glyphs, faded disabled date ink, wrong calendar state/window, early marker failure and independent app restoration after font-transport failure. Test byte fixtures are never runtime screenshots or goldens.

Sixteen JVM tests exercise actual production color/state functions, every effective accent, fixed/inverse roles, semantic/chart/disabled pairs, explicit monochrome and SYSTEM known/unknown fallback. Existing host palette oracles parse AnalystColors and verify actual factory/renderer bindings, including all 24 calendar role arguments. These sources were only parsed/hashes calculated here.

Mandatory next steps: bind to actual 45 backup; combined46 source/dependency review; Windows host/JVM/lint/build; unchanged native suites plus this 52-frame and separate lifecycle receipts; actual Windows golden regeneration/review where required; normal CI and exact-head external Sonar. This candidate establishes none of those outcomes.
