"""Emit Kotlin source and effective-role design data; does not import/run the app."""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
proposal_path = ROOT.parent / "theme46-audit/palette-proposal.json"
raw = proposal_path.read_bytes()
if hashlib.sha256(raw).hexdigest() != "bec4160ad8794cc251968dd3bc8199dcedcd188d5796eff2e0c3cd320845cf95":
    raise SystemExit("Unexpected reviewed palette bytes")
proposal = json.loads(raw)
target = ROOT / "source/app/src/main/java/ru/omnicio/app/ui/theme/AnalystColors.kt"
target.parent.mkdir(parents=True, exist_ok=True)

lines = [
    "package ru.omnicio.app.ui.theme", "",
    "import androidx.compose.material3.ColorScheme",
    "import androidx.compose.material3.darkColorScheme",
    "import androidx.compose.material3.lightColorScheme",
    "import androidx.compose.runtime.Immutable",
    "import androidx.compose.ui.graphics.Color",
    "import androidx.compose.ui.graphics.compositeOver",
    "import ru.omnicio.app.ui.workspace.AccentStyle", "",
    "/** Extra semantic colors stay independent of a user's selected action accent. */",
    "@Immutable", "data class AnalystSemanticColors(",
]
lines += [f"    val {name}: Color," for name in proposal["semantic_roles"]["light"]]
lines += [")", "", "@Immutable", "data class AnalystColorSet(",
          "    val material: ColorScheme,", "    val semantic: AnalystSemanticColors,",
          "    val chartSeries: List<Color>,", ")", ""]
for mode in ("light", "dark"):
    title = mode.title()
    lines += [f"private val {title}Colors = {mode}ColorScheme("]
    lines += [f"    {name} = Color(0xFF{value})," for name, value in proposal["material_roles"][mode].items()]
    lines += [")", "", f"private val {title}Semantic = AnalystSemanticColors("]
    lines += [f"    {name} = Color(0xFF{value})," for name, value in proposal["semantic_roles"][mode].items()]
    lines += [")", ""]
lines += [
    "/** All 48 Material roles are explicit; no wallpaper or default palette is merged. */",
    "fun analystColors(dark: Boolean, accent: AccentStyle = AccentStyle.AURORA): AnalystColorSet {",
    "    val base = if (dark) DarkColors else LightColors",
    "    val opposite = if (dark) LightColors else DarkColors",
    "    val semantic = if (dark) DarkSemantic else LightSemantic",
    "    val colors = when (accent) {",
    "        AccentStyle.AURORA -> base",
]
for accent, family in (("OCEAN", "secondary"), ("IRIS", "tertiary")):
    cap = family.title()
    lines += [f"        AccentStyle.{accent} -> base.copy(",
              f"            primary = base.{family}, onPrimary = base.on{cap},",
              f"            primaryContainer = base.{family}Container, onPrimaryContainer = base.on{cap}Container,",
              f"            inversePrimary = opposite.{family}, surfaceTint = base.{family},",
              f"            primaryFixed = base.{family}Fixed, primaryFixedDim = base.{family}FixedDim,",
              f"            onPrimaryFixed = base.on{cap}Fixed, onPrimaryFixedVariant = base.on{cap}FixedVariant,",
              "        )"]
lines += ["    }", "    return AnalystColorSet(colors, semantic,",
          "        listOf(base.secondary, semantic.success, base.tertiary, semantic.warning, base.error, base.primary))",
          "}", "", "/** Actual state-layer composition; callers retain the foreground paired to the fill. */",
          "internal fun analystPressedColor(fill: Color, foreground: Color, opacity: Float = .08f): Color =",
          "    foreground.copy(alpha = opacity).compositeOver(fill)", ""]
target.write_text("\n".join(lines), encoding="utf-8")

effective = {"schema": 1, "palette_sha256": hashlib.sha256(raw).hexdigest(),
             "kind": "complete_effective_role_maps_for_review_not_runtime_evidence", "accents": {}}
for accent, family in (("AURORA", "primary"), ("OCEAN", "secondary"), ("IRIS", "tertiary")):
    effective["accents"][accent] = {}
    for mode in ("light", "dark"):
        base = proposal["material_roles"][mode]
        opposite = proposal["material_roles"]["dark" if mode == "light" else "light"]
        roles = copy.deepcopy(base)
        cap = family.title()
        roles.update(primary=base[family], onPrimary=base["on" + cap],
                     primaryContainer=base[family + "Container"], onPrimaryContainer=base["on" + cap + "Container"],
                     inversePrimary=opposite[family], surfaceTint=base[family],
                     primaryFixed=base[family + "Fixed"], primaryFixedDim=base[family + "FixedDim"],
                     onPrimaryFixed=base["on" + cap + "Fixed"], onPrimaryFixedVariant=base["on" + cap + "FixedVariant"])
        effective["accents"][accent][mode] = dict(material=roles,
            semantic=proposal["semantic_roles"][mode], chartSeries=proposal["categorical_chart"][mode])
(ROOT / "effective-accent-roles.json").write_text(json.dumps(effective, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"kotlin_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "effective_role_maps": 6}))
