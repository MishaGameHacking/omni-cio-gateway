"""UI checks use only the disposable emulator callback, never attached user phones."""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

APPLY_LABEL = 'Применить'
LIGHT_THEME_LABEL = 'Светлая'


PACKAGE = "ru.omnicio.app.debug"
ACTIVITY = PACKAGE + "/ru.omnicio.app.ProfileUiProbeActivity"
THEME_LABEL = "Оформление"
WORKSPACE_BACK = "Назад"
CONFIRM_LABEL = "Понятно"
SETTINGS_LABEL = "Настройки"
INFO_LABEL = "О приложении"
EDUCATION_LABEL = "Обучение"
BACK_FROM_EDUCATION = "Назад"
FIRST_LESSON = "Сначала цель, срок и резерв"
FIRST_LESSON_TOGGLE = "lesson-toggle-start-plan"
LIGHT_BACKGROUND = "fff8fafc"
DARK_BACKGROUND = "ff0f172a"


def matching_node(tree: ET.Element, text: str) -> ET.Element | None:
    """Compose may merge card labels into text or content-description nodes."""
    for node in tree.iter("node"):
        labels = node.get("text", "").splitlines() + node.get(
            "content-desc", ""
        ).splitlines()
        if text in [label.strip() for label in labels]:
            return node
    return None


def checkable_label(tree: ET.Element, text: str) -> ET.Element | None:
    """Resolve the native control, including labels in its unmerged children."""
    return _native_label(tree, text, "checkable", "true")


def button_label(tree: ET.Element, text: str) -> ET.Element | None:
    """Read the action owner's state, including Compose's separate role child.

    Compose exposes a non-leaf clickable as View, with a direct, unlabelled
    Button child for Role.Button. That child has no click action or Disabled
    property; enabled must be read from its clickable parent, not the role or
    text child. A label or arbitrary clickable without a button role is not
    evidence of a button.
    """
    matches = [node for node in tree.iter("node")
               if node.get("package") == PACKAGE
               and node.get("visible-to-user") != "false"
               and _owns_button_role(node)
               and matching_node(node, text) is not None]
    if len(matches) > 1:
        raise AssertionError("Ambiguous native control label: " + text)
    return matches[0] if matches else None


def _owns_button_role(node: ET.Element) -> bool:
    if node.get("class") == "android.widget.Button":
        return True
    if node.get("class") != "android.view.View" or node.get("clickable") != "true":
        return False
    return any(child.get("class") == "android.widget.Button"
               and child.get("package") == PACKAGE
               and child.get("visible-to-user") != "false"
               and child.get("clickable") == "false"
               and not child.get("text") and not child.get("content-desc")
               and len(child) == 0
               for child in node)


def _native_label(tree: ET.Element, text: str, attribute: str, value: str) -> ET.Element | None:
    matches = [node for node in tree.iter("node")
               if node.get("package") == PACKAGE
               and node.get("visible-to-user") != "false"
               and node.get(attribute) == value
               and matching_node(node, text) is not None]
    if len(matches) > 1:
        raise AssertionError("Ambiguous native control label: " + text)
    return matches[0] if matches else None


def node_bounds(node: ET.Element) -> tuple[int, int, int, int]:
    match = re.fullmatch(
        r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]",
        node.get("bounds", ""),
    )
    if match is None:
        raise AssertionError("Missing UI bounds")
    left, top, right, bottom = map(int, match.groups())
    if left < 0 or top < 0 or right <= left or bottom <= top:
        raise AssertionError("UI target is empty or outside the visible screen")
    return left, top, right, bottom


def _horizontal_scroll_direction(x1: int, y1: int, x2: int, y2: int) -> str:
    if y1 != y2 or x1 == x2:
        raise ValueError("Horizontal semantic scroll geometry is invalid")
    return "end" if x2 < x1 else "start"


def _vertical_scroll_direction(x1: int, y1: int, x2: int, y2: int) -> str:
    if x1 != x2 or y1 == y2:
        raise ValueError("Vertical semantic scroll geometry is invalid")
    return "end" if y2 < y1 else "start"


def semantic_scroll_direction(
    area: str,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
) -> str:
    if area in {"profile-tabs", "dossier-tabs", "quotes-intervals"}:
        return _horizontal_scroll_direction(x1, y1, x2, y2)
    return _vertical_scroll_direction(x1, y1, x2, y2)


class ProfileProbe:
    def __init__(self, device):
        self.device = device
        self.read_tree = None

    def command(self, *args, timeout=15):
        response = self.device(*args, timeout=timeout)
        if response.returncode:
            detail = (response.stdout + "\n" + response.stderr).strip()[-1500:]
            raise RuntimeError(
                f"UI test command failed ({response.returncode}): {detail}"
            )
        return response.stdout

    def tree(self):
        if self.read_tree is None:
            raise RuntimeError("Persistent UI frame session is not connected")
        return self.read_tree()

    def capture(self, name: str):
        """Capture a real frame through the official emulator console.

        Guest screencap stalls on this headless Windows lab with Compose dialogs
        (documented in PR #827 and reproduced by job 116433346814). Preserve the
        established console transport; it still must produce a complete PNG.
        A fresh directory prevents reusing a previous frame. Errors remain fatal.
        """
        if re.fullmatch(r"[a-z][a-z0-9-]{0,63}", name) is None:
            raise ValueError("Invalid screenshot label")
        root = Path(__file__).resolve().parents[2]
        directory = root / "app/build/outputs/apk/preview/ui-screens"
        if directory.is_symlink() or not directory.resolve().is_relative_to(root):
            raise ValueError("Screenshot directory escapes checkout")
        directory.mkdir(parents=True, exist_ok=True)
        destination = directory / (name + ".png")
        if destination.is_symlink():
            raise ValueError("Screenshot destination is a symlink")
        with tempfile.TemporaryDirectory(prefix="capture-", dir=directory) as stage:
            self.command("emu", "screenrecord", "screenshot", stage)
            pictures = list(Path(stage).glob("*.png"))
            if len(pictures) != 1:
                raise AssertionError("Expected exactly one fresh emulator screenshot")
            picture = pictures[0]
            if not picture.is_file() or picture.is_symlink():
                raise AssertionError("Emulator screenshot is not a regular file")
            if not 100 <= picture.stat().st_size <= 2097152:
                raise AssertionError("Unexpected emulator screenshot size")
            image = picture.read_bytes()
            if not image.startswith(b"\x89PNG\r\n\x1a\n") or not image.endswith(
                b"\x00\x00\x00\x00IEND\xaeB`\x82"
            ):
                raise AssertionError("Invalid or incomplete emulator screenshot")
            picture.replace(destination)
        print("PROFILE_SCREENSHOT=" + name, flush=True)
        return destination

    def wait_for(self, read, message):
        deadline = time.monotonic() + 12
        last_error = None
        while time.monotonic() < deadline:
            try:
                value = read()
                if value is not None and value is not False:
                    return value
            except (RuntimeError, ET.ParseError, ValueError) as error:
                last_error = error
            time.sleep(0.2)
        raise AssertionError(message) from last_error

    def find(self, text):
        return self.wait_for(
            lambda: matching_node(self.tree(), text),
            "UI label not found: " + text,
        )

    def find_all(self, labels):
        """Check simultaneous labels in one fresh frame, not five new sessions."""

        def read():
            frame = self.tree()
            nodes = [matching_node(frame, label) for label in labels]
            return nodes if all(node is not None for node in nodes) else None

        return self.wait_for(
            read,
            "UI labels not found together: " + ", ".join(labels),
        )

    def bounds(self, text):
        return node_bounds(self.find(text))

    def _semantic_scroll_callback(self, area: str, direction: str):
        """Map validated list geometry to one exact accessibility action.

        The old shell drag could begin over a clickable profile card and open a
        modal dialog instead of scrolling. This callback keeps the existing
        bounded geometry contract, but delegates movement to the exact tagged
        Compose list through the owned persistent UiAutomation session.
        """
        from persistent_ui import FrameReader, SCROLL_LIST_CODES

        reader = getattr(self.read_tree, "__self__", None)
        if not isinstance(reader, FrameReader):
            raise ValueError("Semantic scrolling needs the owned frame session")
        if area not in SCROLL_LIST_CODES or direction not in {"start", "end"}:
            raise ValueError("Unknown semantic scroll target")

        def scroll(x1, y1, x2, y2):
            observed = semantic_scroll_direction(area, x1, y1, x2, y2)
            if observed != direction:
                raise ValueError(
                    "Semantic scroll direction disagrees with list geometry"
                )
            reader.scroll_list(area, direction)

        return scroll

    def reveal(self, text, area="profile-content", direction="end", *, max_swipes=10):
        from profile_scroll import reveal_in_list

        target = reveal_in_list(
            self.tree,
            self._semantic_scroll_callback(area, direction),
            text,
            resource_id=area,
            direction=direction,
            max_swipes=max_swipes,
            layout_timeout=12,
        )
        if target is None:
            from profile_scroll import visible_label

            target = self.wait_for(
                lambda: visible_label(self.tree(), text),
                "UI label not visible: " + text,
            )
        return target

    def reveal_resource(
        self,
        resource_id,
        area="profile-content",
        direction="end",
        for_capture=False,
        minimum_size=(0, 0),
    ):
        from profile_scroll import reveal_resource_in_list

        target = reveal_resource_in_list(
            self.tree,
            self._semantic_scroll_callback(area, direction),
            resource_id,
            resource_id=area,
            direction=direction,
            layout_timeout=12,
            for_capture=for_capture,
            minimum_size=minimum_size,
        )
        if target is None:
            from profile_scroll import visible_resource, fully_visible_resource

            target = self.wait_for(
                lambda: fully_visible_resource(self.tree(), resource_id, area, minimum_size)
                if for_capture else visible_resource(self.tree(), resource_id),
                "UI resource not visible: " + resource_id,
            )
        return target

    def tap_node(self, node):
        left, top, right, bottom = node_bounds(node)
        self.command(
            "shell",
            "input",
            "tap",
            str((left + right) // 2),
            str((top + bottom) // 2),
        )

    def dismiss_keyboard(self):
        from native_input_evidence import dismiss_keyboard
        return dismiss_keyboard(self)

    def tap(self, text, area="profile-content", direction="end", *, max_swipes=10):
        self.tap_node(self.label_tap_target(text, area, direction, max_swipes=max_swipes))

    def label_tap_target(self, text, area="profile-content", direction="end", *, max_swipes=10):
        """Reveal and observe the settled native action before any tap."""
        from native_label_target import settled_label
        from profile_scroll import reveal_in_list

        target = reveal_in_list(
            self.tree, self._semantic_scroll_callback(area, direction), text,
            resource_id=area, direction=direction, max_swipes=max_swipes, layout_timeout=12, for_tap=True,
        )
        if target is None:
            raise AssertionError("Native action list is not visible: " + area)
        return settled_label(self.tree, text)

    def tap_visible(self, text):
        """Wait for a native visible action/editor without scrolling any list."""
        from native_label_target import settled_label

        self.tap_node(settled_label(self.tree, text))

    def _show_resource_on_screen(self, area, resource_id):
        from persistent_ui import FrameReader

        reader = getattr(self.read_tree, "__self__", None)
        if not isinstance(reader, FrameReader):
            raise ValueError("Native target reveal needs the owned frame session")
        return reader.show_on_screen(area, resource_id)

    def resource_tap_target(
        self,
        resource_id,
        area="profile-content",
        direction="end",
    ):
        from profile_scroll import reveal_resource_in_list, settled_resource

        target = reveal_resource_in_list(
            self.tree,
            self._semantic_scroll_callback(area, direction),
            resource_id,
            resource_id=area,
            direction=direction,
            layout_timeout=12,
            for_tap=True,
            show_on_screen=self._show_resource_on_screen,
        )
        if target is None:
            raise AssertionError("Button list is not visible: " + area)
        return settled_resource(self.tree, resource_id, area)

    def tap_resource(self, resource_id, area="profile-content", direction="end"):
        self.tap_node(self.resource_tap_target(resource_id, area, direction))

    def tap_profile_content(self, text):
        from native_label_target import settled_label
        from profile_scroll import reveal_in_list
        from profile_tab_checks import content_tree

        def read_content():
            frame = self.tree()
            scoped = ET.Element("hierarchy", dict(frame.attrib))
            scoped.append(content_tree(frame))
            return scoped

        target = reveal_in_list(
            read_content,
            self._semantic_scroll_callback("profile-content", "end"),
            text,
            resource_id="profile-content",
            layout_timeout=12,
            for_tap=True,
        )
        if target is None:
            raise AssertionError("Profile content action not visible: " + text)
        self.tap_node(settled_label(read_content, text))

    def tab(self, label):
        from profile_tab_checks import TAB_IDS, reveal_tab, selected_tab, settled_tab

        resource_id = TAB_IDS[label]
        direction = "start" if label == SETTINGS_LABEL else "end"
        reveal_tab(self.tree, self._semantic_scroll_callback("profile-tabs", direction), resource_id, direction)
        self.tap_node(settled_tab(self.tree, resource_id))
        return self.wait_for(
            lambda: selected_tab(self.tree(), resource_id),
            "Profile tab selection not confirmed: " + resource_id,
        )

    def marker(self, expected):
        def read():
            for node in self.tree().iter("node"):
                if expected in node.get("content-desc", "").split(";"):
                    return node
            return None

        self.wait_for(read, "UI marker missing: " + expected)

    def palette(self, expected):
        self.marker("probe-background:" + expected)
        foreground = "fff8fafc" if expected == DARK_BACKGROUND else "ff0f172a"
        self.marker("probe-foreground:" + foreground)

    def open(self):
        from profile_launch import launch_profile

        launch_profile(self.command, self.tree, self.wait_for)
        self.marker("probe-education-tests:10")

    def horizontal_info(self):
        from profile_tab_checks import assert_horizontal_geometry

        # Sample each selected tab, not a clipped sliver left outside the rail.
        peer = node_bounds(self.tab(SETTINGS_LABEL))
        target = node_bounds(self.tab(INFO_LABEL))
        print(
            "PROFILE_TAB_GEOMETRY="
            + json.dumps({"settings": peer, "about": target}),
            flush=True,
        )
        assert_horizontal_geometry(peer, target)

    def dashboards(self):
        from profile_launch import launch_profile

        self.command("shell", "settings", "put", "system", "font_scale", "1.0")
        self.command("shell", "cmd", "uimode", "night", "yes")
        for screen in ("home", "portfolio"):
            launch_profile(self.command, self.tree, self.wait_for, expected_screen=screen)
            self.marker("probe-screen:" + screen)
            self.palette(DARK_BACKGROUND)
            self.find("ВИЗУАЛЬНЫЙ ТЕСТ · НЕ РЕАЛЬНЫЕ ДАННЫЕ")
            self.find_all(("Система", "Решения", "Настройки"))
            self.find("Analyst AI" if screen == "home" else "Портфель")
            self.capture("spectrum-" + screen)
            if screen == "portfolio":
                self.reveal("Денежные средства", "portfolio-content")
                self.capture("spectrum-allocation")
                from native_input_evidence import append_native_text
                self.tap_resource("portfolio-search", "portfolio-content")
                append_native_text(self, "", "NO_SUCH_ASSET")
                self.dismiss_keyboard()
                self.find("Ничего не найдено")
                self.tap_visible("Сбросить")
                self.find("Денежные средства")
                from position_preview_probe import exercise_position_preview
                exercise_position_preview(self)
        self.command("shell", "am", "force-stop", PACKAGE)

    def goal_workflow(self):
        from goal_workflow_probe import exercise_goal_workflow
        exercise_goal_workflow(self)

    def balance_privacy(self):
        from balance_privacy_probe import exercise_balance_privacy
        exercise_balance_privacy(self)

    def spatial(self):
        from spatial_ui_probe import exercise_spatial
        exercise_spatial(self)

    def business(self):
        from business_ui_probe import exercise_business
        report = exercise_business(self)
        self.business_cases = [row["case"] + "@" + format(row["font_scale"], "g") for row in report["cases"]]

    def session_context(self):
        from session_context_probe import exercise_session_context
        exercise_session_context(self)

    def portfolio(self):
        from portfolio_ui_probe import exercise_portfolio
        report = exercise_portfolio(self)
        self.portfolio_cases = [row["case"] + "@" + format(row["font_scale"], "g") for row in report["cases"]]

    def workspace(self):
        from profile_launch import launch_profile
        for screen, label in (("appearance", "Оформление"), ("strategy", "Моя стратегия"),
                              ("assistant", "Ассистент"), ("market", "Рынки и география"), ("ux100", "Проверка UX100")):
            launch_profile(self.command, self.tree, self.wait_for, expected_screen=screen)
            self.find(label)
            self.find("ВИЗУАЛЬНЫЙ ТЕСТ · НЕ РЕАЛЬНЫЕ ДАННЫЕ")
            self.capture("workspace-" + screen)
            if screen == "strategy":
                self.tap_visible("Отбор")
                self.reveal("Кредитные рейтинги", "workspace-content")
                self.reveal("Минимум: BBB-", "workspace-content")
                self.capture("workspace-ratings")
                self.tap_visible("Доход")
                self.reveal("Пополнять резерв", "workspace-content")
                self.tap("Пополнять резерв", "workspace-content")
                self.reveal("Сохранить черновик", "workspace-content")
                self.tap("Сохранить черновик", "workspace-content")
                self.find("Черновик сохранён")
            elif screen == "ux100":
                # A label can be reported outside the clipped viewport during scroll.
                # Use the exact button, clipped to its list and stable for three frames.
                self.tap_resource("plan-defer-fixture", "workspace-content")
                self.tap_visible("Нужно подумать")
                self.find("Отложено: Нужно подумать · изменить")
                self.tap_visible("График")
                self.reveal("Скрыть суммы", "workspace-content", direction="start")
                self.reveal_resource("history-bars", "workspace-content")
                self.capture("ux100-chart")
                chart = self.resource_tap_target("history-bars", "workspace-content")
                left, top, right, bottom = node_bounds(chart)
                self.command("shell", "input", "tap", str(left + (right - left) // 34), str((top + bottom) // 2))
                self.find("Выбранный интервал: 2026-10-01 — 2026-10-01")
                self.capture("bars-selected")
                self.tap_resource("history-selection-next", "workspace-content")
                self.find("Выбранный интервал: 2026-10-02 — 2026-10-02")
                self.tap_resource("history-selection-reset", "workspace-content")
                self.find("За показанный период")
                self.tap("Скрыть суммы", "workspace-content", direction="start")
                self.find("График скрыт режимом приватности.")
                self.tap("Показать суммы", "workspace-content", direction="start")
                self.tap_visible("Изменения")
                self.find("Влияние изменений")
                self.capture("ux100-impact")
                self.tap_visible("События")
                self.tap("Обновления события (2)", "workspace-content")
                self.find("Уточнение источника")
            elif screen == "appearance":
                self.reveal("Без движения", "workspace-content")
                self.tap("Без движения", "workspace-content")
                self.find("Цветное оформление сохраняется. Элементы сразу принимают конечное состояние без движения.")
                self.reveal("Вернуть оформление по умолчанию", "workspace-content")
                self.tap("Вернуть оформление по умолчанию", "workspace-content")
            self.tap_visible(WORKSPACE_BACK)
            self.find("Система")
        self.command("shell", "am", "force-stop", PACKAGE)

    def profile_preflight(self):
        # Exercise actual settings and dialogs before system-mode changes,
        # then repeat after applying those changes below.
        self.open()
        # This preflight validates real dialog actions and settings scroll reachability. The
        # full dialog stage below captures all three required screenshots;
        # avoid re-capturing those frames before the primary UI assertions.
        self.dialogs(capture_evidence=False)
        self.section_scroll_reset()

    def themes(self):
        self.command("shell", "cmd", "uimode", "night", "no")
        self.open()
        # Spectrum starts dark; light/system remain explicit user choices.
        self.palette(DARK_BACKGROUND)
        self.tap(THEME_LABEL)
        self.tap(LIGHT_THEME_LABEL, "workspace-content")
        self.palette(LIGHT_BACKGROUND)
        self.tap_visible(WORKSPACE_BACK)
        self.palette(DARK_BACKGROUND)
        self.tap(THEME_LABEL)
        self.tap(LIGHT_THEME_LABEL, "workspace-content")
        self.tap(APPLY_LABEL, "workspace-content", direction="start")
        self.tap_visible(WORKSPACE_BACK)
        self.palette(LIGHT_BACKGROUND)
        self.capture("light-initial")
        self.tap(THEME_LABEL)
        self.tap("Тёмная", "workspace-content")
        self.tap(APPLY_LABEL, "workspace-content", direction="start")
        self.tap_visible(WORKSPACE_BACK)
        self.palette(DARK_BACKGROUND)
        self.capture("dark-selected")
        self.command("shell", "am", "force-stop", PACKAGE)
        self.open()
        self.palette(DARK_BACKGROUND)
        self.capture("dark-restored")
        self.tap(THEME_LABEL)
        self.tap(LIGHT_THEME_LABEL, "workspace-content")
        self.tap(APPLY_LABEL, "workspace-content", direction="start")
        self.tap_visible(WORKSPACE_BACK)
        self.palette(LIGHT_BACKGROUND)
        self.capture("light-selected")
        self.tap(THEME_LABEL)
        self.tap("Как в системе", "workspace-content")
        self.tap(APPLY_LABEL, "workspace-content", direction="start")
        self.tap_visible(WORKSPACE_BACK)
        self.command("shell", "cmd", "uimode", "night", "yes")
        self.palette(DARK_BACKGROUND)
        self.capture("system-dark")
        self.command("shell", "cmd", "uimode", "night", "no")
        self.palette(LIGHT_BACKGROUND)
        self.capture("system-light")

    def dialogs(self, capture_evidence=True):
        self.tap_resource("profile-security-action")
        self.find(CONFIRM_LABEL)
        if capture_evidence:
            self.capture("security")
        self.tap_visible(CONFIRM_LABEL)
        self.reveal(INFO_LABEL)
        if capture_evidence:
            self.capture("info")
        self.tap_profile_content(INFO_LABEL)
        self.find(CONFIRM_LABEL)
        if capture_evidence:
            self.capture("about")
        if not any(
            "Версия " in node.get("text", "")
            for node in self.tree().iter("node")
        ):
            raise AssertionError("About version text missing")
        self.tap_visible(CONFIRM_LABEL)

    def section_scroll_reset(self):
        # The redesigned settings are one scroll hierarchy. Start from a real visible top control.
        self.reveal("Автоматический анализ", direction="start", max_swipes=20)
        for group in ("Анализ и стратегия", "Подключения", "Интерфейс",
                      "Приватность", "Дополнительно", "Аккаунт"):
            node_bounds(self.reveal(group, direction="end", max_swipes=20))
        self.reveal("Автоматический анализ", direction="start", max_swipes=20)
        self.wait_for(lambda: checkable_label(self.tree(), "Автоматический анализ"),
                      "Automatic analysis lost its native switch")
        self.tap_resource("profile-security-action")
        self.find(CONFIRM_LABEL)
        self.tap_visible(CONFIRM_LABEL)
        self.reveal(THEME_LABEL, direction="start", max_swipes=20)

    def automation(self):
        from automation_ui_probe import exercise_automation
        report = exercise_automation(self)
        self.automation_report = report
        self.automation_cases = [row["case"] + "@" + format(row["font_scale"], "g")
                                 for row in report["cases"]]

    def education(self, screenshot="education"):
        area = "education-content"
        self.tap(EDUCATION_LABEL)
        self.find(EDUCATION_LABEL)
        self.reveal(FIRST_LESSON, area)
        self.capture(screenshot)
        self.tap_resource(FIRST_LESSON_TOGGLE, area)
        self.find("Свернуть урок: " + FIRST_LESSON)
        self.reveal("• Запишите цель и дату, когда деньги могут понадобиться.", area)
        self.tap("Старт", area)
        self.find(FIRST_LESSON)
        self.tap("Все уроки", area)
        self.find(EDUCATION_LABEL)
        self.tap(BACK_FROM_EDUCATION, area)
        self.find("Настройки")

    def large_font(self):
        self.command("shell", "settings", "put", "system", "font_scale", "2.0")
        self.command("shell", "am", "force-stop", PACKAGE)
        self.open()
        self.section_scroll_reset()
        self.capture("large-font")
        self.education("education-large-font")

        from profile_launch import launch_profile
        launch_profile(self.command, self.tree, self.wait_for, expected_screen="ux100")
        self.tap_visible("График")
        chart = self.resource_tap_target("history-bars", "workspace-content")
        left, top, right, bottom = node_bounds(chart)
        self.command("shell", "input", "tap", str(right - (right - left) // 34), str((top + bottom) // 2))
        self.reveal("Выбранный интервал: 2026-10-17 — 2026-10-17", "workspace-content", direction="start")
        self.reveal("Изменение стоимости", "workspace-content")
        self.reveal("Минимум / максимум", "workspace-content")
        self.capture("bars-large-font")
        self.tap_resource("history-selection-reset", "workspace-content", direction="start")
        self.reveal("За показанный период", "workspace-content")


def night_setting(output: str) -> str:
    match = re.search(
        r"Night mode:\s*(yes|no|auto|custom)\b",
        output,
        flags=re.IGNORECASE,
    )
    return match.group(1).lower() if match else "auto"


def exercise(device) -> dict:
    from persistent_ui import frame_session

    with frame_session(device) as read_tree:
        return exercise_checks(device, read_tree)


def run_stage(probe, test):
    """Keep the original UI failure even when its diagnostic capture also fails."""
    try:
        test()
    except (AssertionError, RuntimeError, ValueError, OSError):
        try:
            probe.capture("failure")
        except Exception as error:
            print("PROFILE_FAILURE_CAPTURE_UNAVAILABLE=" + type(error).__name__, flush=True)
        raise


def exercise_checks(device, read_tree) -> dict:
    """Run production screen assertions with an explicitly scoped frame source."""
    checkout = str(Path(__file__).resolve().parents[2])
    if checkout not in sys.path:
        sys.path.insert(0, checkout)
    from backend.android_runtime_contract import CURRENT_UI_SUITE, UI_STAGE_IDS
    probe = ProfileProbe(device)
    probe.read_tree = read_tree
    original_night = night_setting(
        probe.command("shell", "cmd", "uimode", "night")
    )
    original_scale = probe.command(
        "shell",
        "settings",
        "get",
        "system",
        "font_scale",
    ).strip()
    if re.fullmatch(r"\d(?:\.\d{1,3})?", original_scale) is None:
        original_scale = "1.0"
    try:
        stages = (
            ("native-2d-renderer", probe.spatial),
            ("session-context", probe.session_context),
            ("balance-privacy", probe.balance_privacy),
            ("goal-workflow", probe.goal_workflow),
            ("business-30-cases", probe.business),
            ("portfolio-7-cases", probe.portfolio),
            ("spectrum-dashboards", probe.dashboards),
            ("workspace-interactions", probe.workspace),
            ("automation-13-cases", probe.automation),
            ("profile-preflight", probe.profile_preflight),
            ("themes", probe.themes),
            ("dialogs", probe.dialogs),
            ("settings-group-scroll", probe.section_scroll_reset),
            ("education", probe.education),
            ("large-font-200", probe.large_font),
        )
        if tuple(name for name, _ in stages) != UI_STAGE_IDS:
            raise AssertionError("UI stages differ from the current release contract")
        completed_stages = []
        for name, test in stages:
            print("PROFILE_UI_STAGE=" + name, flush=True)
            run_stage(probe, test)
            completed_stages.append(name)
            print("PROFILE_UI_STAGE_PASSED=" + name, flush=True)
        print(
            "PROFILE_UI_TESTS=passed: spectrum-dark-first,light,dark,system,"
            "persistence,about,security,settings-group-scroll,automation,education,font-200,"
            "education-font-200,refresh-state-15,education-catalog-10",
            flush=True,
        )
        return {"ui_suite": CURRENT_UI_SUITE, "ui_stages": completed_stages,
                "business_case_count": len(probe.business_cases),
                "business_cases": probe.business_cases, "portfolio_case_count": len(probe.portfolio_cases),
                "portfolio_cases": probe.portfolio_cases,
                "automation_case_count": len(probe.automation_cases), "automation_cases": probe.automation_cases,
                "automation_report": probe.automation_report}
    finally:
        from profile_snapshot import restore_device_settings

        # A cleanup disconnect must not replace a real UI assertion and thereby
        # make the outer driver retry an application defect as transport loss.
        restore_device_settings(
            probe.command,
            original_scale,
            original_night,
            sys.exc_info()[1],
        )

