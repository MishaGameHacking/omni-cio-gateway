# Theme46 core — prepared source slice

This context-only candidate contains **40 source files: 30 existing and 10 new**. It has not been applied to the repository, imported, compiled, tested, run on a device, published or installed. AST parsing, hashing, source comparison and color arithmetic are administrative preparation. Manifest old hashes must be bound to the actual successful 45 backup before Windows apply.

## Product changes

AnalystColors owns all 48 approved Material and 19 semantic light/dark roles. Saved AURORA/OCEAN/IRIS enums and preference keys remain stable. Each accent maps the full 10-role primary family, including inverse/tint/fixed colors. Fixed roles are equal across light/dark. Semantic meanings and six categorical series stay independent of action accent.

Material/Spectrum/Spatial components consume these shared roles: cards, buttons, choices, tabs, fields, text selection, progress, sliders, native/custom switches, signed values, charts and functional/decorative artwork. Profile's ordinary Material switch now uses SpectrumSwitch with all 16 state colors. Neutral pressed surfaces use 4% on-surface to retain secondary-text contrast; colored action fills use 8%. Approved base shades are unchanged.

Artwork has explicit monochrome/decorative mode instead of Color.White equality; every disabled support ink is disabled. History colors every observation consistently, negatives retain their meaning, categorical plots use six stable roles, selected edges use paired roles inside existing geometry. Data, values, hit targets, labels and motion guards remain unchanged.

Final 45 drawer/bottom/rail receive only explicit colors and monochrome glyphs. Dirty/Back/menu/navigation guards are unchanged. Bottom-bar modifier order includes the verified retry1 zIndex→clipToBounds→testTag correction.

The real DateRangePicker receives explicit 24 calendar role colors plus date-input field colors. Selectable dates, ranges and Apply/Cancel behavior are unchanged. Four finite extra native captures open this production picker; arithmetic alone cannot prove visible calendar colors.

## SYSTEM integration

The core consumes the assets slice's public SystemThemeObservation and provides its single actual observation through LocalSystemThemeObservation. Forced modes remain direct. SYSTEM follows known independent display-area state; Unknown retains the last displayed theme or the current app configuration as the explicit first fallback. Appearance shows the approved Unknown notice.

Only committed saveTheme calls the saved application-night-mode synchronizer; Preview/Cancel remain ephemeral. Assets supply helper/Application/manifests. The separate lifecycle slice supplies its finite nine-key run snapshot and actual opposite-OS/dirty-owner probe. The router includes its exact reviewed delta. Native colors reuse lifecycle begin/restore before any preference mutation, without extra screenshots or OS-mode changes.

## Prepared validation

- 16 new JVM tests exercise actual production functions, every effective accent and SYSTEM fallback.
- 30 new host tests exercise real native parsers/pixel helpers and early-failure restoration, including exact absence of keys.
- Existing foreground/contrast/renderer oracles move to actual new tokens; calendar contracts bind every explicit role and preserve selectableDates.
- The finite additional native colors gate has 52 exact cases in coverage-matrix.json; full coverage and exclusions are in NATIVE_COVERAGE_PROPOSAL.md.

Original15/original14 interaction cases and thresholds remain intact. profile_ui_probe.py changes only approved expected foreground/background constants. No reference PNG changed. No preparation result establishes native acceptance or plan completion.

## Union dependencies / version handling

1. Rebind old bytes to the actual successful 45 backup. Navigation/Appearance and the version oracle use final 45 / retry1 old bytes; other hashes describe unchanged verified44 paths. Retry2 caller-limit fixes do not alter these production overlays.
2. Include assets helper/Application/manifests and all 3 lifecycle source files. The color helper depends on lifecycle _launch and exact snapshot restoration; do not omit the router branch.
3. The separate quote Reset repair is parent-owned; core does not edit InstrumentQuotesPanel.kt.
4. Parent's 46 version bump must merge into test_android17_live_spectrum.py: this copy keeps45/0.13.7 while carrying the renderer-signature oracle update. The assets brand test has a separate documented version merge. Core does not edit app/build.gradle.kts.
5. Merge parent-owned theme design/checkpoint docs with actual evidence.

manifest.json/candidate.patch describe only these 40 source files. They are not a Windows workflow, backup, release or permission to skip normal CI/Sonar/native gates.
