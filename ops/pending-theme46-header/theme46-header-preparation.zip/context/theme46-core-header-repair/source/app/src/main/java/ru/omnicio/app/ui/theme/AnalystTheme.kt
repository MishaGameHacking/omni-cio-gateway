package ru.omnicio.app.ui.theme

import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.LocalActivity
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import ru.omnicio.app.ui.workspace.*
import ru.omnicio.app.ui.spectrum.LocalSpectrumPalette
import ru.omnicio.app.ui.spectrum.spectrumPalette
import ru.omnicio.app.ui.spectrum.LocalEditorRestorationOwner
import ru.omnicio.app.ui.spatial.SpatialSceneRoot
import ru.omnicio.app.ui.spatial.SpatialMotion
import java.util.UUID

enum class ThemeMode(val title: String) {
    SYSTEM("Как в системе"), LIGHT("Светлая"), DARK("Тёмная");
}

data class ThemePreference(val mode: ThemeMode, val preview: (ThemeMode) -> Unit = {},
    val cancelPreview: () -> Unit = {}, val applyPreview: () -> Unit = {},
    val systemThemeUnavailable: Boolean = false, val select: (ThemeMode) -> Unit)
val LocalThemePreference = staticCompositionLocalOf {
    ThemePreference(ThemeMode.DARK) { }
}

data class SpectrumMotionPreference(
    val enabled: Boolean,
    val select: (Boolean) -> Unit,
)

val LocalSpectrumMotionPreference = staticCompositionLocalOf {
    SpectrumMotionPreference(enabled = true) { }
}

/** Unknown global state keeps the last displayed colors; app configuration is only a fallback. */
internal fun displayedThemeDark(mode: ThemeMode, system: SystemThemeObservation,
    lastDisplayed: Boolean?, appConfigurationDark: Boolean): Boolean = when (mode) {
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
    ThemeMode.SYSTEM -> (system as? SystemThemeObservation.Known)?.dark
        ?: lastDisplayed ?: appConfigurationDark
}

private val AnalystTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 46.sp,
        lineHeight = 52.sp,
        letterSpacing = (-1.2).sp,
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 34.sp,
        lineHeight = 39.sp,
        letterSpacing = (-0.4).sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 33.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 21.sp,
        lineHeight = 27.sp,
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 23.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 17.sp,
        lineHeight = 25.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 22.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 20.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 15.sp,
    ),
)

@Composable
fun AnalystTheme(content: @Composable () -> Unit) {
    if (LocalInspectionMode.current) {
        // The caller supplies in-memory appearance values for an explicit host preview.
        AnalystThemeContent(content)
    } else WorkspacePreferencesProvider { AnalystThemeContent(content) }
}

@Composable
private fun AnalystThemeContent(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val inspection = LocalInspectionMode.current
    val activity = if (inspection) null else LocalActivity.current
    val editorRestorationOwner = remember { UUID.randomUUID().toString() }
    val preferences = remember(context, inspection) {
        if (inspection) null else context.applicationContext.getSharedPreferences("analyst_ai_settings", 0)
    }
    val defaultMode = if (inspection) ThemeMode.SYSTEM else ThemeMode.DARK
    var modeName by rememberSaveable {
        mutableStateOf(
            preferences?.getString("theme_mode", defaultMode.name) ?: defaultMode.name,
        )
    }
    var previewMode by remember { mutableStateOf<ThemeMode?>(null) }
    val mode = previewMode ?: ThemeMode.entries.firstOrNull { it.name == modeName } ?: ThemeMode.DARK
    val workspace = LocalWorkspacePreferences.current
    // The app-local configuration may already contain a saved forced mode.
    // Observe the display's system configuration separately; never call this fallback "known".
    val appConfigurationDark = isSystemInDarkTheme()
    val system = if (inspection) SystemThemeObservation.Known(appConfigurationDark)
        else rememberSystemThemeObservation()
    var lastDisplayedDark by rememberSaveable { mutableStateOf<Boolean?>(null) }
    val dark = displayedThemeDark(mode, system, lastDisplayedDark, appConfigurationDark)
    SideEffect {
        lastDisplayedDark = dark
        (activity as? ComponentActivity)?.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT,
            ) { dark },
            navigationBarStyle = SystemBarStyle.auto(
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT,
            ) { dark },
        )
        activity?.window?.isNavigationBarContrastEnforced = false
    }
    val saveTheme: (ThemeMode) -> Unit = { selected ->
        modeName = selected.name
        previewMode = null
        preferences?.edit()?.putString("theme_mode", selected.name)?.apply()
        if (!inspection) syncSavedApplicationTheme(context.applicationContext, selected)
    }
    val themePreference = ThemePreference(mode, preview = { previewMode = it }, cancelPreview = { previewMode = null },
        applyPreview = { previewMode?.let(saveTheme) },
        systemThemeUnavailable = mode == ThemeMode.SYSTEM && system is SystemThemeObservation.Unknown,
        select = saveTheme)
    val motionPreference = SpectrumMotionPreference(workspace.value.motion != MotionLevel.OFF) { enabled ->
        workspace.update(workspace.value.copy(motion = if (enabled) MotionLevel.LIVE else MotionLevel.OFF))
        preferences?.edit()?.putBoolean("spectrum_motion", enabled)?.apply()
    }
    val palette = remember(dark, workspace.value.accent) { spectrumPalette(dark, workspace.value.accent) }
    val colors = palette.colors
    CompositionLocalProvider(
        LocalEditorRestorationOwner provides editorRestorationOwner,
        LocalThemePreference provides themePreference,
        LocalSystemThemeObservation provides system,
        LocalSpectrumMotionPreference provides motionPreference,
        LocalSpectrumPalette provides palette,
    ) {
        MaterialTheme(
            colorScheme = colors,
            typography = AnalystTypography,
        ) {
            // Transparent scaffolds and text outside cards must not inherit the
            // framework's default black LocalContentColor in the dark theme.
            CompositionLocalProvider(
                LocalContentColor provides MaterialTheme.colorScheme.onBackground,
                LocalTextSelectionColors provides TextSelectionColors(
                    handleColor = colors.primary, backgroundColor = colors.primaryContainer),
            ) {
                SpatialSceneRoot(modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                    motion = when (workspace.value.motion) { MotionLevel.LIVE -> SpatialMotion.Live; MotionLevel.SUBDUED -> SpatialMotion.Subdued; MotionLevel.OFF -> SpatialMotion.Off },
                    tactile = workspace.value.haptics, opaque = workspace.value.brightLight,
                    navigationProgress = LocalWorkspaceBackProgress.current) { content() }
            }
        }
    }
}
