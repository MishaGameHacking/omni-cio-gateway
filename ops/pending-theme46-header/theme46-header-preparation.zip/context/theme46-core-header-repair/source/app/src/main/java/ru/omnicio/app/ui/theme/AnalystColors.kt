package ru.omnicio.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import ru.omnicio.app.ui.workspace.AccentStyle

/** Extra semantic colors stay independent of a user's selected action accent. */
@Immutable
data class AnalystSemanticColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val info: Color,
    val onInfo: Color,
    val infoContainer: Color,
    val onInfoContainer: Color,
    val disabledInk: Color,
    val disabledContainer: Color,
    val chartGrid: Color,
    val chartAxis: Color,
    val chartSeparator: Color,
    val chartSelectedInner: Color,
    val chartSelectedOuter: Color,
)

@Immutable
data class AnalystColorSet(
    val material: ColorScheme,
    val semantic: AnalystSemanticColors,
    val chartSeries: List<Color>,
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF006B65),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD6F0EB),
    onPrimaryContainer = Color(0xFF103E3A),
    inversePrimary = Color(0xFF80D1C5),
    secondary = Color(0xFF315F82),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDEEBF5),
    onSecondaryContainer = Color(0xFF153B55),
    tertiary = Color(0xFF65538C),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEDE5F6),
    onTertiaryContainer = Color(0xFF392755),
    background = Color(0xFFF5F7F9),
    onBackground = Color(0xFF1B2930),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B2930),
    surfaceVariant = Color(0xFFE5ECEF),
    onSurfaceVariant = Color(0xFF4C606A),
    surfaceTint = Color(0xFF006B65),
    inverseSurface = Color(0xFF293940),
    inverseOnSurface = Color(0xFFEAF1F4),
    error = Color(0xFFAA3440),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFDE6E8),
    onErrorContainer = Color(0xFF731E2A),
    outline = Color(0xFF607680),
    outlineVariant = Color(0xFFBDC9D0),
    scrim = Color(0xFF102026),
    surfaceBright = Color(0xFFFFFFFF),
    surfaceDim = Color(0xFFDCE5EA),
    surfaceContainer = Color(0xFFEDF2F5),
    surfaceContainerHigh = Color(0xFFE7EEF2),
    surfaceContainerHighest = Color(0xFFDEE7EC),
    surfaceContainerLow = Color(0xFFF1F5F7),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    primaryFixed = Color(0xFFD6F0EB),
    primaryFixedDim = Color(0xFFA3D8CE),
    onPrimaryFixed = Color(0xFF0B3934),
    onPrimaryFixedVariant = Color(0xFF215E57),
    secondaryFixed = Color(0xFFDEEBF5),
    secondaryFixedDim = Color(0xFFB7D3E8),
    onSecondaryFixed = Color(0xFF12354D),
    onSecondaryFixedVariant = Color(0xFF285475),
    tertiaryFixed = Color(0xFFEDE5F6),
    tertiaryFixedDim = Color(0xFFD2C1E7),
    onTertiaryFixed = Color(0xFF322047),
    onTertiaryFixedVariant = Color(0xFF574579),
)

private val LightSemantic = AnalystSemanticColors(
    success = Color(0xFF206C47),
    onSuccess = Color(0xFFFFFFFF),
    successContainer = Color(0xFFE0F1E6),
    onSuccessContainer = Color(0xFF174B32),
    warning = Color(0xFF835400),
    onWarning = Color(0xFFFFFFFF),
    warningContainer = Color(0xFFFFF0D6),
    onWarningContainer = Color(0xFF5C3A00),
    info = Color(0xFF315F82),
    onInfo = Color(0xFFFFFFFF),
    infoContainer = Color(0xFFDEEBF5),
    onInfoContainer = Color(0xFF153B55),
    disabledInk = Color(0xFF687A82),
    disabledContainer = Color(0xFFE5ECEF),
    chartGrid = Color(0xFFBDC9D0),
    chartAxis = Color(0xFF607680),
    chartSeparator = Color(0xFFFFFFFF),
    chartSelectedInner = Color(0xFFFFFFFF),
    chartSelectedOuter = Color(0xFF1B2930),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF80D1C5),
    onPrimary = Color(0xFF003B36),
    primaryContainer = Color(0xFF164D47),
    onPrimaryContainer = Color(0xFFBAEDE3),
    inversePrimary = Color(0xFF006B65),
    secondary = Color(0xFF9BC8EA),
    onSecondary = Color(0xFF123A55),
    secondaryContainer = Color(0xFF284B63),
    onSecondaryContainer = Color(0xFFD4E9F8),
    tertiary = Color(0xFFC9B7E9),
    onTertiary = Color(0xFF392754),
    tertiaryContainer = Color(0xFF51406E),
    onTertiaryContainer = Color(0xFFEDE2FF),
    background = Color(0xFF101A1F),
    onBackground = Color(0xFFE7EFF2),
    surface = Color(0xFF172329),
    onSurface = Color(0xFFE7EFF2),
    surfaceVariant = Color(0xFF2D424B),
    onSurfaceVariant = Color(0xFFB5C5CD),
    surfaceTint = Color(0xFF80D1C5),
    inverseSurface = Color(0xFFDFE8ED),
    inverseOnSurface = Color(0xFF24363E),
    error = Color(0xFFF2A9AD),
    onError = Color(0xFF5E1722),
    errorContainer = Color(0xFF6B2C36),
    onErrorContainer = Color(0xFFFFDADF),
    outline = Color(0xFF829BA6),
    outlineVariant = Color(0xFF405862),
    scrim = Color(0xFF050C10),
    surfaceBright = Color(0xFF324750),
    surfaceDim = Color(0xFF101A1F),
    surfaceContainer = Color(0xFF1E2E35),
    surfaceContainerHigh = Color(0xFF25373F),
    surfaceContainerHighest = Color(0xFF2D424B),
    surfaceContainerLow = Color(0xFF19272E),
    surfaceContainerLowest = Color(0xFF0C151A),
    primaryFixed = Color(0xFFD6F0EB),
    primaryFixedDim = Color(0xFFA3D8CE),
    onPrimaryFixed = Color(0xFF0B3934),
    onPrimaryFixedVariant = Color(0xFF215E57),
    secondaryFixed = Color(0xFFDEEBF5),
    secondaryFixedDim = Color(0xFFB7D3E8),
    onSecondaryFixed = Color(0xFF12354D),
    onSecondaryFixedVariant = Color(0xFF285475),
    tertiaryFixed = Color(0xFFEDE5F6),
    tertiaryFixedDim = Color(0xFFD2C1E7),
    onTertiaryFixed = Color(0xFF322047),
    onTertiaryFixedVariant = Color(0xFF574579),
)

private val DarkSemantic = AnalystSemanticColors(
    success = Color(0xFF88D2A5),
    onSuccess = Color(0xFF123D29),
    successContainer = Color(0xFF254B36),
    onSuccessContainer = Color(0xFFC7EFD6),
    warning = Color(0xFFE8C078),
    onWarning = Color(0xFF473000),
    warningContainer = Color(0xFF5A431A),
    onWarningContainer = Color(0xFFFFE1A6),
    info = Color(0xFF9BC8EA),
    onInfo = Color(0xFF123A55),
    infoContainer = Color(0xFF284B63),
    onInfoContainer = Color(0xFFD4E9F8),
    disabledInk = Color(0xFF93A8B2),
    disabledContainer = Color(0xFF25373F),
    chartGrid = Color(0xFF405862),
    chartAxis = Color(0xFF829BA6),
    chartSeparator = Color(0xFF172329),
    chartSelectedInner = Color(0xFF101A1F),
    chartSelectedOuter = Color(0xFFE7EFF2),
)

/** All 48 Material roles are explicit; no wallpaper or default palette is merged. */
fun analystColors(dark: Boolean, accent: AccentStyle = AccentStyle.AURORA): AnalystColorSet {
    val base = if (dark) DarkColors else LightColors
    val opposite = if (dark) LightColors else DarkColors
    val semantic = if (dark) DarkSemantic else LightSemantic
    val colors = when (accent) {
        AccentStyle.AURORA -> base
        AccentStyle.OCEAN -> base.copy(
            primary = base.secondary, onPrimary = base.onSecondary,
            primaryContainer = base.secondaryContainer, onPrimaryContainer = base.onSecondaryContainer,
            inversePrimary = opposite.secondary, surfaceTint = base.secondary,
            primaryFixed = base.secondaryFixed, primaryFixedDim = base.secondaryFixedDim,
            onPrimaryFixed = base.onSecondaryFixed, onPrimaryFixedVariant = base.onSecondaryFixedVariant,
        )
        AccentStyle.IRIS -> base.copy(
            primary = base.tertiary, onPrimary = base.onTertiary,
            primaryContainer = base.tertiaryContainer, onPrimaryContainer = base.onTertiaryContainer,
            inversePrimary = opposite.tertiary, surfaceTint = base.tertiary,
            primaryFixed = base.tertiaryFixed, primaryFixedDim = base.tertiaryFixedDim,
            onPrimaryFixed = base.onTertiaryFixed, onPrimaryFixedVariant = base.onTertiaryFixedVariant,
        )
    }
    return AnalystColorSet(colors, semantic,
        listOf(base.secondary, semantic.success, base.tertiary, semantic.warning, base.error, base.primary))
}

/** Actual state-layer composition; callers retain the foreground paired to the fill. */
internal fun analystPressedColor(fill: Color, foreground: Color, opacity: Float = .08f): Color =
    foreground.copy(alpha = opacity).compositeOver(fill)
