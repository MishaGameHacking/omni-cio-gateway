package ru.omnicio.app.ui.theme

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DisplayedThemeTest {
    private val unavailable = SystemThemeObservation.Unknown(SystemThemeUnavailableReason.CONTEXT_UNAVAILABLE)

    @Test
    fun aKnownSystemObservationOverridesTheOppositeSavedApplicationConfiguration() {
        assertFalse(displayedThemeDark(ThemeMode.SYSTEM, SystemThemeObservation.Known(false), true, true))
        assertTrue(displayedThemeDark(ThemeMode.SYSTEM, SystemThemeObservation.Known(true), false, false))
    }

    @Test
    fun anUnavailableSystemSourceKeepsTheLastActuallyDisplayedColors() {
        assertFalse(displayedThemeDark(ThemeMode.SYSTEM, unavailable, false, true))
        assertTrue(displayedThemeDark(ThemeMode.SYSTEM, unavailable, true, false))
    }

    @Test
    fun onlyAnUninitializedDisplayUsesTheExplicitApplicationFallback() {
        assertFalse(displayedThemeDark(ThemeMode.SYSTEM, unavailable, null, false))
        assertTrue(displayedThemeDark(ThemeMode.SYSTEM, unavailable, null, true))
        assertTrue(displayedThemeDark(ThemeMode.SYSTEM,
            SystemThemeObservation.Unknown(SystemThemeUnavailableReason.INITIALIZING), true, false))
    }

    @Test
    fun explicitLightAndDarkNeverDependOnAnUnavailableSystemSource() {
        assertFalse(displayedThemeDark(ThemeMode.LIGHT, unavailable, true, true))
        assertTrue(displayedThemeDark(ThemeMode.DARK, unavailable, false, false))
    }
}
