"""Read production Kotlin tokens; unrelated passing example colors are not evidence."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[3]
UI = ROOT / 'app/src/main/java/ru/omnicio/app/ui'


def luminance(rgb):
    linear = [c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4 for c in rgb]
    return sum(c * weight for c, weight in zip(linear, (.2126, .7152, .0722)))

def rgb(expression):
    if expression == 'Color.White':
        return (1.0, 1.0, 1.0)
    match = re.fullmatch(r'Color\(0xFF([0-9A-Fa-f]{6})\)', expression)
    if match is None:
        raise AssertionError('Expected a production opaque color literal')
    value = match.group(1)
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4))


def colors(source, declaration):
    block = source.split(declaration, 1)[1].split('\n)', 1)[0]
    return {name: rgb(value) for name, value in re.findall(
        r'\b(\w+)\s*=\s*(Color\(0xFF[0-9A-Fa-f]{6}\)|Color\.White)', block)}


def contrast(first, second):
    high, low = sorted((luminance(first), luminance(second)), reverse=True)
    return (high + .05) / (low + .05)


class SpectrumProductionTokens(unittest.TestCase):

    def test_actual_theme_accents_and_component_text_have_readable_contrast(self):
        source = (UI / 'spectrum/SpectrumDesignSystem.kt').read_text(encoding='utf-8')
        theme = (UI / 'theme/AnalystTheme.kt').read_text(encoding='utf-8')
        tokens = (UI / 'theme/AnalystColors.kt').read_text(encoding='utf-8')
        schemes = {
            'light': colors(tokens, 'private val LightColors = lightColorScheme('),
            'dark': colors(tokens, 'private val DarkColors = darkColorScheme('),
        }
        semantic = {
            'light': colors(tokens, 'private val LightSemantic = AnalystSemanticColors('),
            'dark': colors(tokens, 'private val DarkSemantic = AnalystSemanticColors('),
        }
        roles = set('primary onPrimary primaryContainer onPrimaryContainer inversePrimary '
            'secondary onSecondary secondaryContainer onSecondaryContainer '
            'tertiary onTertiary tertiaryContainer onTertiaryContainer '
            'background onBackground surface onSurface surfaceVariant onSurfaceVariant surfaceTint '
            'inverseSurface inverseOnSurface error onError errorContainer onErrorContainer outline outlineVariant '
            'scrim surfaceBright surfaceDim surfaceContainer surfaceContainerHigh surfaceContainerHighest '
            'surfaceContainerLow surfaceContainerLowest primaryFixed primaryFixedDim onPrimaryFixed onPrimaryFixedVariant '
            'secondaryFixed secondaryFixedDim onSecondaryFixed onSecondaryFixedVariant '
            'tertiaryFixed tertiaryFixedDim onTertiaryFixed onTertiaryFixedVariant'.split())
        self.assertEqual(len(roles), 48)
        self.assertIn('spectrumPalette(dark, workspace.value.accent)', theme)
        self.assertIn('val colors = palette.colors', theme)
        self.assertIn('colorScheme = colors', theme)
        self.assertIn('val resolved = analystColors(dark, accent)', source)
        self.assertIn('SpectrumPalette(resolved.material, resolved.semantic, resolved.chartSeries)', source)
        self.assertIn('val blue: Color get() = semantic.info', source)
        self.assertNotIn('copy(cyan = color, blue = color, violet = color)', theme)
        accent_block = tokens.split('val colors = when (accent) {', 1)[1].split('\n    }', 1)[0]
        self.assertCountEqual(re.findall(r'AccentStyle\.(\w+)\s*->', accent_block),
                              ['AURORA', 'OCEAN', 'IRIS'])
        self.assertIn('AccentStyle.AURORA -> base', accent_block)
        mappings = {'AURORA': {}}
        for accent, family in (('OCEAN', 'secondary'), ('IRIS', 'tertiary')):
            branch = re.search(r'AccentStyle\.' + accent + r'\s*-> base\.copy\((.*?)\n\s*\)',
                               accent_block, re.DOTALL)
            self.assertIsNotNone(branch, accent)
            mapping = {target: (origin, key) for target, origin, key in re.findall(
                r'(\w+)\s*=\s*(base|opposite)\.(\w+)', branch.group(1))}
            self.assertEqual(set(mapping), {'primary', 'onPrimary', 'primaryContainer', 'onPrimaryContainer',
                'inversePrimary', 'surfaceTint', 'primaryFixed', 'primaryFixedDim', 'onPrimaryFixed', 'onPrimaryFixedVariant'})
            self.assertEqual(mapping['primary'], ('base', family))
            self.assertEqual(mapping['inversePrimary'], ('opposite', family))
            self.assertEqual(mapping['primaryFixed'], ('base', family + 'Fixed'))
            mappings[accent] = mapping

        actual = {}
        for mode in ('light', 'dark'):
            with self.subTest(mode=mode):
                self.assertEqual(set(schemes[mode]), roles)
                actual[mode] = {}
                for accent, mapping in mappings.items():
                    with self.subTest(accent=accent):
                        c = dict(schemes[mode])
                        opposite = schemes['dark' if mode == 'light' else 'light']
                        c.update({target: (schemes[mode] if origin == 'base' else opposite)[key]
                                  for target, (origin, key) in mapping.items()})
                        actual[mode][accent] = c
                        for prefix in ('Primary', 'Secondary', 'Tertiary', 'Error'):
                            role = prefix[0].lower() + prefix[1:]
                            self.assertGreaterEqual(contrast(c['on' + prefix], c[role]), 4.5)
                            self.assertGreaterEqual(contrast(c['on' + prefix + 'Container'], c[role + 'Container']), 4.5)
                        for ink in ('onPrimaryFixed', 'onPrimaryFixedVariant'):
                            for fill in ('primaryFixed', 'primaryFixedDim'):
                                self.assertGreaterEqual(contrast(c[ink], c[fill]), 4.5)
                self.assertGreaterEqual(contrast(schemes[mode]['background'], schemes[mode]['onBackground']), 4.5)
                for card in ('surface', 'surfaceContainerHighest'):
                    for ink in ('onSurface', 'onSurfaceVariant'):
                        self.assertGreaterEqual(contrast(schemes[mode][card], schemes[mode][ink]), 4.5)
                for name in ('Success', 'Warning', 'Info'):
                    role = name[0].lower() + name[1:]
                    self.assertGreaterEqual(contrast(semantic[mode]['on' + name], semantic[mode][role]), 4.5)
                    self.assertGreaterEqual(contrast(semantic[mode]['on' + name + 'Container'], semantic[mode][role + 'Container']), 4.5)
        for accent in mappings:
            for key in ('primaryFixed', 'primaryFixedDim', 'onPrimaryFixed', 'onPrimaryFixedVariant'):
                self.assertEqual(actual['light'][accent][key], actual['dark'][accent][key])

        button = source.split('fun SpectrumPrimaryButton(', 1)[1].split(
            '\n@Composable\nfun SpectrumSecondaryButton', 1)[0]
        self.assertIn('color = if (enabled) MaterialTheme.colorScheme.primary else LocalSpectrumPalette.current.semantic.disabledContainer', button)
        self.assertIn('Text(text, color = if (enabled) MaterialTheme.colorScheme.onPrimary else LocalSpectrumPalette.current.semantic.disabledInk', button)
        self.assertIn('tint = if (enabled) MaterialTheme.colorScheme.onPrimary else LocalSpectrumPalette.current.semantic.disabledInk', button)
        self.assertIn('colorMode = SpatialColorMode.Monochrome', button)
        self.assertIn('role = Role.Button', button)
        self.assertIn('heightIn(min = 54.dp)', button)
        self.assertNotIn('Color.White', button)
        surface = (UI / 'spatial/SpatialComponents.kt').read_text(encoding='utf-8')
        self.assertIn('.clip(shape).background(fill).border(borderWidth, border, shape)', surface)
        self.assertIn('spatialSurfaceColors(palette, color, state', surface)
        self.assertIn('LocalContentColor provides resolved.foreground', surface)
        self.assertNotIn('drawnModels', surface)
        # Token/input contrast does not replace actual light/dark runtime captures.

    def test_real_date_picker_uses_explicit_readable_calendar_state_roles(self):
        caller = (UI / 'portfolio/AccountDataState.kt').read_text(encoding='utf-8')
        factory = (UI / 'spectrum/SpectrumCalendarColors.kt').read_text(encoding='utf-8')
        tokens = (UI / 'theme/AnalystColors.kt').read_text(encoding='utf-8')
        self.assertIn('colors = ru.omnicio.app.ui.spectrum.spectrumDatePickerColors()', caller)
        self.assertIn('utcTimeMillis <= todayMillis', caller)
        self.assertIn('year <= today.year', caller)
        self.assertIn('val c = MaterialTheme.colorScheme', factory)
        self.assertIn('val s = LocalSpectrumPalette.current.semantic', factory)
        block = factory.split('return DatePickerDefaults.colors(', 1)[1].split('dateTextFieldColors =', 1)[0]
        bindings = {name: (kind, role) for name, kind, role in re.findall(r'(\w+)\s*=\s*(c|s)\.(\w+)', block)}
        self.assertEqual(len(bindings), 24)
        for state in ('Day', 'Year'):
            self.assertEqual(bindings['disabled' + state + 'ContentColor'], ('s', 'disabledInk'))
            self.assertEqual(bindings['disabledSelected' + state + 'ContentColor'], ('s', 'disabledInk'))
            self.assertEqual(bindings['disabledSelected' + state + 'ContainerColor'], ('s', 'disabledContainer'))
        for mode in ('Light', 'Dark'):
            source = {'c': colors(tokens, 'private val ' + mode + 'Colors = ' + mode.lower() + 'ColorScheme('),
                      's': colors(tokens, 'private val ' + mode + 'Semantic = AnalystSemanticColors(')}
            actual = {name: source[kind][role] for name, (kind, role) in bindings.items()}
            for state in ('Day', 'Year'):
                self.assertGreaterEqual(contrast(actual['selected' + state + 'ContentColor'],
                                                 actual['selected' + state + 'ContainerColor']), 4.5)
                self.assertGreaterEqual(contrast(actual['disabledSelected' + state + 'ContentColor'],
                                                 actual['disabledSelected' + state + 'ContainerColor']), 3)
                self.assertGreaterEqual(contrast(actual['disabled' + state + 'ContentColor'], actual['containerColor']), 3)
            self.assertGreaterEqual(contrast(actual['dayInSelectionRangeContentColor'],
                                             actual['dayInSelectionRangeContainerColor']), 4.5)

    def test_portfolio_uses_new_presenter_and_live_position_resolution(self):
        screen = (UI / 'portfolio/PortfolioScreen.kt').read_text(encoding='utf-8')
        dashboard = (UI / 'portfolio/PortfolioDashboard.kt').read_text(encoding='utf-8')
        self.assertIn('PortfolioDashboard(', screen)
        self.assertIn('resolveSelectedPosition(', screen)
        self.assertNotIn('AccountPreviewCard(', screen)
        self.assertIn('listOf("Структура", "Активы", "Динамика")', dashboard)
        self.assertIn('AccountAnalytics(accessToken, account, historyOnly = true)', dashboard)
        self.assertIn('AssetStructure(snapshot.allocations, snapshot.totalValue)', dashboard)
        self.assertNotIn('PortfolioSnapshot(', dashboard)

    def test_history_keeps_validated_real_points_and_value_table(self):
        source = (UI / 'portfolio/HistoryChart.kt').read_text(encoding='utf-8')
        geometry = (UI / 'portfolio/HistoryBars.kt').read_text(encoding='utf-8')
        self.assertIn('portfolioHistory(points)', geometry)
        self.assertIn('val selectedPoint = historySelectedObservation(model, selected, selectedObservation)', source)
        self.assertIn('HistoryValues(model.source.coordinates, currency, selectedStart, selectedPoint?.date)', source)
        self.assertIn('selectedInstant?.let { sameHistoryInstant(point.date, it) } == true', source)
        self.assertIn('onSelect(point.date)', source)
        self.assertIn('SpatialBars(model.bars.map { it.close?.value?.toDouble() }', source)
        self.assertIn('model.source.low.toDouble(), model.source.high.toDouble()', source)
        self.assertNotIn('drawRoundRect(', source)
        self.assertNotIn('drawPath(', source)
        self.assertNotIn('Random', source)


if __name__ == '__main__':
    unittest.main()
