# Native46: initial global night policy — read-only finding and optional contract

2026-10-26. No application/test execution. Frozen native46 generator remains
SHA256 `fd11f280bc20febbcd480ac458e9958d70b9be81fea66b67237533b1b9a01c0f`.
No wrapper, renderer change or additional tests are proposed for application now.

## Observed44 evidence

Actual native44 run40287655859 used a newly created owned API37/16384 AVD.
`runtime-console.log` records system image `google_apis_ps16k`, revision7,
fingerprint `google/sdk_gphone16k_x86_64/emu64xa16k:17/CE2A.260420.050/16231978:userdebug/dev-keys`,
and initial storage layout `data-directory`, 68,549 source bytes. The runtime
creates the AVD with avdmanager and uses `-no-snapshot`; `configure_userdata`
changes only partition capacity and software navigation.

The source data directory, framework resource overlays and Settings.Secure
values were not retained in these artifacts. The actual global result of
`cmd uimode night` at hook entry is **unknown**. Hook44 reads it into a local
variable but never writes it to its JSON or log. No before-hook yes/no setter
exists in the inspected runtime, setup or frame-session flow. The seven
inspected runtime/profile/setup files matched actual44 source-final SHA256
`632690ecf7bca6a54b6f569567c6b6dbf7bfe0dab22b999e8bfa70ee74e94e67`.

The upstream AOSP base resource currently defaults to1 (`no`), and the service
loads the saved secure mode with that resource as fallback. That is source
context, not proof of this Google API37 image's resource overrides or saved
state. App screenshots and effective Activity configuration are not global
policy evidence. No actual auto/custom failure has been observed.

## Optional follow-up only if a real initial policy requires it

1. Keep frozen46 unchanged until the actual policy is observed. Record the
   strict command result before original14; never replace unknown output
   with `auto` or infer it from UI colors.
2. If an explicit test fixture is needed, declare its chosen yes/no policy
   in the administrative run request and provenance. It must apply only to
   the new disposable AVD, under the unchanged canonical lease, after exact
   current host-PID AVD name, qemu/API37, primary-user and live frame-session
   ownership checks. Preserve source/APK admission and all UI assertions.
3. Before any setter, durably record the original policy and finite global
   activation state. Admit plain auto only if no activation or attention/dock
   overrides exist; otherwise stop before writes. Custom schedule/bedtime
   needs its own restoration contract and must not be silently generalized.
4. Set the declared policy and require a real command/service read-back before
   the original hook's admission/snapshot. Keep this initialization receipt
   distinct from application and lifecycle acceptance.
5. In `finally`, attempt restoration even after partial setter or UI failure;
   first revalidate the same owned transport. Read back the exact original
   policy and admitted override state. Do not claim the time-dependent auto
   computed value or every secure-setting byte was restored. The unchanged
   runtime must still stop and remove its owned disposable AVD.
6. Any future collector must require the independent final restoration receipt;
   cleanup errors cannot be hidden behind the diagnostic full-suite sentinel.
   Actual native evidence and reviewed Windows checks are prerequisites before
   adopting such an administrative follow-up.

No initialization has been applied. A prepared wrapper draft was removed when
root narrowed this task to this contract; it was never imported or executed.

## Primary source context

- [AOSP base resource config](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/res/res/values/config.xml), inspected blob `37ad78a2b83c9f93d257890d8a927a10a771ad9c`.
- [AOSP UiModeManagerService](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/core/java/com/android/server/UiModeManagerService.java), inspected blob `896c9b8d0932a2860acf8250826cd752f87a0428`: saved-policy fallback, global override reset, dump fields.
- [AOSP UiModeManager constants](https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/app/UiModeManager.java): attention-overlay OFF is1000, not0.
- Local actual evidence: `context/native44-original14/`; pinned hook/runtime: `context/native44-bound/`; current strict guard: `context/prepare_native46.py`.
