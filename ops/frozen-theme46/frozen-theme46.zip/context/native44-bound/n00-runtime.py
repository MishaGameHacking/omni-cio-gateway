import datetime,hashlib,json,os,pathlib,shutil,stat,subprocess,sys,tempfile,time,zipfile,ctypes
from ctypes import wintypes
BASE_COMMIT = '1cc05586b6874bfdd0cdb80131d178de9f95870c'
SOURCE_HASH = 'e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9'
PATCH_HASH = None
SOURCE_EVIDENCE = {'.github/scripts/portfolio_chart_probe.py': {'bytes': 17520, 'sha256': '4751548957aed5bd7350c4e4442ca0b253decf2ea39b178067c2763a1a9dedcb'}, '.github/scripts/portfolio_preferences_probe.py': {'bytes': 5842, 'sha256': 'be9f1e23e1e41b2aeedd06de7d7436ca341221a317b21010d8d59ea4f5008071'}, '.github/scripts/portfolio_research_probe.py': {'bytes': 17730, 'sha256': '500eadc99d029c90087bdb93fd404780c20bf0f62b6a292e38ea7e87b45790d7'}, '.github/scripts/tests/test_android17_live_spectrum.py': {'bytes': 7591, 'sha256': '4d6667c97d48a70ee6708f01420416f044e29e81897fc34b67bd63bd8e315d34'}, '.github/scripts/tests/test_portfolio_appearance_reset_state.py': {'bytes': 6418, 'sha256': '6901b2538443fa35b76a75c8dbd1701f2bdfb956800306360821129d02a4b9ed'}, '.github/scripts/tests/test_portfolio_controls_evidence.py': {'bytes': 35579, 'sha256': '16400d652562444ff8912545cb688604f8b2995188f82955b6b9e8b726c230c4'}, '.github/scripts/tests/test_portfolio_dossier_long_metrics.py': {'bytes': 7960, 'sha256': '784739d023c30718fe29fdd022017a82e4180f0edb51ac7a3f2a2cfe28e7a1a7'}, '.github/scripts/tests/test_portfolio_preferences_traversal.py': {'bytes': 8738, 'sha256': '01b934d2a8052ed3cfdc364db2347f00bab5c1de0decef923203f2df65fc61a3'}, '.github/scripts/tests/test_portfolio_research_traversal.py': {'bytes': 36533, 'sha256': 'eaaf6ad010d0b5c5c720cc07926d6a1d0a5319c39382c554bca623978f0aa8a9'}, '.github/scripts/tests/test_spectrum_brand_identity.py': {'bytes': 4023, 'sha256': '83851aa9b8c4f68ff6f92f009c312cef430af403422c4c5d7080463f624c670d'}, 'app/build.gradle.kts': {'bytes': 2450, 'sha256': '34117cdcb29bca951e4d57c0ad34adfe6a09da2f47fcd791e487c3a5276a3c3a'}, 'app/src/debug/java/ru/omnicio/app/BusinessWorkspaceProbe.kt': {'bytes': 50361, 'sha256': 'c23119ba4c49f71206ba3e76cb01a114de393eb4ea705a11f9b4773e4276235f'}, 'app/src/debug/java/ru/omnicio/app/PortfolioWorkspaceProbe.kt': {'bytes': 14619, 'sha256': '43843b391a534a6add46bb218226fdbcd67d14e3df5b74d983ae667db6b79202'}, 'app/src/main/java/ru/omnicio/app/ui/workspace/AssistantWorkspaceScreen.kt': {'bytes': 34811, 'sha256': '850c9dc8431ed33859fd89ac7505ffaaae7b95b1e76894f5f6cbbc6383f8b872'}, 'app/src/main/java/ru/omnicio/app/ui/workspace/ResearchLibraryScreen.kt': {'bytes': 12010, 'sha256': '22f68c7013a9357b55058beae05898db25dcf6ba6dd9baf4fa3483abc1fd793a'}}
BUILD_PROVENANCE = {'build_report_sha256': '808a43afb0585b3cf2cd9519d54c525f51be4d66fa239e3d9c4c4257d2eafd40', 'build_run_id': 40282775349, 'build_run_attempt': 1, 'build_workflow_sha': '07e291f9efd6ba6b1be96ead7d3b42340776ffce', 'build_status': 'passed_check_and_build_only', 'host': 'LAPTOP-NPSGA016', 'root': 'C:\\actions-runner-3\\_work\\omni-cio-gateway\\omni-cio-gateway\\windows-development-40282775349-1', 'state': 'C:\\actions-runner-3\\_work\\_temp\\analyst-development-40282775349-1', 'build_base_commit': '043e1da910da2fcf952cc00c46d0e81a761076ea', 'source_backup_commit': '1cc05586b6874bfdd0cdb80131d178de9f95870c', 'source_sha256': 'e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9', 'complete_build_source_sha256': '69c10c8d65c0559b58d45231390cd0e84dc681df3f7dbaed3d0a5ee716c20fe6', 'build_export_receipt_sha256': 'aea3b2586adf4f62304bb66495e154c0c015b45ebbaed7dca6f04157f7ef6c43', 'build_archive': {'bytes': 68927139, 'sha256': 'f8dd107e1714fcc1a3aeed4afd25b6d9efa3dca878b7106191f3fd77e4fa1b89'}, 'preview_version_code': 44, 'preview_version_name': '0.13.6-preview', 'input_apks': {'app/build/outputs/apk/preview/app-preview.apk': [29771254, 'f0af0b45515143f8abb2c28e73d0d484acde5c6a36e18de1b398692bc45a4cf6'], 'app/build/outputs/apk/debug/app-debug.apk': [63292529, '9b3fb5a1c779ba162249f11b870aba6a57f4b65c6d624fa8808760f1b2779878'], 'ci-ui-driver/build/outputs/apk/debug/ci-ui-driver-debug.apk': [2683192, '7fb9ad4121c2a1e981cacc611522941122c9fe3178e2eeb3849683200f3c7705']}, 'candidate_source_files': {'.github/scripts/portfolio_chart_probe.py': {'bytes': 17520, 'sha256': '4751548957aed5bd7350c4e4442ca0b253decf2ea39b178067c2763a1a9dedcb'}, '.github/scripts/portfolio_preferences_probe.py': {'bytes': 5842, 'sha256': 'be9f1e23e1e41b2aeedd06de7d7436ca341221a317b21010d8d59ea4f5008071'}, '.github/scripts/portfolio_research_probe.py': {'bytes': 17730, 'sha256': '500eadc99d029c90087bdb93fd404780c20bf0f62b6a292e38ea7e87b45790d7'}, '.github/scripts/tests/test_android17_live_spectrum.py': {'bytes': 7591, 'sha256': '4d6667c97d48a70ee6708f01420416f044e29e81897fc34b67bd63bd8e315d34'}, '.github/scripts/tests/test_portfolio_appearance_reset_state.py': {'bytes': 6418, 'sha256': '6901b2538443fa35b76a75c8dbd1701f2bdfb956800306360821129d02a4b9ed'}, '.github/scripts/tests/test_portfolio_controls_evidence.py': {'bytes': 35579, 'sha256': '16400d652562444ff8912545cb688604f8b2995188f82955b6b9e8b726c230c4'}, '.github/scripts/tests/test_portfolio_dossier_long_metrics.py': {'bytes': 7960, 'sha256': '784739d023c30718fe29fdd022017a82e4180f0edb51ac7a3f2a2cfe28e7a1a7'}, '.github/scripts/tests/test_portfolio_preferences_traversal.py': {'bytes': 8738, 'sha256': '01b934d2a8052ed3cfdc364db2347f00bab5c1de0decef923203f2df65fc61a3'}, '.github/scripts/tests/test_portfolio_research_traversal.py': {'bytes': 36533, 'sha256': 'eaaf6ad010d0b5c5c720cc07926d6a1d0a5319c39382c554bca623978f0aa8a9'}, '.github/scripts/tests/test_spectrum_brand_identity.py': {'bytes': 4023, 'sha256': '83851aa9b8c4f68ff6f92f009c312cef430af403422c4c5d7080463f624c670d'}, 'app/build.gradle.kts': {'bytes': 2450, 'sha256': '34117cdcb29bca951e4d57c0ad34adfe6a09da2f47fcd791e487c3a5276a3c3a'}, 'app/src/debug/java/ru/omnicio/app/BusinessWorkspaceProbe.kt': {'bytes': 50361, 'sha256': 'c23119ba4c49f71206ba3e76cb01a114de393eb4ea705a11f9b4773e4276235f'}, 'app/src/debug/java/ru/omnicio/app/PortfolioWorkspaceProbe.kt': {'bytes': 14619, 'sha256': '43843b391a534a6add46bb218226fdbcd67d14e3df5b74d983ae667db6b79202'}, 'app/src/main/java/ru/omnicio/app/ui/workspace/AssistantWorkspaceScreen.kt': {'bytes': 34811, 'sha256': '850c9dc8431ed33859fd89ac7505ffaaae7b95b1e76894f5f6cbbc6383f8b872'}, 'app/src/main/java/ru/omnicio/app/ui/workspace/ResearchLibraryScreen.kt': {'bytes': 12010, 'sha256': '22f68c7013a9357b55058beae05898db25dcf6ba6dd9baf4fa3483abc1fd793a'}}, 'baseline': {'version_code': 43, 'version_name': '0.13.5-preview', 'bytes': 29771254, 'sha256': '4e9bf0a2fd54d8ab4b9d49ef9ddf96bc14a274ac4c145585fcfdb88d6ae774b6', 'retained_build_run_id': 40277268871, 'publication_run_id': 40280610534}, 'original_portfolio_cases_required': 14, 'full_ui_stage_count': 15, 'diagnostic_only': True, 'release_gate_pass': False, 'full_ui_suite_executed': False, 'publication_authorized': False, 'phone_verified': False}
FILES = {'app/build/outputs/apk/preview/app-preview.apk': [29771254, 'f0af0b45515143f8abb2c28e73d0d484acde5c6a36e18de1b398692bc45a4cf6'], 'app/build/outputs/apk/debug/app-debug.apk': [63292529, '9b3fb5a1c779ba162249f11b870aba6a57f4b65c6d624fa8808760f1b2779878'], 'ci-ui-driver/build/outputs/apk/debug/ci-ui-driver-debug.apk': [2683192, '7fb9ad4121c2a1e981cacc611522941122c9fe3178e2eeb3849683200f3c7705']}
SDK=pathlib.Path(r'C:\actions-runner-2\_work\_tool\AndroidSdk\sdk')
JAVA=pathlib.Path(r'C:\actions-runner-2\_work\_tool\Java_Temurin-Hotspot_jdk\17.0.20-101\x64')
PREVIOUS_HASH='4e9bf0a2fd54d8ab4b9d49ef9ddf96bc14a274ac4c145585fcfdb88d6ae774b6'
BASELINE = pathlib.Path('C:\\actions-runner-3\\_work\\omni-cio-gateway\\omni-cio-gateway\\windows-development-40277268871-1\\app\\build\\outputs\\apk\\preview\\app-preview.apk')
assert __debug__ and sys.platform=='win32' and os.environ.get('COMPUTERNAME')=='LAPTOP-NPSGA016'
ROOT=pathlib.Path(os.environ['SOURCE_ROOT']).resolve(strict=True)
STATE=pathlib.Path(os.environ['RUNNER_TEMP'])/('n00-native44-focused-'+os.environ['GITHUB_RUN_ID']+'-'+os.environ['GITHUB_RUN_ATTEMPT'])
STATE.mkdir(exist_ok=True)
BASE=ROOT/'app/build/outputs/apk/preview'
PREVIOUS=STATE/'previous43.apk'
sys.path[:0]=[str(ROOT),str(ROOT/'.github/scripts')]
def expected_source_hash():return SOURCE_HASH
def need(value, message):
    if not value: raise RuntimeError(message)

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1048576),b''): h.update(data)
    return h.hexdigest()

def regular(path):
    s=path.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not getattr(s,'st_file_attributes',0)&0x400 and not path.is_symlink(),'untrusted_file')
    return s

def source_hash():
    raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT,timeout=45)
    h=hashlib.sha256()
    for name in sorted(set(raw.split(b'\0'))-{b''}):
        rel=name.decode('utf-8');p=ROOT/rel
        if rel in ('AGENTS.md','README.md') or rel.startswith('docs/') or not p.is_file():continue
        regular(p);h.update(name+b'\0'+sha(p).encode()+b'\0')
    return h.hexdigest()

def unchanged():
    need(source_hash()==expected_source_hash(),'source_bytes_changed')
    for rel,identity in SOURCE_EVIDENCE.items():
        path=ROOT/rel;need(regular(path).st_size==identity['bytes'] and sha(path)==identity['sha256'],'candidate_source_evidence_changed')
    for name,(size,digest) in FILES.items():
        p=ROOT/name;need(regular(p).st_size==size and sha(p)==digest,'apk_bytes_changed')
    need(regular(PREVIOUS).st_size==29771254 and sha(PREVIOUS)==PREVIOUS_HASH,'previous_bytes_changed')

def environment():
    env=dict(os.environ)
    for key in list(env):
        if key.startswith(('AI_','ANALYSIS_','TINVEST_','TELEGRAM_','FERNET_','OWNER_','OPENAI_','ANTHROPIC_','TIMEWEB_')) or key in {'GITHUB_TOKEN','GH_TOKEN','ACTIONS_RUNTIME_TOKEN','DATABASE_PATH','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE'}:env.pop(key,None)
    env.update(JAVA_HOME=str(JAVA),JAVA_HOME_17_X64=str(JAVA),PATH=str(JAVA/'bin')+os.pathsep+env['PATH'],ANDROID_SDK_ROOT=str(SDK),ANDROID_HOME=str(SDK),PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8',PYTHONUTF8='1',RUN_PROFILE_UI_TESTS='1',GITHUB_SHA=BASE_COMMIT,GITHUB_WORKSPACE=str(ROOT))
    return env

def profile(page):
    unchanged();work=BASE/('install-api37-'+str(page));need(not work.exists(),'profile_already_exists');work.mkdir(parents=True)
    log=work/'runtime-console.log'
    args=[sys.executable,'-c',"import sys,runpy; assert sys.stdin.buffer.readline(64)==b'WINDOWS_OWNED_JOB_READY\\n'; sys.argv=sys.argv[1:]; import pathlib; sys.path.insert(0,str(pathlib.Path(sys.argv[0]).parent)); runpy.run_path(str(pathlib.Path(__import__('os').environ['RUNNER_TEMP'])/'n00-portfolio-focused-hook.py')); runpy.run_path(sys.argv[0],run_name='__main__')",str(ROOT/'.github/scripts/test_apk_installation.py'),'--sdk',str(SDK),'--apk',str(BASE/'app-preview.apk'),'--previous',str(PREVIOUS),'--api','37','--page-bytes',str(page),'--work-dir',str(work)]
    record={'test_patch_sha256':PATCH_HASH,'test_source_sha256':expected_source_hash(),'page_bytes':page,'started_at':now(),'host':os.environ['COMPUTERNAME'],'apk_sha256':FILES['app/build/outputs/apk/preview/app-preview.apk'][1]}
    job=OwnedJob();process=None
    try:
        with log.open('xb') as out:
            process=subprocess.Popen(args,cwd=ROOT,env=environment(),stdin=subprocess.PIPE,stdout=out,stderr=subprocess.STDOUT)
            job.attach(process);process.stdin.write(b'WINDOWS_OWNED_JOB_READY\n');process.stdin.flush();process.stdin.close()
            record['exit_code']=process.wait(timeout=2700)
        need(record['exit_code']==0,'runtime_failed_'+str(page))
    except BaseException as error:
        record.update(error_type=type(error).__name__,error=str(error)[:500]);raise
    finally:
        try:
            if job.active():job.stop()
            if process is not None:process.wait(timeout=30)
        finally:job.close()
        record['finished_at']=now()
        if page==16384 and (BASE/'ui-screens').exists():shutil.copytree(BASE/'ui-screens',BASE/'ui-screens-api37-16384')
        (STATE/('runtime-'+str(page)+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
        if log.exists():
            with log.open('rb') as src:src.seek(max(0,log.stat().st_size-18000));print(src.read().decode('utf-8',errors='replace'),flush=True)
        unchanged();print('N00_RUNTIME_PROFILE='+json.dumps(record),flush=True)

def export():
    unchanged();entries={}
    for base in [STATE,*[BASE/name for name in ('install-api37-16384','install-api37-4096','ui-screens','ui-screens-api37-16384')]]:
        if not base.exists():continue
        for directory,dirs,names in os.walk(base,followlinks=False):
            dirs[:]=[d for d in dirs if d not in ('avd','.android','android-home','android-user-home')]
            for name in names:
                p=pathlib.Path(directory)/name
                if p.suffix.lower() not in ('.json','.log','.txt','.png','.xml'):continue
                size=regular(p).st_size;need(size<=64*1024**2,'evidence_file_too_large')
                rel=('controller/' if base==STATE else base.name+'/')+p.relative_to(base).as_posix()
                need(rel not in entries,'duplicate_evidence');entries[rel]=(p,{'bytes':size,'sha256':sha(p)})
    for rel,identity in SOURCE_EVIDENCE.items():
        p=ROOT/rel;need(regular(p).st_size==identity['bytes'] and sha(p)==identity['sha256'],'candidate_source_export_changed')
        entries['source/'+rel]=(p,dict(identity))
    need(sum(v[1]['bytes'] for v in entries.values())<450*1024**2,'evidence_too_large')
    envelope={'kind':'n00_candidate44_portfolio_focused','diagnostic_only':True,'release_gate_pass':False,'original_portfolio_cases_required':14,'full_ui_stage_count':15,'build_provenance':BUILD_PROVENANCE,'candidate_source_evidence':SOURCE_EVIDENCE,'full_ui_suite_executed':False,'source_commit':BASE_COMMIT,'base_source_sha256':SOURCE_HASH,'test_patch_sha256':PATCH_HASH,'source_sha256':expected_source_hash(),'input_files':FILES,'created_at':now(),'publication_authorized':False,'phone_verified':False,'files':{n:v[1] for n,v in entries.items()}}
    (STATE/'native44-evidence-envelope.json').write_text(json.dumps(envelope,indent=2),encoding='utf-8')
    path=pathlib.Path(os.environ['RUNNER_TEMP'])/'ci-handoff.zip'
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for name,(p,identity) in entries.items():
            data=p.read_bytes();need(len(data)==identity['bytes'] and hashlib.sha256(data).hexdigest()==identity['sha256'],'evidence_changed');z.writestr(name,data)
        z.writestr('n00-runtime-envelope.json',json.dumps(envelope,sort_keys=True))
    print('N00_RUNTIME_EXPORT='+json.dumps({'bytes':path.stat().st_size,'sha256':sha(path),'files':len(entries)}),flush=True)

class OwnedJob:
    """Only the handshake-blocked worker and its descendants enter this OS job."""
    def __init__(self):
        class Limits(ctypes.Structure):
            _fields_=[("ProcessTime",ctypes.c_longlong),("JobTime",ctypes.c_longlong),("Flags",wintypes.DWORD),("MinWorking",ctypes.c_size_t),("MaxWorking",ctypes.c_size_t),("ActiveLimit",wintypes.DWORD),("Affinity",ctypes.c_size_t),("Priority",wintypes.DWORD),("Scheduling",wintypes.DWORD)]
        class IO(ctypes.Structure): _fields_=[(name,ctypes.c_ulonglong) for name in ("ReadOps","WriteOps","OtherOps","ReadBytes","WriteBytes","OtherBytes")]
        class Extended(ctypes.Structure): _fields_=[("Basic",Limits),("IO",IO),("ProcessMemory",ctypes.c_size_t),("JobMemory",ctypes.c_size_t),("PeakProcess",ctypes.c_size_t),("PeakJob",ctypes.c_size_t)]
        self.api=ctypes.WinDLL("kernel32",use_last_error=True)
        signatures={"CreateJobObjectW":([ctypes.c_void_p,wintypes.LPCWSTR],wintypes.HANDLE),"SetInformationJobObject":([wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD],wintypes.BOOL),"AssignProcessToJobObject":([wintypes.HANDLE,wintypes.HANDLE],wintypes.BOOL),"OpenProcess":([wintypes.DWORD,wintypes.BOOL,wintypes.DWORD],wintypes.HANDLE),"QueryInformationJobObject":([wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p],wintypes.BOOL),"TerminateJobObject":([wintypes.HANDLE,wintypes.UINT],wintypes.BOOL),"CloseHandle":([wintypes.HANDLE],wintypes.BOOL)}
        for name,(args,result) in signatures.items(): function=getattr(self.api,name); function.argtypes=args; function.restype=result
        self.handle=self.api.CreateJobObjectW(None,None)
        if not self.handle: raise ctypes.WinError(ctypes.get_last_error())
        info=Extended(); info.Basic.Flags=0x2000
        if not self.api.SetInformationJobObject(self.handle,9,ctypes.byref(info),ctypes.sizeof(info)):
            error=ctypes.WinError(ctypes.get_last_error()); self.close(); raise error
    def attach(self,process):
        need(process.poll() is None,"worker_exited_before_job_assignment")
        handle=self.api.OpenProcess(0x0100|0x0001,False,process.pid)
        if not handle: raise ctypes.WinError(ctypes.get_last_error())
        try:
            if not self.api.AssignProcessToJobObject(self.handle,handle): raise ctypes.WinError(ctypes.get_last_error())
        finally: self.api.CloseHandle(handle)
    def active(self):
        class Accounting(ctypes.Structure): _fields_=[("User",ctypes.c_longlong),("Kernel",ctypes.c_longlong),("PeriodUser",ctypes.c_longlong),("PeriodKernel",ctypes.c_longlong),("Faults",wintypes.DWORD),("Total",wintypes.DWORD),("Active",wintypes.DWORD),("Terminated",wintypes.DWORD)]
        info=Accounting()
        if not self.api.QueryInformationJobObject(self.handle,1,ctypes.byref(info),ctypes.sizeof(info),None): raise ctypes.WinError(ctypes.get_last_error())
        return info.Active
    def stop(self):
        if not self.api.TerminateJobObject(self.handle,1): raise ctypes.WinError(ctypes.get_last_error())
    def close(self):
        if self.handle:
            handle,self.handle=self.handle,None
            if not self.api.CloseHandle(handle): raise ctypes.WinError(ctypes.get_last_error())

def prepare():
    (STATE/'native44-build-provenance.json').write_text(json.dumps(BUILD_PROVENANCE,indent=2),encoding='utf-8')
    need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,timeout=30).strip()==BASE_COMMIT,'unexpected_base_commit')
    need(source_hash()==SOURCE_HASH,'verified_build_source_changed')
    original=pathlib.Path(BUILD_PROVENANCE['root'])
    report=pathlib.Path(os.environ['RUNNER_TEMP'])/'n00-successful-build-report.json'
    regular(report);need(sha(report)==BUILD_PROVENANCE['build_report_sha256'],'successful_build_report_changed')
    exported=pathlib.Path(os.environ['RUNNER_TEMP'])/'n00-build-export-receipt.json'
    regular(exported);need(sha(exported)==BUILD_PROVENANCE['build_export_receipt_sha256'],'successful_build_export_receipt_changed')
    archive=json.loads(exported.read_text(encoding='utf-8'))
    need(archive['bytes']==BUILD_PROVENANCE['build_archive']['bytes'] and archive['sha256']==BUILD_PROVENANCE['build_archive']['sha256'],'successful_build_archive_changed')
    need(archive['source_sha256']==SOURCE_HASH and archive['complete_source_sha256']==BUILD_PROVENANCE['complete_build_source_sha256'] and archive['status']=='passed_check_and_build_only','successful_build_export_source_changed')
    need(archive['runtime_pass'] is False and archive['publication_authorized'] is False,'unexpected_build_export_acceptance_claim')
    for name,(size,digest) in FILES.items():
        old=original/name;path=ROOT/name
        need(regular(old).st_size==size and sha(old)==digest,'verified_build_apk_changed')
        need(not path.exists(),'runtime_apk_destination_exists')
        path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,path)
    need(regular(BASELINE).st_size==29771254 and sha(BASELINE)==PREVIOUS_HASH,'published_baseline43_changed')
    need(not PREVIOUS.exists(),'baseline_destination_exists')
    shutil.copyfile(BASELINE,PREVIOUS)
    import emulator_lease,prepare_android_sdk
    from backend.android_runtime_contract import required_sdk_packages
    lease_bytes=(ROOT/'.github/scripts/emulator_lease.py').read_bytes()
    need(hashlib.sha1(b'blob '+str(len(lease_bytes)).encode()+b'\0'+lease_bytes).hexdigest()=='c9626f3bf90b612a71b9bbf2954d0c134aa29b22','canonical_lease_changed')
    with emulator_lease.exclusive_emulator():
        for package in required_sdk_packages():prepare_android_sdk._verify_package(SDK,package)
        subprocess.run([SDK/'emulator/emulator.exe','-accel-check'],check=True,timeout=30,env=environment())
    unchanged()
    print('N00_RUNTIME_INPUTS='+json.dumps({'source_sha256':SOURCE_HASH,'source_commit':BASE_COMMIT,'files':FILES,'previous_sha256':PREVIOUS_HASH,'prepared_at':now(),'build_provenance':BUILD_PROVENANCE}),flush=True)

stage=sys.argv[1]
if stage=='prepare':prepare()
elif stage in ('4096','16384'):profile(int(stage))
elif stage=='export':export()
else:raise ValueError('unknown_stage')
