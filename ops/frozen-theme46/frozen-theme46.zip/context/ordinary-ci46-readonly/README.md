# N00: ordinary CI and external Sonar after the final46 source backup

Read-only audit, 2026-10-26; final observation at 09:14:48 UTC. No PR, push,
workflow run, rerun, branch rule, application, test, release, or client policy
was changed or executed. All source copies in `remote/` were fetched from
GitHub and matched their Git blob IDs. This is an execution plan, not an
ordinary-CI acceptance receipt.

## Result

The existing ordinary CI has a viable trigger path: create a **new same-repository
draft PR to main** from the final source backup on
`codex/windows-development-2026-10-25`. Android CI and Backend CI both listen
to `pull_request` targeting main, with no draft exclusion or path filter.
Pushing this development branch alone does not start either workflow.
The external Sonar app has already produced real successful checks on the old
draft PRs; the new PR must obtain its own clean check at its exact new head.

No current configuration blocker to this trigger was observed. The future46
source backup and its checks do not exist yet in this snapshot, so their
success cannot be claimed. The migrated ordinary workflow itself still needs
an actual full integration run on the laptop.

## Current identities and rules

| Item | Read-only observation |
| --- | --- |
| main | `f54912165127bfab42673743cd141d635e20881f` |
| Development branch | `58515d9d96246d560b371ab067a93831ef305af0` |
| Development versus main | 247 commits ahead, 0 behind; merge base equals current main |
| PRs for this development branch | None, including closed PRs returned by the exact head filter |
| Checks/runs at development head | 0 check runs and 0 workflow runs |
| Existing draft PR880 | Head `690811a5a376181990a64f37d914c87eb6c919b7`, base main; unchanged |
| Existing draft PR887 | Head `79be182168e21ae8248e0e0dfa6deb0abfbacbcf`, base `codex/spectrum-3d-100`; unchanged |
| Main ruleset20519289 | Active; PR required; squash merge; no bypass; required context `V10 authoritative merge gate`, integration15368, strict status policy |

The live Android workflow/helper, Backend workflow/helper and android-apk
caller are byte-identical to the reviewed CI13 migration candidates. GitHub
branch protection's separate administrator endpoint was not needed; the
active repository ruleset and rules applying to main were readable.

## Exact execution path after46 is independently checked and backed up

1. Re-read the final development head and current main. Bind the final source
   backup to the successful Windows46 source inventory and build receipts.
   Check the **last head commit message** has no explicit private-APK request.
   `private_apk_review.cjs` reads this message with `repos.getCommit`; it does
   not use the PR title or body for that request. The present58515 head has no
   such marker. Do not change main or reuse the stale880/887 source branches.
2. Create the new draft PR with head
   `codex/windows-development-2026-10-25`, base `main`. Record the PR number,
   exact head SHA, current base SHA and GitHub's tested merge SHA. No public
   release or private-APK request is needed for ordinary verification.
3. Let the PR event start **Backend CI** and **Android CI**. Both use fresh
   run/attempt-owned checkouts on the existing Windows laptop and the
   canonical shared lease for actual code execution. The tested source is
   the synthetic merge; raw Git parents must equal `[base, head]`. External
   Sonar must refer to the PR **head**, not to that synthetic merge.
4. Await `SonarCloud Code Analysis` from app `sonarqubecloud` for this exact
   head. The existing gates require completed success, no annotations,
   exactly zero new issues and exactly zero accepted issues. They do not
   manufacture a status or reuse the old PR's Sonar result. If the new result
   is absent or fails, investigate the actual check/annotations before any
   rerun or source change; do not bypass the gate.
5. Allow Android build, both runtime profiles, strict validation, private
   evidence collection and attributed cleanup to complete. The separate
   publication job must also succeed: it first revalidates retained source,
   APKs and receipts, then an ordinary PR without the head-commit request
   returns before the inherited private version35 validator. Main-only
   public-release steps do not execute for this PR.
6. Require the final `Android debug and release build`, `Backend smoke test`
   and **`V10 authoritative merge gate`** to succeed on their appropriate
   identities. The authoritative gate re-reads the open PR head/base and the
   newest exact-head Backend run/attempt plus the real Sonar check. Preserve
   the draft/no-merge state until the intended review and remaining plan
   acceptance are complete. Opening a draft and obtaining checks is not a
   claim that N00 or the full autonomous-portfolio plan is finished.

## What the ordinary native gate really runs

The runtime job runs16384 and4096 sequentially, each with a125-minute step
budget. Both steps use `always()` after successful input preparation, so the
second profile is attempted even if the first fails. The unchanged
installation entry point runs as `__main__` with `RUN_PROFILE_UI_TESTS=1`;
there is no focused-hook substitution. `validate_distribution.py` requires
both current profile receipts after the runtime controllers pass.

`backend/android_runtime_contract.py` and `profile_ui_probe.exercise` agree
on these exact15 stage IDs:

1. `native-2d-renderer`
2. `session-context`
3. `balance-privacy`
4. `goal-workflow`
5. `business-30-cases`
6. `portfolio-7-cases`
7. `spectrum-dashboards`
8. `workspace-interactions`
9. `automation-13-cases`
10. `profile-preflight`
11. `themes`
12. `dialogs`
13. `settings-group-scroll`
14. `education`
15. `large-font-200`

The proposed46 palette52/lifecycle4 evidence is additional, separately bound
native acceptance. It is not implicitly proved by this original15 receipt.
Likewise, a focused original14 or navigation-only run does not replace this
ordinary full15 matrix.

## Concrete limits to retain in the result

- **Upgrade baseline remains43.** Ordinary CI pins0.13.5-preview/43,
  29,771,254 bytes and SHA256
  `4e9bf0a2fd54d8ab4b9d49ef9ddf96bc14a274ac4c145585fcfdb88d6ae774b6`.
  Its two profiles will prove43→46, not automatically45→46. A bounded GET at
  09:14:28 UTC returned206 with `Content-Range: bytes 0-0/29771254`; only one
  byte was fetched. HEAD is unsupported405. This availability observation
  does not replace CI's full download/hash/signature verification. If both
  ordinary profiles must instead prove45→46, that is a separate reviewed
  baseline update before freezing the final tested head.
- **External Sonar is automatic app analysis.** There is no Sonar scanner
  workflow to dispatch in the current repository. Previous real checks:
  PR880 check120550343899 and PR887 check120550963109, app12526, both success
  with zero new/accepted issues. These establish the existing integration,
  not a successful future46 analysis. The official documentation describes
  PR analysis at the source-branch head and automatic PR-triggered analysis.
- **Public/private release debt is out of this PR path.** The retained
  `ANDROID_N11_RELEASE_POLICY_DEBT.md` remains applicable. Public version/notes
  are stale and the requested private APK path is fixed to35/0.11.0-preview.
  Those paths must be repaired before invoking them, but they do not block an
  ordinary PR whose head commit contains no private-APK request. Current
  `.sonarcloud.properties` also still says `sonar.projectVersion=0.11.0`;
  that is stale analysis metadata, not an observed trigger failure.
- **No new source can borrow old evidence.** A later push requires fresh
  checks at the new head; the final gate detects head/base changes. A source
  backup, prior administrative build, successful focused preview delivery
  and actual client policy are separate receipts.

## Sources

Local exact API evidence: `github-snapshot.json`,
`additional-observations.json` and14 verified source copies in `remote/`.

- [Current main ref](https://api.github.com/repos/MishaGameHacking/omni-cio-gateway/git/ref/heads/main)
- [Development branch](https://github.com/MishaGameHacking/omni-cio-gateway/tree/58515d9d96246d560b371ab067a93831ef305af0)
- [Active main ruleset20519289](https://api.github.com/repos/MishaGameHacking/omni-cio-gateway/rulesets/20519289)
- [Android CI at inspected head](https://github.com/MishaGameHacking/omni-cio-gateway/blob/58515d9d96246d560b371ab067a93831ef305af0/.github/workflows/android-ci.yml)
- [Backend CI at inspected head](https://github.com/MishaGameHacking/omni-cio-gateway/blob/58515d9d96246d560b371ab067a93831ef305af0/.github/workflows/backend-ci.yml)
- [PR880](https://github.com/MishaGameHacking/omni-cio-gateway/pull/880)
- [PR887](https://github.com/MishaGameHacking/omni-cio-gateway/pull/887)
- [SonarCloud automatic analysis](https://docs.sonarsource.com/sonarqube-cloud/analyzing-source-code/automatic-analysis)
- [SonarCloud PR analysis](https://docs.sonarsource.com/sonarqube-cloud/analyzing-source-code/pull-request-analysis)

Read-only administrative parsing, hashing and bounded HTTP/API requests only.
No application/test execution was performed outside Windows or by this audit.
