"""Prepare candidate43 native diagnostics; never execute application code here.

Run only after the successful Windows build and its exact source backup have
been independently verified. This writes reviewable files under context/native43;
it does not modify a checkout, push a workflow, or start an emulator.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import zlib

import yaml


ROOT = Path(__file__).resolve().parents[1]
TARGET_WORKFLOW = '.github/workflows/windows-n00-portfolio43.yml'
BASE_RUNTIME_SHA256 = '05d14d3abff96e80454381b877789f9185a01a6a0824d2ed4e27d94abf33e3c6'
BASE_HOOK_SHA256 = 'ddff3bb7c57670141b9e5f0ce02994fb0d8ed7748b781776a284460614f2276e'
BASE_WORKFLOW_SHA256 = 'c61d5f035fd8c758e06168b4f28359f8805f21e6db529a39367db8c82d6c002d'
UPLOAD_ACTION = 'actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9'
APK_PATHS = (
    'app/build/outputs/apk/debug/app-debug.apk',
    'app/build/outputs/apk/preview/app-preview.apk',
    'ci-ui-driver/build/outputs/apk/debug/ci-ui-driver-debug.apk',
)


def need(value, message):
    if not value:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def hash_value(value, length, label):
    need(isinstance(value, str) and re.fullmatch('[a-f0-9]{' + str(length) + '}', value), label)
    return value


def replace_once(text, old, new):
    need(text.count(old) == 1, 'Template anchor changed: ' + old[:100])
    return text.replace(old, new, 1)


def assignment(text, name, value):
    lines = [line for line in text.splitlines() if line.startswith(name + ' = ')]
    need(len(lines) == 1, 'Missing unique template assignment: ' + name)
    return replace_once(text, lines[0], name + ' = ' + repr(value))


def source_paths(report, bundle):
    rows = report.get('patch_files')
    need(isinstance(rows, list) and len(rows) == 14, 'The successful build must contain all 14 candidate source files')
    expected = {}
    for row in bundle['files']:
        rel = row['path']
        path = PurePosixPath(rel)
        need(not path.is_absolute() and '..' not in path.parts and '\\' not in rel, 'Invalid candidate source path')
        need(path.parts[0] in ('.github', 'app') and path.suffix in ('.py', '.kt', '.kts'), 'Unexpected candidate source kind')
        need(rel not in expected, 'Duplicate candidate source path')
        data = row['content'].encode('utf-8')
        need(len(data) == row['new_bytes'] and sha256(data) == row['new_sha256'], 'Candidate bundle bytes changed')
        expected[rel] = {'bytes': len(data), 'sha256': row['new_sha256']}
    need(len(expected) == 14, 'The reviewed candidate bundle must contain 14 files')
    observed = {}
    for row in rows:
        rel = row['path']
        need(rel in expected and rel not in observed, 'Build source evidence differs from reviewed candidate')
        need(row['new_sha256'] == expected[rel]['sha256'], 'Build source hash differs from reviewed candidate')
        observed[rel] = expected[rel]
    need(observed.keys() == expected.keys(), 'Incomplete candidate source evidence')
    gradle = next(row['content'] for row in bundle['files'] if row['path'] == 'app/build.gradle.kts')
    need(re.search(r'^\s*versionCode = 43\s*$', gradle, re.M), 'Candidate code must be exactly 43')
    need(re.search(r'^\s*versionName = "0\.13\.5"\s*$', gradle, re.M), 'Candidate name must be exactly 0.13.5')
    return dict(sorted(observed.items()))


def read_build_report(path, source_commit, source_hash, bundle):
    raw = path.read_bytes()
    need(0 < len(raw) <= 8 * 1024**2, 'Invalid build report size')
    report = json.loads(raw)
    need(report.get('schema') == 1 and report.get('kind') == 'windows_development_check_build', 'Wrong build report kind')
    need(report.get('host') == 'LAPTOP-NPSGA016' and report.get('origin') == 'Windows laptop', 'Wrong build host')
    need(report.get('status') == 'passed_check_and_build_only', 'The complete check/build result must have passed')
    for phase in ('check', 'build'):
        need(report.get(phase, {}).get('status') == 'passed', 'Unsuccessful build phase: ' + phase)
        need(report[phase].get('source_sha256') == source_hash, 'Build phase source identity changed')
    need(report.get('source_sha256') == source_hash == report.get('source_sha256_after'), 'Build source inventory differs from explicit input')
    complete = hash_value(report.get('complete_source_sha256'), 64, 'Invalid complete source inventory')
    need(report.get('complete_source_sha256_after') == complete, 'Complete build source inventory changed')
    need(report.get('publication_authorized') is False and report.get('phone_verified') is False, 'Unexpected publication or phone claim')
    need(report.get('timeweb_execution') is False and report.get('runtime', {}).get('status') == 'not_run', 'Build report must keep runtime acceptance separate')
    need(report.get('certificate_sha256') == 'bbce9534fd4cfee8f3bdcaf51a31cce384a4f303f090c8cae9ec558227d59eb1', 'Build signing identity changed')
    steps = report.get('steps')
    need(isinstance(steps, list) and steps and all(type(row.get('exit_code')) is int and row['exit_code'] == 0 for row in steps), 'A build/check command did not pass')
    required = {'host-tests', 'tools-tests', 'node-tests', 'backend-tests', 'gradle', 'apk-verification'}
    need(required <= {row.get('label') for row in steps}, 'A required complete build/check gate is absent')
    for case in ('quote', 'appearance', 'dossier'):
        row = report.get('original_regressions', {}).get(case, {})
        need(row.get('expected_original_failure_reproduced') is True and row.get('tests_run') == 1
             and row.get('failures') == 2 and row.get('errors') == 0 and row.get('skips') == 0,
             'Missing original defect evidence: ' + case)
    github = report['github']
    run, attempt = github['run_id'], github['run_attempt']
    need(type(run) is int and run > 0 and type(attempt) is int and attempt > 0, 'Invalid build run identity')
    hash_value(github['workflow_sha'], 40, 'Invalid build workflow commit')
    root = PureWindowsPath(report['root'])
    need(root.drive.upper() == 'C:' and root.is_absolute() and len(root.parts) == 6, 'Invalid retained Windows build root')
    need(root.parts[1] in {'actions-runner', 'actions-runner-2', 'actions-runner-3', 'actions-runner-4'}, 'Unexpected Windows runner root')
    need(root.parts[2:] == ('_work', 'omni-cio-gateway', 'omni-cio-gateway', f'windows-development-{run}-{attempt}'), 'Retained build root is not owned by the reported run')
    state = root.parents[2] / '_temp' / f'analyst-development-{run}-{attempt}'
    need(PureWindowsPath(report['state']) == state, 'Retained build report is outside the exact run state')
    files = {}
    for rel in APK_PATHS:
        identity = report.get('apks', {}).get(rel, {})
        size = identity.get('bytes')
        need(type(size) is int and 0 < size <= 512 * 1024**2, 'Missing exact APK byte count: ' + rel)
        files[rel] = [size, hash_value(identity.get('sha256'), 64, 'Missing exact APK SHA256: ' + rel)]
    need(report['build'].get('apk_sha256') == files[APK_PATHS[1]][1], 'Preview build identity differs from APK inventory')
    evidence = source_paths(report, bundle)
    provenance = {
        'build_report_sha256': sha256(raw), 'build_run_id': run, 'build_run_attempt': attempt,
        'build_workflow_sha': github['workflow_sha'], 'build_status': report['status'],
        'host': report['host'], 'root': str(root), 'state': str(state),
        'build_base_commit': report['base_commit'], 'source_backup_commit': source_commit,
        'source_sha256': source_hash, 'complete_build_source_sha256': complete,
        'preview_version_code': 43, 'preview_version_name': '0.13.5-preview',
        'input_apks': files, 'candidate_source_files': evidence,
        'original_portfolio_cases_required': 14, 'full_ui_stage_count': 15,
        'diagnostic_only': True, 'release_gate_pass': False,
        'full_ui_suite_executed': False, 'publication_authorized': False, 'phone_verified': False,
    }
    return files, evidence, provenance


def make_runtime(original, source_commit, source_hash, files, evidence, provenance):
    text = original.decode('utf-8')
    text = assignment(text, 'BASE_COMMIT', source_commit)
    text = assignment(text, 'SOURCE_HASH', source_hash)
    text = assignment(text, 'FILES', files)
    text = replace_once(text, 'PATCH_HASH = None\n',
                        'PATCH_HASH = None\nSOURCE_EVIDENCE = ' + repr(evidence) + '\nBUILD_PROVENANCE = ' + repr(provenance) + '\n')
    text = replace_once(text, "'n00-layout42-focused-'", "'n00-native43-focused-'")
    text = replace_once(text, "    need(source_hash()==expected_source_hash(),'source_bytes_changed')\n",
                        "    need(source_hash()==expected_source_hash(),'source_bytes_changed')\n"
                        "    for rel,identity in SOURCE_EVIDENCE.items():\n"
                        "        path=ROOT/rel;need(regular(path).st_size==identity['bytes'] and sha(path)==identity['sha256'],'candidate_source_evidence_changed')\n")
    old_source_loop = next(line for line in text.splitlines() if line.startswith("    for rel in ('app/src/main/java/ru/omnicio/app/ui/spectrum/SpectrumTabs.kt'"))
    text = replace_once(text, old_source_loop, '    for rel,identity in SOURCE_EVIDENCE.items():')
    text = replace_once(text, "        p=ROOT/rel;entries['source/'+rel]=(p,{'bytes':regular(p).st_size,'sha256':sha(p)})",
                        "        p=ROOT/rel;need(regular(p).st_size==identity['bytes'] and sha(p)==identity['sha256'],'candidate_source_export_changed')\n"
                        "        entries['source/'+rel]=(p,dict(identity))")
    text = replace_once(text, "envelope={'kind':'n00_candidate42_portfolio_focused',",
                        "envelope={'kind':'n00_candidate43_portfolio_focused','diagnostic_only':True,'release_gate_pass':False,"
                        "'original_portfolio_cases_required':14,'full_ui_stage_count':15,'build_provenance':BUILD_PROVENANCE,'candidate_source_evidence':SOURCE_EVIDENCE,")
    text = replace_once(text, "    path=pathlib.Path(os.environ['RUNNER_TEMP'])/'ci-handoff.zip'\n",
                        "    (STATE/'native43-evidence-envelope.json').write_text(json.dumps(envelope,indent=2),encoding='utf-8')\n"
                        "    path=pathlib.Path(os.environ['RUNNER_TEMP'])/'ci-handoff.zip'\n")
    old_root = next(line for line in text.splitlines() if line.startswith('    original=pathlib.Path('))
    text = replace_once(text, old_root,
                        "    original=pathlib.Path(BUILD_PROVENANCE['root'])\n"
                        "    report=pathlib.Path(os.environ['RUNNER_TEMP'])/'n00-successful-build-report.json'\n"
                        "    regular(report);need(sha(report)==BUILD_PROVENANCE['build_report_sha256'],'successful_build_report_changed')")
    text = replace_once(text, 'def prepare():\n',
                        "def prepare():\n"
                        "    (STATE/'native43-build-provenance.json').write_text(json.dumps(BUILD_PROVENANCE,indent=2),encoding='utf-8')\n")
    old_inputs = next(line for line in text.splitlines() if line.startswith("    print('N00_RUNTIME_INPUTS='"))
    text = replace_once(text, old_inputs,
                        "    print('N00_RUNTIME_INPUTS='+json.dumps({'source_sha256':SOURCE_HASH,'source_commit':BASE_COMMIT,'files':FILES,'previous_sha256':PREVIOUS_HASH,'prepared_at':now(),'build_provenance':BUILD_PROVENANCE}),flush=True)")
    ast.parse(text)
    # These unchanged sections own process termination and SDK/emulator access.
    baseline = original.decode('utf-8')
    need(text.split('class OwnedJob:', 1)[1].split('\ndef prepare():', 1)[0]
         == baseline.split('class OwnedJob:', 1)[1].split('\ndef prepare():', 1)[0], 'OwnedJob changed')
    for start, end in (('def environment():', '\ndef profile('),
                       ('    import emulator_lease,prepare_android_sdk', '\n    unchanged()')):
        need(text.split(start, 1)[1].split(end, 1)[0] == baseline.split(start, 1)[1].split(end, 1)[0], 'Canonical lease or environment isolation changed')
    need("raise ValueError('unknown_stage')" in text and "'published_baseline38_changed'" in text, 'Runtime boundary changed')
    return text.encode('utf-8')


def stage(name, content):
    need(re.fullmatch(r'[a-z0-9-]+\.(?:py|json)', name), 'Invalid administrative transport name')
    encoded = base64.b64encode(zlib.compress(content, 9)).decode('ascii')
    lines = []
    for offset in range(0, len(encoded), 6000):
        mode = 'w' if offset == 0 else 'a'
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'RUNNER_TEMP\'])/\'' + name + '.b64\'; p.open(\'' + mode + '\',encoding=\'ascii\').write(\'' + encoded[offset:offset + 6000] + '\')"')
        lines.append('if errorlevel 1 exit /b 1')
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'RUNNER_TEMP\']); b=zlib.decompress(base64.b64decode((p/\'' + name + '.b64\').read_text())); assert hashlib.sha256(b).hexdigest()==\'' + sha256(content) + '\'; (p/\'' + name + '\').write_bytes(b)"')
    lines.append('if errorlevel 1 exit /b 1')
    need(max(map(len, lines)) < 8000, 'Windows command line would be too long')
    return {'name': 'Stage verified focused transport ' + name, 'shell': 'cmd', 'run': '\n'.join(lines)}


def observation_script(source_commit, source_hash, provenance):
    header = 'const identity=' + json.dumps({'source_commit': source_commit, 'source_sha256': source_hash,
        'build_run_id': provenance['build_run_id'], 'build_run_attempt': provenance['build_run_attempt'],
        'build_report_sha256': provenance['build_report_sha256']}, separators=(',', ':')) + ';\n'
    return header + """const fs=require('node:fs'),p=require('node:path');
const folder=p.join(process.env.SOURCE_ROOT,'app/build/outputs/apk/preview/ui-screens');
const file=p.join(folder,'portfolio-focused-observations.json');
const source=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{diagnostic_only:true,release_gate_pass:false,error:'focused_report_missing'};
const cases=source.portfolio && Array.isArray(source.portfolio.cases)?source.portfolio.cases:[];
const complete=source.diagnostic_only===true && source.release_gate_pass===false && source.portfolio_cases_complete===true && cases.length===14;
const report={...identity,diagnostic_only:true,release_gate_pass:false,
  original14:{complete,required_cases:14,observed_cases:cases.length},
  full15:{executed:false,accepted:false,required_stages:15},
  observations:{...source,portfolio:source.portfolio?{...source.portfolio,cases:cases.map(c=>({case:c.case,font_scale:c.font_scale,checks:c.checks,screenshots:c.screenshots}))}:null}};
const state=p.join(process.env.RUNNER_TEMP,'n00-native43-focused-'+process.env.GITHUB_RUN_ID+'-'+process.env.GITHUB_RUN_ATTEMPT);
fs.writeFileSync(p.join(state,'native43-original14-summary.json'),JSON.stringify(report,null,2)+'\\n');
core.setOutput('original14_complete',String(complete));
core.info('N00_ORIGINAL14_COMPLETE='+String(complete));
core.info('N00_FULL15_ACCEPTED=false');
const title=complete?'Original 14 native cases completed; full 15-stage matrix remains pending':'Original 14 native cases incomplete; full 15-stage matrix remains pending';
const fence=String.fromCharCode(96).repeat(3);
await github.rest.checks.create({...context.repo,name:'N00 candidate43 original14 observations (diagnostic only)',head_sha:context.sha,status:'completed',conclusion:'neutral',output:{title,summary:fence+'json\\n'+JSON.stringify(report,null,2)+'\\n'+fence}});
"""


def diagnostic_upload():
    state = '${{ runner.temp }}/n00-native43-focused-${{ github.run_id }}-${{ github.run_attempt }}'
    apk = '${{ env.SOURCE_ROOT }}/app/build/outputs/apk/preview'
    # Top-level install files avoid its disposable AVD/home tree. UI folders
    # contain only synthetic captures. No APK, archive, key, or profile glob.
    folders = [state, apk + '/install-api37-16384', apk + '/ui-screens/**', apk + '/ui-screens-api37-16384/**']
    paths = [folder + '/*.' + extension for folder in folders for extension in ('json', 'log', 'xml', 'png')]
    return {'name': 'Retain original14 native diagnostic reports and synthetic captures', 'if': 'always()',
        'uses': UPLOAD_ACTION, 'with': {'name': 'n00-candidate43-original14-native-16384',
            'path': '\n'.join(paths), 'retention-days': 3, 'if-no-files-found': 'error'}}


def make_workflow(template, runtime, hook, build_report, source_commit, source_hash, provenance, build_workflow):
    pins = {step.get('uses') for step in build_workflow['jobs']['develop']['steps']
            if step.get('uses', '').startswith('actions/upload-artifact@')}
    need(pins == {UPLOAD_ACTION}, 'Build workflow upload-artifact pin changed')
    workflow = copy.deepcopy(template)
    workflow['name'] = 'N00 candidate43 original fourteen portfolio cases after native repairs'
    need(workflow['on']['push']['branches'] == ['codex/timeweb-owner-prepare-2026-10-23'], 'Unexpected administrative branch')
    workflow['on']['push']['paths'] = [TARGET_WORKFLOW]
    workflow['concurrency']['group'] = 'analyst-n00-candidate43-portfolio-focused'
    need(workflow['concurrency']['cancel-in-progress'] is False, 'Native run cancellation policy changed')
    develop = workflow['jobs']['develop']
    develop['name'] = 'Run all fourteen original portfolio cases on exact candidate43'
    need(develop['runs-on'] == ['self-hosted', 'Windows', 'X64', 'omni-cio-ci'], 'Native runtime is not pinned to the laptop')
    steps, staged, checkout, exported, reported = [], False, False, False, False
    for step in develop['steps']:
        name = step.get('name', '')
        if step.get('uses', '').startswith('actions/checkout@'):
            need(not checkout, 'Unexpected additional source checkout')
            step['with']['ref'] = source_commit
            need(step['with']['persist-credentials'] is False, 'Checkout credentials would persist')
            checkout = True
        if name.startswith('Stage verified focused transport '):
            if not staged:
                steps.extend([stage('n00-runtime.py', runtime), stage('n00-portfolio-focused-hook.py', hook),
                              stage('n00-successful-build-report.json', build_report)])
                steps[-1]['id'] = 'setup'
                staged = True
            continue
        if name == 'Report focused portfolio observation separately from full matrix':
            step['id'] = 'focused_report'
            step['with']['script'] = observation_script(source_commit, source_hash, provenance)
            reported = True
        steps.append(step)
        if step.get('id') == 'export':
            steps.append(diagnostic_upload())
            exported = True
    need(checkout and staged and exported and reported, 'Native workflow structure changed')
    develop['steps'] = steps
    develop['outputs']['original14_complete'] = '${{ steps.focused_report.outputs.original14_complete }}'
    workflow['jobs']['collect']['name'] = 'Return exact Windows native evidence to Timeweb storage'
    workflow['jobs']['result']['name'] = 'Original14 diagnostics do not claim full15 runtime acceptance'
    # The original sentinel deliberately leaves the runtime/job unsuccessful.
    # Do not add continue-on-error or convert a diagnostic result into acceptance.
    need(not any(step.get('continue-on-error') for step in steps), 'Diagnostic failure semantics changed')
    return yaml.safe_dump(workflow, allow_unicode=True, sort_keys=False, width=120).encode('utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-commit', required=True, help='Exact verified source backup commit')
    parser.add_argument('--source-sha256', required=True, help='Exact code inventory SHA256 from the successful build')
    parser.add_argument('--build-report', type=Path, required=True, help='Unmodified successful Windows windows-development.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'context/native43')
    args = parser.parse_args()
    source_commit = hash_value(args.source_commit, 40, 'Invalid source backup commit')
    source_hash = hash_value(args.source_sha256, 64, 'Invalid source inventory SHA256')
    original = (ROOT / 'context/build-baseline/n00-runtime.py').read_bytes()
    hook = (ROOT / 'context/build-baseline/n00-portfolio-focused-hook.py').read_bytes()
    template_bytes = (ROOT / 'admin-transport/.github/workflows/windows-n00-portfolio-layout42.yml').read_bytes()
    need(sha256(original) == BASE_RUNTIME_SHA256 and sha256(hook) == BASE_HOOK_SHA256
         and sha256(template_bytes) == BASE_WORKFLOW_SHA256, 'Pinned native baseline changed')
    bundle = json.loads((ROOT / 'context/candidate43/bundle.json').read_bytes())
    files, evidence, provenance = read_build_report(args.build_report, source_commit, source_hash, bundle)
    build_report = args.build_report.read_bytes()
    need(sha256(build_report) == provenance['build_report_sha256'], 'Build report changed while preparing transport')
    runtime = make_runtime(original, source_commit, source_hash, files, evidence, provenance)
    build_workflow = yaml.safe_load((ROOT / 'admin-transport/.github/workflows/windows-development.yml').read_text())
    workflow = make_workflow(yaml.safe_load(template_bytes), runtime, hook, build_report, source_commit, source_hash, provenance, build_workflow)
    outputs = {'n00-runtime.py': runtime, 'n00-portfolio-focused-hook.py': hook, 'workflow.yml': workflow,
        'n00-successful-build-report.json': build_report,
        'build-provenance.json': (json.dumps(provenance, indent=2) + '\n').encode('utf-8')}
    receipt = {'target_workflow_path': TARGET_WORKFLOW, 'source_backup_commit': source_commit,
        'source_sha256': source_hash, 'build_report_sha256': provenance['build_report_sha256'],
        'build_run_id': provenance['build_run_id'], 'build_run_attempt': provenance['build_run_attempt'],
        'candidate_source_file_count': len(evidence), 'candidate_source_files': evidence,
        'hook_unchanged_sha256': sha256(hook), 'original14_is_diagnostic_only': True,
        'full15_acceptance_claimed': False, 'upload_artifact': UPLOAD_ACTION, 'retention_days': 3,
        'files': {name: {'bytes': len(data), 'sha256': sha256(data)} for name, data in outputs.items()}}
    # Prepare only: no GitHub operation, checkout mutation, application import,
    # emulator/process launch, or change to prepare_candidate43.py occurs here.
    args.output.mkdir(parents=True, exist_ok=True)
    for name, data in outputs.items():
        (args.output / name).write_bytes(data)
    (args.output / 'preparation.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'workflow': str(args.output / 'workflow.yml'), **receipt}, indent=2))


if __name__ == '__main__':
    main()
