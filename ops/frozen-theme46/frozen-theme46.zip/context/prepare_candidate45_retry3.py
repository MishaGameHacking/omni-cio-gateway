"""Prepare only the actual Windows45 synthetic-marker regression repair."""
import argparse
import ast
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib
import yaml

CONTEXT = Path(__file__).resolve().parent
PRIOR = CONTEXT / "candidate45-retry2-bound"
REPAIR = CONTEXT / "navigation45-fixture-repair"
REVIEW_SHA = "423ddacae2affd3655a72ba3eed21dbea47c2d27c04b1d27c6e041ca392a8be5"
REPAIR_SHA = "f47836882fd55979774937fa996d38ec99bc132e6d36c911b74ad9bb79895241"
WORKFLOW_SHA = "a65f691d6dc80b105f1cf342672a5730e79f60e41f6353dd5b17103c5dc95e60"
BOOTSTRAP_SHA = "9e4b061008d9596d5a104ea35e080405a3a569508b3f51b9fc7fb802d7adb3fc"
GUEST_SHA = "9c92c16d88a9e69a6e9b73b61f0e1eff8cd6b1b457451ee104c07bd17a7e29f0"
GENERATOR_SHA = "69bfb8dbefd2cb3ce7bbf03dbd3bbbaf90c66b8b6fb5d38873a6f27e878ecf9a"
BASE = "1cc05586b6874bfdd0cdb80131d178de9f95870c"
SOURCE = "e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9"
TEST = ".github/scripts/tests/test_navigation_detail_probe.py"


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected):
    need(CONTEXT in path.parents and path.resolve(strict=True) == path and not path.is_symlink()
         and path.is_file() and path.stat().st_nlink == 1, "Canonical input required")
    raw = path.read_bytes()
    need(sha(raw) == expected, "Pinned input changed: " + str(path))
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.absolute()
    need(CONTEXT in output.parents and not output.exists()
         and output.parent.resolve(strict=True) == output.parent, "New context output required")
    path = CONTEXT / "prepare_candidate45.py"
    read(path, GENERATOR_SHA)
    spec = importlib.util.spec_from_file_location("reviewed_admin45_retry3", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.verify_transport_source()
    _, previous44 = helper.reviewed_files()
    prior = json.loads(read(PRIOR / "reviewed-files.json", REVIEW_SHA))
    repair = json.loads(read(REPAIR / "manifest.json", REPAIR_SHA))
    need(prior["confirmed_base44_backup_commit"] == BASE and prior["base44_code_inventory_sha256"] == SOURCE
         and prior["version_after"] == {"code": 45, "name": "0.13.7"} and len(prior["files"]) == 24,
         "Prior exact candidate changed")
    need(repair["frozen"] is True and repair["base_reviewed_files_sha256"] == REVIEW_SHA
         and repair["source_file_count"] == 1 and repair["source_files"][0]["path"] == TEST
         and repair["production_helper_changed"] is False and repair["shared_admission_guard_changed"] is False,
         "Repair widened beyond one synthetic fixture")
    read(CONTEXT / "candidate45-retry2-build-evidence/10-host-tests.log", repair["observed_failure"]["host_log_sha256"])
    patch = read(REPAIR / "candidate.patch", repair["patch_sha256"])
    review = copy.deepcopy(prior)
    rows = review["files"]
    for row in rows:
        old = read(PRIOR / "source" / row["path"], row["new_sha256"])
        need(old == row["content"].encode() and len(old) == row["new_bytes"], "Prior source bytes differ")
        if row["path"] != TEST:
            continue
        entry = repair["source_files"][0]
        need(entry["old_sha256"] == sha(old) and entry["old_bytes"] == len(old)
             and entry["old_git_blob"] == helper.git_blob(old), "Repair old bytes differ")
        raw = read(REPAIR / "source" / TEST, entry["new_sha256"])
        need(len(raw) == entry["new_bytes"] and helper.git_blob(raw) == entry["new_git_blob"], "Repair new bytes differ")
        ast.parse(raw)
        row.update(content=raw.decode(), new_sha256=sha(raw), new_bytes=len(raw))
    need([a["path"] for a, b in zip(prior["files"], rows) if a != b] == [TEST], "Unexpected source delta")
    _, inventory = helper.verify_base_inventory(CONTEXT / "candidate44-original-evidence/source-final.json",
                                                SOURCE, rows, previous44)
    review.update(kind="reviewed_candidate45_retry3_after_actual_fixture_failure",
                  prior_reviewed_files_sha256=REVIEW_SHA, repair_paths=[TEST],
                  repair_evidence={"manifest_sha256": REPAIR_SHA, **repair["observed_failure"]})
    review_raw = helper.json_bytes(review)
    bundle = helper.json_bytes({"reference_commit": BASE, "files": rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = helper.json_bytes({"schema": 1, "base_commit": BASE, "bundles": [{"name": "n00-native45",
        "transport_sha256": sha(transport), "decoded_sha256": sha(bundle)}]}, compact=True)
    bootstrap = read(PRIOR / "windows-full-development.py", BOOTSTRAP_SHA)
    guest = read(PRIOR / "n00-linux-guest.py", GUEST_SHA)
    need(bootstrap == helper.bootstrap(BASE, SOURCE), "Proven bootstrap changed")
    before = yaml.safe_load(read(PRIOR / "workflow.yml", WORKFLOW_SHA))
    after = copy.deepcopy(before)
    after["name"] = "Side and bottom panels; candidate45 actual business-marker fixture repair"
    for index, name, raw in ((5, "n00-native45.b64", transport), (6, "patch-manifest.json", manifest)):
        step = after["jobs"]["develop"]["steps"][index]
        replacement = helper.stage(name, raw)
        need(step["name"] == replacement["name"] and step["shell"] == replacement["shell"], "Unexpected staged step")
        step["run"] = replacement["run"]
    restored = copy.deepcopy(after)
    restored["name"] = before["name"]
    for index in (5, 6):
        restored["jobs"]["develop"]["steps"][index]["run"] = before["jobs"]["develop"]["steps"][index]["run"]
    need(restored == before, "Workflow execution/transport changed")
    workflow = yaml.safe_dump(after, allow_unicode=True, sort_keys=False, width=120).encode()
    summary = {"state": "prepared_only_no_application_or_test_execution", "base_commit": BASE,
        "base_source_sha256": SOURCE, "base44_inventory": inventory, "reviewed_files_sha256": sha(review_raw),
        "bootstrap_sha256": sha(bootstrap), "guest_sha256": sha(guest), "patch_manifest_sha256": sha(manifest),
        "workflow_sha256": sha(workflow), "bundle_sha256": sha(bundle), "transport_sha256": sha(transport),
        "source_paths": 24, "new_source_paths": 6, "unchanged_retry2_rows": 23,
        "approved_repair_manifest_sha256": REPAIR_SHA, "repairs": [TEST],
        "source_applied_on_windows": False, "build_passed": False, "runtime_passed": False,
        "phone_verified": False, "publication_performed": False, "n00_complete": False}
    outputs = {"reviewed-files.json": review_raw, "bundle.json": bundle, "n00-native45.b64": transport,
        "patch-manifest.json": manifest, "windows-full-development.py": bootstrap, "n00-linux-guest.py": guest,
        "workflow.yml": workflow, "manifest-summary.json": helper.json_bytes(summary), "repair.patch": patch}
    output.mkdir()
    for name, raw in outputs.items():
        with (output / name).open("xb") as stream:
            stream.write(raw)
    for row in rows:
        p = output / "source" / row["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("xb") as stream:
            stream.write(row["content"].encode())
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
