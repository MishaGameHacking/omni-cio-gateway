"""Run all fourteen real portfolio cases; never claim the complete suite."""
import json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import profile_ui_probe as module
from portfolio_ui_probe import exercise_portfolio
from profile_snapshot import restore_device_settings
def focused(device,read_tree):
    probe=module.ProfileProbe(device);probe.read_tree=read_tree
    night=module.night_setting(probe.command('shell','cmd','uimode','night'))
    scale=probe.command('shell','settings','get','system','font_scale').strip()
    report={'diagnostic_only':True,'release_gate_pass':False,'portfolio_cases_complete':False}
    folder=Path(module.__file__).resolve().parents[2]/'app/build/outputs/apk/preview/ui-screens'
    try:
        report['portfolio']=exercise_portfolio(probe)
        report['portfolio_cases_complete']=len(report['portfolio']['cases'])==14
        if not report['portfolio_cases_complete']:raise AssertionError('All fourteen actual portfolio cases are required')
        raise AssertionError('Diagnostic only: full UI suite was deliberately not claimed')
    except BaseException as error:
        report.update(error_type=type(error).__name__,error=str(error)[:1000])
        if not report['portfolio_cases_complete']:
            try:
                folder.mkdir(parents=True,exist_ok=True)
                probe.capture('portfolio-focused-failure')
                (folder/'portfolio-focused-failure.xml').write_text(ET.tostring(probe.tree(),encoding='unicode'),encoding='utf-8')
            except Exception as capture_error:
                report['failure_capture_error']=type(capture_error).__name__
        raise
    finally:
        folder.mkdir(parents=True,exist_ok=True)
        (folder/'portfolio-focused-observations.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print('PORTFOLIO_FOCUSED_OBSERVATIONS='+json.dumps(report),flush=True)
        restore_device_settings(probe.command,scale,night,sys.exc_info()[1])
module.exercise_checks=focused
