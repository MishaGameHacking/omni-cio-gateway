# Focused native46 transport — preparation only

`../prepare_native46.py` is an administrative generator. It has not been invoked. No runtime, final native46 workflow, emulator, application or test has been executed or rendered here. All actual execution belongs to the Windows laptop. Root must independently confirm the actual46 source backup and private9417611 build archive before rendering/dispatch.

## Mandatory inputs

The request uses schema1 and the same `{path, sha256}` references as the preceding prepared transport. Every file must be a regular, single-link, canonical file below `context`, read with an independently supplied SHA256; duplicate JSON keys and non-finite numbers are rejected.

| Field | Real evidence required |
|---|---|
| verified45_request | The completed actual45 request accepted by the hash-pinned native45 validator: full Windows report/controller/export/inventory/reviewed patch and the actual published44 prerequisite. Its source backup is the exact base used by build46. |
| source_backup_commit / source_sha256 | Actual Git backup of the successful Windows-applied46 code and its code inventory, not a planned branch or guessed hash. |
| build_report | Complete Windows46 full host/tools/Node/backend/Gradle/APK report, all command exit codes0, exact base45, unchanged code/complete inventories, existing certificate and no invented native/publication claim. |
| build_controller | Actual successful46 worker and canonical lease receipt: worker exit0, owned descendants0, no error or cleanup error. Its hash is staged and rechecked on the laptop too. |
| build_export_receipt | The actual completed build archive's size/hash and both source inventories. Root must verify that exact archive is preserved on9417611; this generator does not contact the server. |
| source_inventory | Original source-final inventory from that successful build. The generator recomputes both code and complete digests and verifies every applied source identity. |
| reviewed_manifest / prepared_build | Actual rendered46 reviewed-files and manifest-summary. Exact base45, bootstrap/patch/reviewed hashes, all68 Windows-applied paths and their old/new bytes must agree. The four frozen source manifests are pinned again. |
| baseline_publication | Actual successful publication45 HTTPS verification receipt. Public policy and entire APK download must match the exact built45 APK, source backup, certificate, Windows run/attempt and build/export hashes. A locally built but unpublished45 cannot satisfy this input. |

`request.example.json` is deliberately invalid. Do not replace missing evidence with placeholder hashes or a report from a failed/partial run.

## Static review checkpoint

The administrative generator is frozen at SHA256 `fd11f280bc20febbcd480ac458e9958d70b9be81fea66b67237533b1b9a01c0f`. An independent read-only review by `ci_investigation` found no concrete blocker. Its receipt, `independent-static-review.json`, has SHA256 `74328b94ce41cee8a55250420e5639d46abbe550cbc6051374db22a57422b720` and records the verified template pins, all four package manifests, the exact 68-file union, receipt interfaces and unchanged process/transfer guards.

This checkpoint covers source inspection only. The generator has not been imported or invoked, no workflow or runtime has been rendered, and the actual build, publication and emulator prerequisites remain mandatory.

## Source, APK and transport boundaries

The generator reconstructs the exact frozen core40 + assets23 + lifecycle3 + quote1 + version Gradle1 union:68 unique paths. Only the three reviewed46 version assertions are merged. It compares every reviewed byte/hash with the completed Windows patch receipt and actual source inventory. Inherited44/45 evidence is retained, and unchanged original portfolio/launch/scroll/snapshot/install/driver/SDK/lease sources must equal the verified45 inventory.

The native runtime checks the exact Git backup and full code inventory again. Every explicit source witness is exported with its exact bytes. Preview46, debug46 and native frame-driver APKs are copied only from the retained actual successful46 build root and rechecked before/after execution. Baseline45 comes only from its retained verified build root, with the exact actually published byte count/hash. No baseline43/44 fallback, new signing key, rebuild or channel mutation is introduced.

The hash-pinned actual native44 runtime supplies the same OwnedJob handshake, environment filtering, source/APK verification, canonical emulator lease, SDK checks, bounded process cleanup and private artifact transfer. The preflight/collect/cleanup/result jobs are copied unchanged.9417611 stores evidence only; no app or test code executes there. Private diagnostic artifacts retain the existing3-day policy and owned temporary draft cleanup.

## Ordered diagnostic execution

1. Admit the actual current process's leased FrameReader emulator and read back the installed debug APK, native-driver APK, app version, API37 and PAGE_SIZE16384. Source/build identity comes from the verified provenance; a helper-local APK hash alone is insufficient.
2. Execute all14 original portfolio cases in their original order at font100/font200. The original case functions, action counts, assertions, 48dp targets and per-action timeouts are unchanged. Exact case identities, distinct checks and the persisted original receipt must agree before additional work starts.
3. Run the additional52 color frames: the unchanged finite48 main matrix plus4 production calendars. Require the complete unique matrix, actual installed source/APK bindings, actual paired pixels and exact nine-key restoration.
4. Read back the installed APK/driver identity again, then run all4 actual lifecycle cases. Require opposite-OS observations, real Appearance actions, native owner continuity and exact restoration. This separate receipt captures its own finite lifecycle evidence; it is not counted as extra palette frames.
5. Restore the original outer font/night settings with actual readback. Only after all three receipts and cleanup complete does the hook raise the existing intentional diagnostic sentinel. Real test, receipt or cleanup errors remain the primary failure.

The frozen lifecycle helper requires an existing explicit OS night policy `yes` or `no`. The wrapper checks it before stage mutations and fails closed on auto/custom; it does not bypass this safeguard by silently normalizing the emulator. This precondition remains a real runtime observation.

The separate neutral summary may say original14 complete and additional themes complete. It always says `full15.executed=false`, `full15.accepted=false` and `release_gate_pass=false`. The workflow itself remains unsuccessful because the complete normal15-stage suite was deliberately not run. No `continue-on-error`, altered required check or fake-green release path is introduced.

## Narrow administrative timeout difference

Adding52 stateful color frames and4 lifecycle cases after original14 needs a larger enclosing budget. Root authorized exactly these administrative changes:

| Boundary | Previous focused44 | Focused46 |
|---|---:|---:|
| Owned worker wait |2700s|5400s|
| Native profile step timeout |Inherited job bound|120min|
| Windows development job timeout |100min|140min|
| Canonical emulator lease wait |1200s|1200s unchanged|
| Original action/probe deadlines |Existing values|Unchanged|

After reversing only these budgets, baseline/names/identity metadata and the additional controller receipt check, the generator compares the process/prepare/export helper bodies against the pinned template. OwnedJob and environment/source functions must remain AST-identical.

## Artifacts and remaining acceptance

Rendered outputs, only after actual prerequisites exist:

- `n00-runtime.py`, `n00-portfolio-theme-focused-hook.py` and three SHA-bound actual build receipts.
- `build-provenance.json`, `workflow.yml`, `preparation.json` in a new requested context directory.
- Runtime state prefix `n00-native46-focused-{run}-{attempt}` with native46 build provenance, envelope and `native46-original14-summary.json`.
- Unchanged `install-api37-16384/install-results.json` plus genuine original portfolio, color and lifecycle JSON/XML/PNG evidence; private archive goes to9417611.

Still required after this diagnostic: complete original15 on both page sizes, normal CI and exact-PR-head external Sonar, Windows screenshot-golden regeneration/review where needed, and separately authorized actual application publication. A source preparation, successful build or focused diagnostic never closes N00 by itself.
