# Theme46: app night mode and independent system theme

Status: source-backed design approved by root on2026-10-26. Isolated helper/Application/uiMode manifest candidates are now prepared in the23-file assets bundle, with core integration owned by plan_audit and native lifecycle coverage owned by quote_diagnosis. No production checkout, app execution, test execution, device configuration or platform mode has been changed here.

## Required behavior

The saved preference remains `LIGHT`, `DARK`, or `SYSTEM`; the existing default remains `DARK`. Applying a preference must update the next native splash/window configuration. Preview and cancel must only change the in-memory preview. A `SYSTEM` preview must reflect the actual system appearance even when the saved application preference currently forces the opposite appearance. A theme apply must preserve the current activity and its unsaved editors.

## Confirmed API behavior

`UiModeManager.setApplicationNightMode` accepts `MODE_NIGHT_NO`, `MODE_NIGHT_YES`, `MODE_NIGHT_AUTO`, and `MODE_NIGHT_CUSTOM`. It does not accept `-1`/an invented `MODE_NIGHT_UNSPECIFIED`. Both inspected Android 16 and current AOSP service implementations map AUTO and CUSTOM to `Configuration.UI_MODE_NIGHT_UNDEFINED`, removing the app override. Therefore the proposed mapping is LIGHT→NO, DARK→YES, SYSTEM→AUTO. This uses only the application setter, never global `setNightMode`.

Sources: [public API](https://developer.android.com/reference/android/app/UiModeManager#setApplicationNightMode(int)); [AOSP current service](https://android.googlesource.com/platform/frameworks/base/+/master/services/core/java/com/android/server/UiModeManagerService.java), blob `896c9b8d0932a2860acf8250826cd752f87a0428`, method `setApplicationNightMode`; [Android 16 service](https://android.googlesource.com/platform/frameworks/base/+/android16-release/services/core/java/com/android/server/UiModeManagerService.java), blob `f54027ec02727b25a75e8d2ca36fd012b29b93d3`.

`Resources.getSystem()` is not a valid independent source after an application override. The source path is PackageConfigurationUpdaterImpl→WindowProcessController application override→merged process configuration→ConfigurationController→ResourcesManager→Resources.updateSystemConfiguration. The process-global Resources object therefore also receives the forced application mode. Likewise, `UiModeManager.getNightMode()` reports the system policy enum, not the currently computed night state for auto/custom/battery behavior.

Primary code inspected from `aosp-mirror/platform_frameworks_base`:

| File | Git blob | Relevant behavior |
| --- | --- | --- |
| services/core/java/com/android/server/wm/PackageConfigurationUpdaterImpl.java | `2cf8a4a7c1464729cea06fbfe6b7d94ccb74f4de` | Applies package override to process and activities |
| services/core/java/com/android/server/wm/WindowProcessController.java | `7f0c33657144bf5b1c2bd8d56e637c8b51001590` | Dispatches merged process configuration |
| core/java/android/app/ConfigurationController.java | `62a50dbbd6f71a66a63a811b541bde34a56487bf` | Applies configuration to ResourcesManager |
| core/java/android/app/ResourcesManager.java | `51d0b18467f4efb44731522b42c2eb65087fefb8` | Updates system Resources; separately overlays per-token configuration |

## Proposed independent system observation

Use one public `Context.createWindowContext(display, TYPE_APPLICATION_OVERLAY, null)` per active Compose root/display. This creates a context and configuration listener only. Never call `WindowManager.addView`, never create an overlay window, never request `SYSTEM_ALERT_WINDOW`, and never pass an activity window token. Keep the context strongly referenced while observing; register its own `ComponentCallbacks`, read initial `resources.configuration.uiMode`, and unregister the callback on disposal. Recreate the observer when the display identity changes. No repeated context creation during recompositions.

The public Context documentation states that a window context receives the configuration of its display area and, since API31, its own component callbacks instead of application callbacks. AOSP confirms that creation returns the selected DisplayArea configuration directly; the listener subsequently sends `mContainer.getConfiguration()`. WindowTokenClient installs that full configuration as this token's override. ResourcesManager overlays it after the process configuration, so an app-specific night override cannot overwrite the display area's night bits.

Sources: [Context API](https://developer.android.com/reference/android/content/Context#createWindowContext(android.view.Display,int,android.os.Bundle)); [registerComponentCallbacks](https://developer.android.com/reference/android/content/Context#registerComponentCallbacks(android.content.ComponentCallbacks)). Inspected primary source files:

| File | Git blob | Evidence |
| --- | --- | --- |
| core/java/android/app/ContextImpl.java | `dcbdc2348fbc244e9b84dbc39a24c3838552137d` | createWindowContextInternal creates token/resources and attaches to DisplayArea; no window added |
| services/core/java/com/android/server/wm/WindowManagerService.java | `1dbb6099f7504ed20d4715ecdc16d6bb86c97989` | attachWindowContextToDisplayArea returns `da.getConfiguration()`; MANAGE_APP_TOKENS only selects privileged area behavior |
| services/core/java/com/android/server/wm/WindowContextListenerController.java | `6d0da1fd36f5ed8a915b81a71de275c8273ef128` | Listener sends display-area configuration, and detach occurs when context is collected |
| core/java/android/window/WindowTokenClient.java | `a551fe701c5b34e62ecaf64bd1ef2c897b4dbfa9` | Updates token resources from received full configuration before dispatching callback |
| core/java/android/window/WindowContext.java | `84a8b8f5b5b0173a6675ae4623341559f9f8afc8` | Registers and unregisters context-local component callbacks |
| services/core/java/com/android/server/wm/RootDisplayArea.java | `092adc37d497353bd7a7e5c10c79481e1514db6c` | Rejects APPLICATION_LAYER for this path |

The window type must be the documented non-activity type `TYPE_APPLICATION_OVERLAY`, not `TYPE_APPLICATION`: the latter reaches APPLICATION_LAYER and is rejected by the inspected RootDisplayArea implementation. Context creation alone does not add any actual overlay or ask for overlay permission.

This is a source-supported implementation design, not a claim about a tested API37 device. A native API37 gate must establish the independent observation and absence of extra app windows. If the display/context cannot be obtained, represent the source as unavailable; do not silently label an app-forced value as system state. Root approved explicit Unknown, retaining the last displayed theme (or initial app configuration as a labelled fallback), with the Appearance notice «Не удалось определить системную тему. Предпросмотр сохраняет текущие цвета.» Applying SYSTEM remains available and clears the app override; preview/cancel never persist a platform override.

## Minimal integration scope

1. New isolated theme helper with platform mode mapping and an explicit observed/unavailable system theme state. It supplies a Compose observable from the window-context callback. It owns no screens, navigation, auth state, or persistent preview.
2. `AnalystApplication.onCreate`: synchronize the last saved valid preference/default DARK to the application platform mode. Do not create a display observer from background services or application startup; the observer belongs to an active UI root.
3. Core owner's `AnalystTheme`: replace app-local `isSystemInDarkTheme()` as the runtime SYSTEM source with the observer. Keep inspection behavior separate. In the existing `saveTheme` path only, persist saved preference and synchronize application mode; preview/cancel never call the platform setter. Existing `enableEdgeToEdge` continues to use the effective preview color mode.
4. `AndroidManifest.xml`: add only `uiMode` to MainActivity and BootstrapActivity handled configuration changes. Add the same to debug ProfileUiProbeActivity so its real theme container has the same lifecycle behavior. Do not suppress orientation, font scale, locale, display-size or other recreation.
5. Compose updates through the existing configuration dispatch and observable system-theme state. A custom MainActivity callback is not necessary just to recompose, and is not proposed without a demonstrated non-Compose resource gap. Existing system-bar SideEffect updates bar icon modes. Recheck any native resource-bound window background after the actual API37 run rather than guessing a callback is required.

The manifest change is deliberate: the application setter can cause a configuration change and recreation. The current Activity contains transient remembered auth/session/UI state, and Appearance applies its draft in the same call. Handling only `uiMode` preserves these owners while Compose recomposes. API37's newly suppressed desk-mode restarts do not cover arbitrary day/night changes. [Official configuration-change guidance](https://developer.android.com/guide/topics/resources/runtime-changes) documents both Compose behavior and this API37 distinction. Existing process-death/saveable behavior remains necessary and unchanged.

## Native verification required before release

Use only the current-PID owned synthetic API37 emulator and existing fixture mechanism; do not mutate a physical device for these checks. Record original global night policy/activation evidence and restore it with read-back in finally, just as other fixture-owned settings are restored.

- Force app DARK while OS is LIGHT, then preview SYSTEM: actual UI and diagnostic observed global bits must be LIGHT while saved preference/platform app override remain DARK. Cancel returns DARK without writes or recreation.
- Repeat app LIGHT with OS DARK. Toggle the actual OS mode while app override remains fixed; SYSTEM preview must follow the independent observer. This is the decisive check that rejects Resources.getSystem/isSystemInDarkTheme as a false source.
- Apply SYSTEM, then both system modes: native app resources and Compose must follow; app mode mapping clears override. Restore a forced saved mode and cold-start: native splash/background and body agree with the saved mode.
- Apply LIGHT/DARK from a real Appearance draft with unsaved controls/text; activity/owner identity and draft continuity must survive. Cancel/Back/discard must preserve their existing semantics, including the panels45 dirty-leave guards.
- Exercise unavailable/removed display/context path with an injected source failure in the helper's behavior test and native diagnostics: no crash, no false claim of a known system state, no unintended saved-mode change. The approved fallback preserves current colors and displays the short unavailable notice.
- Check active app windows/permissions before and after observer attachment and disposal: no extra overlay, no overlay permission, no retained callback after disposal. Validate bars under gesture and 3-button navigation if both are part of the configured native gate.
- Preserve all existing original automation counts and N00 gates; these theme lifecycle checks are additive, not a substitute for original14/full15.

First installation deserves an explicit distinction: the OS creates a starting window before Application can read app preferences. With no persisted platform override yet, that very first starting window follows the OS configuration. Synchronizing the app default in Application corrects the app and subsequent starts; it cannot retroactively change the already-created first splash. Do not claim that the first ever system splash always used the default DARK preference unless the real native capture proves it. After a saved mode/app sync, cold starts must use that saved mode.

## Runtime web publication requirement

The final46 deliverable includes the actual owned web surfaces on the running approved runtime9417611, not only APK resources. After real Windows46 checks, first compare current runtime source hashes and discover the actual served help path by read-only observation. Prepare a separate narrow deployment for the exact tested web files with preserved DB/config/session/owner binding, atomic backups/replacement, service restart only if needed, and health plus actual rendered endpoint verification. Do not assume runtime source matches the Git branch, replace the full backend, or develop/test app logic on the server. The owner denial page and its exact static stylesheet CSP hash are included in the reviewed assets bundle; startup binding, JSON responses and default-src policy remain unchanged.
