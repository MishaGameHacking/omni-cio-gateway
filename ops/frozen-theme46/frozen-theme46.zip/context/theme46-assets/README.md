# Theme46 assets, web colors, and application night-mode preparation

Preparation only. Nothing was applied to `analyst-ai`, a device, or a server. Application, tests and Kotlin compilation were not executed locally. The administrative generator performs only byte-identity checks and Python AST/XML parsing.

## Current review bundle

- `manifest.json`: 23 candidate files; SHA256 `a320b29b48f408945d9f446070a9ef126262e31c806a60fa4123d7367ae3fd50`.
- `theme46-assets.patch`: SHA256 `e01bcf00bd1f26a5ac1f062be9f9ee3efe6724326fb2bfaa35d32e414815a985`.
- `manifest-summary.json`: exact old/new sizes, SHA256 and Git blob identities without embedded source text.
- Approved palette: `bec4160ad8794cc251968dd3bc8199dcedcd188d5796eff2e0c3cd320845cf95`.
- Original44 inventory: `632690ecf7bca6a54b6f569567c6b6dbf7bfe0dab22b999e8bfa70ee74e94e67`, code `e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9`, source backup `1cc05586b6874bfdd0cdb80131d178de9f95870c`.

The earlier18-file owner-denial review bundle is preserved in `frozen-18/` with manifest `afb4afb1493fa68d8dcaabbb0891d859c7736e14ff0a00f43a5f7a810b82139a` and patch `249b2f488277376848466823313b7592ad8b9f7a09e0d812b022ef6b9f58bc78`.

## Scope

The resource portion adds matching day/night semantic colors and themes, explicit native splash/window/bar roles, and a code-native foreground vector using the existing launcher silhouette. Both API26 and active API33-qualified adaptive launchers use the vector; API37 therefore no longer picks the old fixed PNG. The monochrome mask retains its system-tinted purpose. Existing legacy PNG bytes remain as unreferenced compatibility assets.

The owned browser login, mobile return, owner callback denial and update-help page use the same day/night role values, paired hover/pressed/disabled colors and visible keyboard focus. The obsolete help hostname is changed only to the already configured `analyst-ai-2941515.twc1.net`.

The owner denial permits exactly its static stylesheet through `style-src 'sha256-qcgBPnXsLugjCFkYUttrq1QOAbctecMAabe6S6v5KJw='`. Its default-src, base-uri and frame-ancestors remain none; no script/unsafe-inline permission is introduced. Status403, error identity, message, deep link, JSON responses, startup binding and ownership logic remain unchanged. `static-scope-review.json` records byte/AST comparison of unchanged non-style/auth paths.

`ApplicationThemeMode.kt` supplies the single root/display observation of the true display-area configuration, explicit Known/Unknown states, application-only saved-mode synchronization and disposal. Application startup synchronizes the stored valid preference/default DARK. MainActivity, BootstrapActivity and the debug fixture declare only uiMode handling. There are no additional windows or overlay permission requests. The source-backed rationale and first-install splash limitation are in `LIFECYCLE_PROPOSAL.md`.

The core owner integrates AnalystTheme/saveTheme and the Appearance Unknown notice. The lifecycle owner prepares the separate native forced-app/opposite-OS observations; the palette owner prepares the state/color fixture and its router. Those files are intentionally absent from this23-file slice.

The strict brand identity test still carries the approved44 version assertions during preparation. Root must compose the actual45 baseline and46 version bump after Windows45 proof; these assertions must remain strict.

## Prepared validation

- Brand/resource checks resolve actual qualified launcher/color/theme resources, preserve native vector geometry and verify actual contrast pairs.
- Six backend HTML/CSS tests render the real functions and inspect the actual styles, interactive states, headers, escaped handoff and exact denial CSP digest; they read the actual Android resource colors.
- Eight JVM helper behavior tests exercise real production session subscription, initial reads, changes, partial registration/read failures, cleanup, callback disarming and unexpected failure propagation, plus application mode/configuration contracts.

These are prepared tests. They have not passed until the owner Windows full build executes them. Native API37 observations must prove independent system lookup under forced opposite application modes, apply-only platform writes, cancel/dirty-state preservation, cold-start behavior and absence of additional windows. Existing original14 and full15 gates remain separate.

## Browser surface inventory and deployment

The explicit backend HTML producers are `_login_page`, `mobile_login_result` and `owner_app._denial`; the static product help file is `.github/scripts/update-help.html`. `deploy/enroll_owner.py` returns text/plain setup callbacks. FastAPI also provides framework-generated API documentation through its defaults; no custom product HTML/CSS is authored for those framework pages in this patch.

The final46 task includes updating the actual running owned web pages after Windows checks. The prepared read-only observer is in `../theme46-runtime-observer/prepared-v2/`; it compares the three exact runtime web source files to both the44 reference and proposed46 bytes, without assuming the running tree matches the branch. It also discovers bounded static help candidates, including the original `/var/lib/analyst-ai/releases/help.html` mapping, and checks public bytes when observable. Raw source/configuration, DB, credentials and sessions are not exported. Deployment target mapping and ancestry must be reviewed before any later exact-file deployment; the observer does not authorize or perform one.
