"""Prepare reviewed theme46 resource/CSS bytes, without importing app or tests."""
from __future__ import annotations

import ast
import base64
import difflib
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'source'
REPO = ROOT / 'analyst-ai'
BASE_COMMIT = '1cc05586b6874bfdd0cdb80131d178de9f95870c'
PALETTE_SHA = 'bec4160ad8794cc251968dd3bc8199dcedcd188d5796eff2e0c3cd320845cf95'
INVENTORY_SHA = '632690ecf7bca6a54b6f569567c6b6dbf7bfe0dab22b999e8bfa70ee74e94e67'
VERSION_TEST = '.github/scripts/tests/test_spectrum_brand_identity.py'
MATERIAL_RESOURCES = {
    'background': 'background', 'on_background': 'onBackground', 'surface': 'surface', 'on_surface': 'onSurface',
    'primary': 'primary', 'on_primary': 'onPrimary', 'primary_container': 'primaryContainer',
    'on_primary_container': 'onPrimaryContainer', 'secondary': 'secondary', 'on_secondary': 'onSecondary',
    'secondary_container': 'secondaryContainer', 'on_secondary_container': 'onSecondaryContainer',
    'tertiary': 'tertiary', 'on_tertiary': 'onTertiary', 'tertiary_container': 'tertiaryContainer',
    'on_tertiary_container': 'onTertiaryContainer', 'surface_variant': 'surfaceVariant',
    'on_surface_variant': 'onSurfaceVariant', 'surface_container': 'surfaceContainer',
    'surface_container_highest': 'surfaceContainerHighest', 'outline': 'outline', 'outline_variant': 'outlineVariant',
    'error': 'error', 'on_error': 'onError', 'scrim': 'scrim',
}
SEMANTIC_RESOURCES = {'warning': 'warning', 'disabled_ink': 'disabledInk', 'disabled_container': 'disabledContainer'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def old_bytes(relative, inventory):
    path = ROOT / 'context/candidate44/source' / relative if relative == VERSION_TEST else REPO / relative
    if relative not in inventory['files']:
        assert not path.exists(), relative
        return None
    raw = path.read_bytes()
    assert {'bytes': len(raw), 'sha256': sha(raw)} == inventory['files'][relative], relative
    return raw


def save(relative, value):
    path = SOURCE / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding='utf-8', newline='\n')


def css_tokens(palette):
    material_names = {
        'bg': 'background', 'surface': 'surface', 'text': 'onSurface', 'muted': 'onSurfaceVariant',
        'primary': 'primary', 'on-primary': 'onPrimary', 'primary-container': 'primaryContainer',
        'on-primary-container': 'onPrimaryContainer', 'surface-container': 'surfaceContainer',
        'outline': 'outline', 'outline-variant': 'outlineVariant', 'danger': 'error',
    }
    blocks = []
    for mode in ('light', 'dark'):
        declarations = [f'color-scheme: {mode}']
        declarations += ['--' + name + ': #' + palette['material_roles'][mode][role] for name, role in material_names.items()]
        declarations += ['--disabled-ink: #' + palette['semantic_roles'][mode]['disabledInk'],
                         '--disabled-container: #' + palette['semantic_roles'][mode]['disabledContainer']]
        lines = ['  :root {'] + ['    ' + declaration + ';' for declaration in declarations] + ['  }']
        if mode == 'dark':
            lines = ['  @media (prefers-color-scheme: dark) {'] + ['  ' + line for line in lines] + ['  }']
        blocks.append('\n'.join(lines))
    return '\n'.join(blocks) + '\n'


LOGIN_CSS = '''  * { box-sizing:border-box; }
  body { min-height:100vh; margin:0; padding:max(24px,env(safe-area-inset-top)) 20px
         max(24px,env(safe-area-inset-bottom)); display:grid; place-items:center;
         background:var(--bg); color:var(--text);
         font:17px/1.48 system-ui,-apple-system,"Segoe UI",sans-serif; }
  main { width:min(100%,520px); padding:30px 24px; border:1px solid var(--outline-variant);
         border-radius:28px; background:var(--surface); }
  .mark { width:76px; height:76px; margin:0 auto 20px; display:grid; place-items:center;
          border-radius:24px; font-size:38px; background:var(--primary-container);
          color:var(--on-primary-container); }
  h1 { margin:0; text-align:center; font-size:clamp(30px,8vw,44px); line-height:1.1; }
  p { color:var(--muted); }
  .privacy { margin:18px 0 24px; padding:16px; border-radius:18px;
             background:var(--surface-container); }
  button,a { width:100%; min-height:56px; border:0; border-radius:18px; font:700 18px/1.2 inherit;
             display:flex; align-items:center; justify-content:center; text-decoration:none; }
  button { cursor:pointer; color:var(--on-primary); background:var(--primary); }
  button:not(:disabled):hover,button:not(:disabled):active {
    background:color-mix(in srgb,var(--on-primary) 8%,var(--primary)); }
  button:disabled { color:var(--disabled-ink); background:var(--disabled-container); cursor:wait; }
  a,a:visited { margin-top:14px; color:var(--primary); border:1px solid var(--outline);
                background:var(--surface); }
  a:hover,a:active { color:var(--on-primary-container); background:var(--primary-container); }
  button:focus-visible,a:focus-visible { outline:3px solid var(--primary); outline-offset:3px; }
  #status { min-height:48px; margin:18px 2px 0; text-align:center; }
  #status.error { color:var(--danger); }
  small { display:block; margin-top:22px; color:var(--muted); text-align:center; }
  ::selection { color:var(--on-primary-container); background:var(--primary-container); }
'''

RETURN_CSS = '''  body { min-height:100vh; display:grid; place-items:center; margin:0;
         padding:20px; box-sizing:border-box; background:var(--bg);
         color:var(--text); font:16px/1.5 system-ui,sans-serif; }
  main { text-align:center; max-width:440px; }
  a,a:visited { display:block; margin-top:22px; padding:14px 20px; border-radius:12px;
               background:var(--primary); color:var(--on-primary); font-weight:600; text-decoration:none; }
  a:hover,a:active { background:color-mix(in srgb,var(--on-primary) 8%,var(--primary)); }
  a:focus-visible { outline:3px solid var(--primary); outline-offset:3px; }
  small { color:var(--muted); }
  ::selection { color:var(--on-primary-container); background:var(--primary-container); }
'''

HELP_CSS = '''  body { margin:0; background:var(--bg); color:var(--text);
         font:16px/1.55 system-ui,sans-serif; padding:24px; }
  main { max-width:680px; margin:auto; background:var(--surface);
         border:1px solid var(--outline-variant); border-radius:24px; padding:24px; }
  h1 { margin-top:0; }
  .muted { color:var(--muted); }
  code { word-break:break-all; color:var(--primary); }
  ::selection { color:var(--on-primary-container); background:var(--primary-container); }
'''


def replace_style(source, css, *, python):
    matches = list(re.finditer(r'(<style(?: nonce="\{nonce_attr\}")?>)\n(.*?)</style>', source, re.S))
    assert len(matches) == 1
    match = matches[0]
    body = css.replace('{', '{{').replace('}', '}}') if python else css
    return source[:match.start(2)] + body + source[match.end(2):]


def build():
    palette_raw = (ROOT / 'context/theme46-audit/palette-proposal.json').read_bytes()
    inventory_raw = (ROOT / 'context/candidate44-original-evidence/source-final.json').read_bytes()
    assert sha(palette_raw) == PALETTE_SHA and sha(inventory_raw) == INVENTORY_SHA
    palette, inventory = json.loads(palette_raw), json.loads(inventory_raw)
    assert inventory['source_sha256'] == 'e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9'
    for mode in ('light', 'dark'):
        qualifier = 'values-night' if mode == 'dark' else 'values'
        values = {name: palette['material_roles'][mode][role] for name, role in MATERIAL_RESOURCES.items()}
        values.update({name: palette['semantic_roles'][mode][role] for name, role in SEMANTIC_RESOURCES.items()})
        colors = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>']
        colors += [f'    <color name="analyst_{name}">#{value}</color>' for name, value in values.items()]
        colors += ['    <color name="analyst_launcher_background">@color/analyst_surface</color>', '</resources>', '']
        save(f'app/src/main/res/{qualifier}/colors.xml', '\n'.join(colors))
        parent = 'Theme.Material.NoActionBar' if mode == 'dark' else 'Theme.Material.Light.NoActionBar'
        items = {
            'fontFamily': 'sans', 'windowNoTitle': 'true', 'forceDarkAllowed': 'false',
            'colorBackground': '@color/analyst_background', 'colorForeground': '@color/analyst_on_background',
            'textColorPrimary': '@color/analyst_on_surface', 'textColorSecondary': '@color/analyst_on_surface_variant',
            'textColorLink': '@color/analyst_primary', 'colorAccent': '@color/analyst_primary',
            'colorControlNormal': '@color/analyst_on_surface_variant', 'colorControlActivated': '@color/analyst_primary',
            'colorControlHighlight': '@color/analyst_primary_container', 'colorButtonNormal': '@color/analyst_surface_container',
            'colorError': '@color/analyst_error', 'windowBackground': '@color/analyst_background',
            'statusBarColor': '@android:color/transparent', 'navigationBarColor': '@android:color/transparent',
            'navigationBarDividerColor': '@android:color/transparent',
            'windowLightStatusBar': 'false' if mode == 'dark' else 'true',
            'windowLightNavigationBar': 'false' if mode == 'dark' else 'true',
            'enforceStatusBarContrast': 'false', 'enforceNavigationBarContrast': 'false',
            'windowSplashScreenBackground': '@color/analyst_background',
            'windowSplashScreenAnimatedIcon': '@drawable/omni_launcher_foreground',
            'windowSplashScreenBehavior': 'icon_preferred',
        }
        themes = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>',
                  f'    <style name="Theme.OMNICIO" parent="@android:style/{parent}">']
        themes += [f'        <item name="android:{name}">{value}</item>' for name, value in items.items()]
        themes += ['    </style>', '</resources>', '']
        save(f'app/src/main/res/{qualifier}/themes.xml', '\n'.join(themes))
    for name in ('analyst_launcher_background', 'omni_launcher_background'):
        save('app/src/main/res/drawable/' + name + '.xml', '''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="@color/analyst_launcher_background" />
</shape>
''')
    monochrome = old_bytes('app/src/main/res/drawable/omni_launcher_monochrome.xml', inventory).decode('utf-8')
    assert monochrome.count('android:fillColor="#FFFFFFFF"') == 1
    save('app/src/main/res/drawable/omni_launcher_foreground.xml',
         monochrome.replace('android:fillColor="#FFFFFFFF"', 'android:fillColor="@color/analyst_primary"'))
    for qualifier in ('mipmap-anydpi-v26', 'mipmap-anydpi-v33'):
        for name in ('ic_launcher', 'ic_launcher_round'):
            save('app/src/main/res/' + qualifier + '/' + name + '.xml', '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/omni_launcher_background" />
    <foreground android:drawable="@drawable/omni_launcher_foreground" />
    <monochrome android:drawable="@drawable/omni_launcher_monochrome" />
</adaptive-icon>
''')
    brain = old_bytes('app/src/main/res/drawable/analyst_brain_foreground.xml', inventory).decode('utf-8')
    for old, new in {'#252C40': '@color/analyst_surface_container_highest', '#68D8C5': '@color/analyst_primary',
                     '#B6A2FF': '@color/analyst_tertiary', '#F4F7FF': '@color/analyst_on_background',
                     '#F5C771': '@color/analyst_warning'}.items():
        assert brain.count(old) == 1
        brain = brain.replace(old, new)
    save('app/src/main/res/drawable/analyst_brain_foreground.xml', brain)
    for relative, styles in (('backend/telegram_browser_app.py', LOGIN_CSS), ('backend/app.py', RETURN_CSS),
                             ('.github/scripts/update-help.html', HELP_CSS)):
        old = old_bytes(relative, inventory).decode('utf-8')
        source = replace_style(old, css_tokens(palette) + styles, python=relative.endswith('.py'))
        if '<meta name="color-scheme"' not in source:
            assert source.count('<title>') == 1
            source = source.replace('<title>', '<meta name="color-scheme" content="light dark">\n<title>', 1)
        if relative == '.github/scripts/update-help.html':
            assert source.count('176.98.178.81.sslip.io') == 1
            source = source.replace('176.98.178.81.sslip.io', 'analyst-ai-2941515.twc1.net')
        save(relative, source)
    owner = old_bytes('backend/owner_app.py', inventory).decode('utf-8')
    denial_css = '\n' + css_tokens(palette) + RETURN_CSS
    denial_style_hash = base64.b64encode(hashlib.sha256(denial_css.encode('utf-8')).digest()).decode('ascii')
    marker = 'MESSAGE = "Эта установка Analyst AI доступна только её владельцу."\n'
    assert owner.count(marker) == 1
    owner = owner.replace(marker, marker + '\n# Only these static CSS bytes are admitted by the denial page CSP.\n' +
                          'DENIAL_STYLE = """' + denial_css + '"""\n' +
                          'DENIAL_STYLE_SHA256 = ' + repr(denial_style_hash) + '\n', 1)
    old_page = '''            '<!doctype html><html lang="ru"><meta name="viewport" content="width=device-width">'
            '<title>Analyst AI</title><p>' + MESSAGE + '</p><a href="' + link
            + '">Вернуться в Analyst AI</a></html>', status_code=403,'''
    new_page = '''            '<!doctype html><html lang="ru"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width">'
            '<meta name="color-scheme" content="light dark"><title>Analyst AI</title>'
            '<style>' + DENIAL_STYLE + '</style></head><body><main><p>' + MESSAGE + '</p><a href="' + link
            + '">Вернуться в Analyst AI</a></main></body></html>', status_code=403,'''
    assert owner.count(old_page) == 1
    owner = owner.replace(old_page, new_page, 1)
    old_csp = '''"Content-Security-Policy": "default-src 'none'; base-uri 'none'; frame-ancestors 'none'"'''
    new_csp = '''"Content-Security-Policy": "default-src 'none'; style-src 'sha256-" + DENIAL_STYLE_SHA256
                     + "'; base-uri 'none'; frame-ancestors 'none'"'''
    assert owner.count(old_csp) == 1
    save('backend/owner_app.py', owner.replace(old_csp, new_csp, 1))
    application = old_bytes('app/src/main/java/ru/omnicio/app/AnalystApplication.kt', inventory).decode('utf-8')
    import_anchor = 'import ru.omnicio.app.data.diagnostics.ClientDiagnostics\n'
    call_anchor = '        ClientDiagnostics.install(this)\n'
    assert application.count(import_anchor) == application.count(call_anchor) == 1
    application = application.replace(import_anchor, import_anchor +
        'import ru.omnicio.app.ui.theme.storedApplicationTheme\n' +
        'import ru.omnicio.app.ui.theme.syncSavedApplicationTheme\n', 1)
    application = application.replace(call_anchor, call_anchor +
        '        syncSavedApplicationTheme(this, storedApplicationTheme(this))\n', 1)
    save('app/src/main/java/ru/omnicio/app/AnalystApplication.kt', application)
    main_manifest = old_bytes('app/src/main/AndroidManifest.xml', inventory).decode('utf-8')
    for activity in ('BootstrapActivity', 'MainActivity'):
        anchor = f'            android:name=".{activity}"\n'
        assert main_manifest.count(anchor) == 1
        main_manifest = main_manifest.replace(anchor, anchor + '            android:configChanges="uiMode"\n', 1)
    save('app/src/main/AndroidManifest.xml', main_manifest)
    debug_manifest = old_bytes('app/src/debug/AndroidManifest.xml', inventory).decode('utf-8')
    anchor = '            android:screenOrientation="portrait"\n'
    assert debug_manifest.count(anchor) == 1 and '.ProfileUiProbeActivity' in debug_manifest
    save('app/src/debug/AndroidManifest.xml', debug_manifest.replace(anchor,
         '            android:configChanges="uiMode"\n' + anchor, 1))
    brand = old_bytes(VERSION_TEST, inventory).decode('utf-8')
    split = '    def test_android_17_live_ui_candidate_has_a_unique_upgrade_code(self):'
    assert brand.count(split) == 1
    prefix = (OUT / 'brand-checks-prefix.py.txt').read_text(encoding='utf-8')
    save(VERSION_TEST, prefix + split + brand.split(split, 1)[1])
    records, patch = [], []
    for path in sorted(SOURCE.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(SOURCE).as_posix()
        raw = path.read_bytes()
        previous = old_bytes(relative, inventory)
        if path.suffix == '.xml':
            ET.fromstring(raw)
        elif path.suffix == '.py':
            ast.parse(raw, filename=relative)
        records.append({'path': relative, 'old_bytes': len(previous) if previous is not None else None,
                        'old_sha256': sha(previous) if previous is not None else None,
                        'old_git_blob': blob(previous) if previous is not None else None,
                        'new_bytes': len(raw), 'new_sha256': sha(raw), 'new_git_blob': blob(raw),
                        'content': raw.decode('utf-8')})
        patch.extend(difflib.unified_diff((previous.decode('utf-8') if previous is not None else '').splitlines(keepends=True),
                     raw.decode('utf-8').splitlines(keepends=True), fromfile='a/' + relative if previous is not None else '/dev/null',
                     tofile='b/' + relative))
    manifest = {'schema': 1, 'reference_commit': BASE_COMMIT, 'preparation_only': True,
                'baseline_source_sha256': inventory['source_sha256'], 'actual44_inventory_sha256': INVENTORY_SHA,
                'approved_palette_sha256': PALETTE_SHA, 'files': records,
                'version_managed_paths': [VERSION_TEST], 'version_test_preserved_as44_until_root46_union': True,
                'application_or_tests_executed': False, 'repository_applied': False,
                'launch_lifecycle_bridge_status': 'root-approved isolated helper/Application/only-uiMode manifests; core saveTheme/Unknown UI integration owned by plan_audit; native37 proof pending',
                'opaque_legacy_png_status': 'kept_as_unreferenced_compatibility_resource; all active launcher/splash refs use native vector',
                'web_security_and_business_logic_status': 'CSS/color-scheme only except owner denial static style-src SHA256; unchanged default-src/auth/JS/routes/403/JSON branches',
                'owner_denial_style_sha256_base64': denial_style_hash,
                'runtime_web_publication_required_after_windows46': True,
                'runtime_web_publication_gate': 'read-only exact runtime source/help comparison first; never assume branch equality',
                'help_host_correction': 'owner-authorized replacement of obsolete text host with current pinned BackendConfig.HOST'}
    (OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    (OUT / 'theme46-assets.patch').write_text(''.join(patch))
    summary = {key: value for key, value in manifest.items() if key != 'files'}
    summary['files'] = [{key: value for key, value in row.items() if key != 'content'} for row in records]
    for name in ('manifest.json', 'theme46-assets.patch'):
        raw = (OUT / name).read_bytes()
        summary[name] = {'bytes': len(raw), 'sha256': sha(raw)}
    (OUT / 'manifest-summary.json').write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'file_count': len(records), 'manifest': summary['manifest.json'], 'patch': summary['theme46-assets.patch'],
                      'validation': 'AST/XML parsing only; no app, compiler or tests executed'}))


if __name__ == '__main__':
    build()
