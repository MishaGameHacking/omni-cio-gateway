"""Prepare the exact native45 switch-visibility repair for a full Windows build."""
import argparse
import ast
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib
import zipfile
import io
import yaml

CONTEXT = Path(__file__).resolve().parent
PRIOR = CONTEXT / "candidate45-retry3-bound"
REPAIR = CONTEXT / "automation45-switch-repair"
REVIEW_SHA = "ef48fc46f81237558064b5e227e069fe7250d1a23b3beb76875f5039309dab8d"
WORKFLOW_SHA = "1f02d25141e8ef67c4b3e5d63c641689a2b3d67d7d60ff10712446040e18912e"
BOOTSTRAP_SHA = "9e4b061008d9596d5a104ea35e080405a3a569508b3f51b9fc7fb802d7adb3fc"
GUEST_SHA = "9c92c16d88a9e69a6e9b73b61f0e1eff8cd6b1b457451ee104c07bd17a7e29f0"
GENERATOR_SHA = "69bfb8dbefd2cb3ce7bbf03dbd3bbbaf90c66b8b6fb5d38873a6f27e878ecf9a"
BASE = "1cc05586b6874bfdd0cdb80131d178de9f95870c"
SOURCE = "e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9"
FILES = {".github/scripts/automation_ui_probe.py", ".github/scripts/tests/test_automation_error_visibility.py"}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected):
    need(CONTEXT in path.parents and path.resolve(strict=True) == path and not path.is_symlink()
         and path.is_file() and path.stat().st_nlink == 1, "Canonical input required")
    raw = path.read_bytes()
    need(sha(raw) == expected, "Pinned input changed: " + str(path))
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repair-sha256", required=True)
    args = parser.parse_args()
    output, repair_sha = args.output.absolute(), args.repair_sha256
    need(CONTEXT in output.parents and not output.exists()
         and output.parent.resolve(strict=True) == output.parent, "New context output required")
    path = CONTEXT / "prepare_candidate45.py"
    read(path, GENERATOR_SHA)
    spec = importlib.util.spec_from_file_location("reviewed_admin45_retry4", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.verify_transport_source()
    _, previous44 = helper.reviewed_files()
    prior = json.loads(read(PRIOR / "reviewed-files.json", REVIEW_SHA))
    repair = json.loads(read(REPAIR / "manifest.json", repair_sha))
    need(prior["confirmed_base44_backup_commit"] == BASE and prior["base44_code_inventory_sha256"] == SOURCE
         and prior["version_after"] == {"code": 45, "name": "0.13.7"} and len(prior["files"]) == 24,
         "Prior exact candidate changed")
    changes = {row["path"]: row for row in repair["source_files"]}
    need(repair["frozen"] is True and repair["base_reviewed_files_sha256"] == REVIEW_SHA
         and repair["source_file_count"] == len(repair["source_files"]) == len(changes) == 2
         and set(changes) == FILES and repair["android_production_changed"] is False
         and repair["shared_admission_guard_changed"] is False and repair["unchanged_case_count"] == 26,
         "Repair widened beyond the observed native visibility failure")
    archive_raw = read(CONTEXT / "candidate45-navigation-native.zip",
         "897f92cb1178f6eed70fc211246bbe8c0128226b90caad0e61dbe8c7fdace528")
    with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
        prefix = "omni-cio-gateway/omni-cio-gateway/windows-development-40299194135-1/app/build/outputs/apk/preview/ui-screens/"
        actual = json.loads(archive.read(prefix + "navigation-focused-observations.json"))
        for suffix in ("xml", "png"):
            need(sha(archive.read(prefix + "navigation-focused-failure." + suffix)) ==
                 repair["observed_failure"][suffix + "_sha256"], "Original native failure capture changed")
    need(actual["navigation_complete"] is False and actual["error_type"] == "AssertionError"
         and actual["error"] == "Native automation switch did not reach its acknowledged state",
         "Actual native45 failure identity differs")
    patch = read(REPAIR / "candidate.patch", repair["patch_sha256"])
    review = copy.deepcopy(prior)
    rows = review["files"]
    for row in rows:
        old = read(PRIOR / "source" / row["path"], row["new_sha256"])
        need(old == row["content"].encode() and len(old) == row["new_bytes"], "Prior source bytes differ")
        if row["path"] not in FILES:
            continue
        entry = changes[row["path"]]
        need(entry["old_sha256"] == sha(old) and entry["old_bytes"] == len(old)
             and entry["old_git_blob"] == helper.git_blob(old), "Repair old bytes differ")
        raw = read(REPAIR / "source" / row["path"], entry["new_sha256"])
        need(len(raw) == entry["new_bytes"] and helper.git_blob(raw) == entry["new_git_blob"], "Repair new bytes differ")
        ast.parse(raw)
        row.update(content=raw.decode(), new_sha256=sha(raw), new_bytes=len(raw))
    existing = {row["path"] for row in rows}
    for name in sorted(FILES - existing):
        entry = changes[name]
        need(entry["old_sha256"] is None and entry["old_bytes"] is None and entry["old_git_blob"] is None,
             "New regression unexpectedly overwrites an existing path")
        raw = read(REPAIR / "source" / name, entry["new_sha256"])
        need(len(raw) == entry["new_bytes"] and helper.git_blob(raw) == entry["new_git_blob"], "New regression bytes differ")
        ast.parse(raw)
        rows.append({"path": name, "old_git_blob": None, "old_sha256": None, "old_bytes": None,
                     "new_sha256": sha(raw), "new_bytes": len(raw), "content": raw.decode()})
    prior_rows = {row["path"]: row for row in prior["files"]}
    need({row["path"] for row in rows if row != prior_rows.get(row["path"])} == FILES
         and len(rows) == 25, "Unexpected source delta")
    rows.sort(key=lambda row: row["path"])
    review.update(source_file_count=25, existing_files=18, new_files=7)
    _, inventory = helper.verify_base_inventory(CONTEXT / "candidate44-original-evidence/source-final.json",
                                                SOURCE, rows, previous44)
    review.update(kind="reviewed_candidate45_retry4_after_actual_native_visibility_failure",
                  prior_reviewed_files_sha256=REVIEW_SHA, repair_paths=sorted(FILES),
                  repair_evidence={"manifest_sha256": repair_sha, **repair["observed_failure"]})
    review_raw = helper.json_bytes(review)
    bundle = helper.json_bytes({"reference_commit": BASE, "files": rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = helper.json_bytes({"schema": 1, "base_commit": BASE, "bundles": [{"name": "n00-native45",
        "transport_sha256": sha(transport), "decoded_sha256": sha(bundle)}]}, compact=True)
    bootstrap = read(PRIOR / "windows-full-development.py", BOOTSTRAP_SHA)
    guest = read(PRIOR / "n00-linux-guest.py", GUEST_SHA)
    need(bootstrap == helper.bootstrap(BASE, SOURCE), "Proven bootstrap changed")
    before = yaml.safe_load(read(PRIOR / "workflow.yml", WORKFLOW_SHA))
    after = copy.deepcopy(before)
    after["name"] = "Side and bottom panels; candidate45 actual native switch visibility repair"
    after["jobs"]["develop"]["name"] = "Apply twenty-five reviewed candidate45 files on the laptop and perform the full build"
    for index, name, raw in ((5, "n00-native45.b64", transport), (6, "patch-manifest.json", manifest)):
        step = after["jobs"]["develop"]["steps"][index]
        replacement = helper.stage(name, raw)
        need(step["name"] == replacement["name"] and step["shell"] == replacement["shell"], "Unexpected staged step")
        step["run"] = replacement["run"]
    restored = copy.deepcopy(after)
    restored["name"] = before["name"]
    restored["jobs"]["develop"]["name"] = before["jobs"]["develop"]["name"]
    for index in (5, 6):
        restored["jobs"]["develop"]["steps"][index]["run"] = before["jobs"]["develop"]["steps"][index]["run"]
    need(restored == before, "Workflow execution/transport changed")
    workflow = yaml.safe_dump(after, allow_unicode=True, sort_keys=False, width=120).encode()
    summary = {"state": "prepared_only_no_application_or_test_execution", "base_commit": BASE,
        "base_source_sha256": SOURCE, "base44_inventory": inventory, "reviewed_files_sha256": sha(review_raw),
        "bootstrap_sha256": sha(bootstrap), "guest_sha256": sha(guest), "patch_manifest_sha256": sha(manifest),
        "workflow_sha256": sha(workflow), "bundle_sha256": sha(bundle), "transport_sha256": sha(transport),
        "source_paths": 25, "new_source_paths": 7, "unchanged_retry3_rows": 23,
        "approved_repair_manifest_sha256": repair_sha, "repairs": sorted(FILES),
        "source_applied_on_windows": False, "build_passed": False, "runtime_passed": False,
        "phone_verified": False, "publication_performed": False, "n00_complete": False}
    outputs = {"reviewed-files.json": review_raw, "bundle.json": bundle, "n00-native45.b64": transport,
        "patch-manifest.json": manifest, "windows-full-development.py": bootstrap, "n00-linux-guest.py": guest,
        "workflow.yml": workflow, "manifest-summary.json": helper.json_bytes(summary), "repair.patch": patch}
    output.mkdir()
    for name, raw in outputs.items():
        with (output / name).open("xb") as stream:
            stream.write(raw)
    for row in rows:
        p = output / "source" / row["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("xb") as stream:
            stream.write(row["content"].encode())
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
