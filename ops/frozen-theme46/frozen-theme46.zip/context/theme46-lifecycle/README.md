# Theme46 lifecycle native gate — preparation only

The three new source files in this directory have not been applied, compiled,
imported or executed. All application and test execution is reserved for the
existing Windows laptop. Source hashing and Python AST parsing are administrative
checks only. The actual45 source backup and the combined46 Windows build remain
required before any native run.

## Files and ownership

- `source/app/src/debug/java/ru/omnicio/app/ThemeLifecycleProbe.kt`: finite debug
  fixture and run-bound restoration of the nine presentation keys changed by
  the real Appearance Apply path.
- `source/.github/scripts/theme_lifecycle_probe.py`: four mandatory native cases
  and independent JSON/XML/PNG evidence. Entry point:
  `exercise_theme_lifecycle(probe)` with the existing `ProfileProbe` and its live
  `FrameReader` inside the existing canonical emulator lease.
- `source/.github/scripts/tests/test_theme_lifecycle_probe.py`: 26 prepared
  host regression tests that call the actual marker, state, window, radio,
  editable-draft and cleanup helpers. These are not native acceptance.
- `router-delta.json` and `router-delta.patch`: the only integration into
  `ProfileUiProbeActivity`. The core theme owner remains its sole writer and
  merges this delta with the palette fixture; the original router is not edited
  in this package.

The route is `theme-lifecycle`. A valid request has one 32-hex session ID,
one fresh 32-hex launch run ID, and phase `begin`, `continue`, or `restore`.
`ThemeLifecycleSession.open(Activity, request)` runs once in the real
Activity.onCreate before the `AnalystTheme` root. `ThemeLifecycleProbe(session)`
then uses that same root and its single `LocalSystemThemeObservation`. It creates
neither another observer nor a new theme/color scheme. The production helper,
Application startup, manifests, actual palette and `AnalystTheme` save path are
owned by the other two theme packages.

Generic launch allowlists, old case IDs, 26 automation cases, original14,
15-stage schema, quote assertions and panel45 assertions are unchanged. The
parent chooses the separate additional wrapper/native stage after combined
source freeze. This file does not silently add work to an old accepted count.

The palette owner may reuse `_launch(probe, session, phase, scale, uid, deadline,
folder)` to create the same run-bound snapshot before its first theme write and
restore it afterward. That helper assumes the caller has already established
`_owned_emulator(probe)` and the canonical lease. Cleanup must use a fresh
deadline and always attempt the restore phase, even if the initial launch did
not return its marker. This reuse does not add a second root observer. Palette
work that never changes the OS must preserve its actual original global policy;
auto/custom policy is not evidence of a computed dark/light state.

## Four finite native cases

Each case runs on the real phone viewport at font scale 1.0 or 2.0. The two
directions are forced app DARK with OS LIGHT, and forced app LIGHT with OS DARK.
Both modes are selected and applied through the actual `AppearanceScreen`.

1. Enter `THEME_DRAFT` once through the production native `SpectrumTextField`.
   Observe the real editable value, caret and keyboard, then dismiss the IME.
2. Change a real Appearance accent control and apply the forced theme. This is
   a dirty, enabled Apply action even when the initial saved mode already equals
   the requested mode. Require saved theme/control, native app resources and
   rendered Compose colors to agree while the OS has the opposite setting.
3. Preview a different accent and SYSTEM. Require independent system observation
   and body colors to follow the opposite OS, while saved keys and app-native
   resources remain in the forced mode. Toggle the actual OS twice and repeat
   the same independent checks without a second tap or reconstructed selection.
4. In the DARK direction use the real Cancel button; in the LIGHT direction use
   the real visible Back button. Require saved keys and the previous accent to
   return, then reopen Appearance and read its actual checked radio choices.
5. Preview SYSTEM and a dirty accent again, apply both, and toggle both OS modes.
   Require actual app configuration/resources and Compose colors to follow the
   OS, with saved SYSTEM and an unchanged saved-key digest across those toggles.
6. Apply a forced theme with another real dirty control. Require the original
   Activity identity, remembered root owner, production editor restoration owner,
   process and native window throughout all non-cold changes. On return, read
   `THEME_DRAFT` from the actual native editable field again.
7. Explicitly force-stop and cold-start the debug fixture with a fresh run ID.
   Require new Activity/root/editor/process identities, the same saved-key
   digest and original restoration snapshot, and correct forced body colors and
   native onCreate configuration/window/splash resource attributes. The local
   unsaved synthetic text now correctly starts again at `THEME`.

Every action is one real coordinate tap after the existing three-frame native
settlement. It additionally enforces the real 48dp target using actual density,
exact app/window affinity and enabled geometry. Selected radio observation is
strict native `checkable=true, checked=true` on the exact unique finite label;
Compose exports radio selection as checked state, including merged View nodes.
The matched label must have positive native bounds fully inside its checked
owner and the actual viewport; hidden/foreign intermediates or clipped labels
cannot borrow a visible checked row. Geometry negatives exercise the real
validator, including an intermediate scroll viewport. Merged native labels on
the checked owner itself remain valid.
This does not alter the separate Tab selected-state contract used by quotes.
Both helper callers use the shared maximum of 20 scrolls. Two prepared seam
regressions invoke the actual case `selected()` and `tap()` paths through the
real shared reveal admission; an invalid former limit of 24 fails there rather
than being accepted by a test double.

## What the evidence actually observes

The tiny fixture marker reports actual saved theme/key digest, root effective
mode, actual LocalConfiguration night bits, the shared independent display-area
observation, actual MaterialTheme background/foreground, native resources and
window theme attributes, public system-bar appearance flags and permission
checks. There is no invented `getApplicationNightMode` API or setter counter.
The decisive preview case requires these independent sources to disagree in the
expected way; an app-local fallback presented as system state cannot pass.

The window census reads bounded, complete `dumpsys window windows` output.
It binds the app's actual installed UID and exact fixture component and rejects
any app overlay or extra final window. A real platform starting window remains
pending and cannot count as the final Activity window. Before attach and after
dispose it requires zero app windows, during the fixture exactly one base
Activity window; no overlay permission/capability may appear. The full global
window dump is not exported: the receipt stores only the fixture records and
the dump hash.

The receipt is `theme-lifecycle-verification.json` in the existing private
`app/build/outputs/apk/preview/ui-screens` evidence directory. Schema version 1
includes the exact debug APK digest, session, four case identities, native
targets, observations, captures and restoration. It says `passed` only after
all four cases and exact restoration succeed. Each capture has PNG/XML hashes.
The helper records the local debug APK hash. The enclosing Windows native
wrapper must separately bind the actual installed APK, driver, source backup
and successful build receipts to those exact bytes; this helper receipt alone
is not standalone build/installation provenance.
There are no real broker/model/network requests, accounts or order submissions.

## Bounded restoration

Before any setting mutation, `_owned_emulator` requires the actual persistent
FrameReader, API37 disposable emulator properties and the console AVD name
owned by this current `test_apk_installation` process (`analyst-install-PID-1/2`).
A physical, other-run or broken transport is refused. The parent retains the
canonical shared lease and OwnedJob controller. No new lease or device is made.

The helper requires an already explicit global `night yes` or `night no`.
It reads and later restores that exact policy and original font-scale string.
Auto/custom policy is rejected before mutation because its activation overrides
cannot be exactly round-tripped by this finite shell command. The ordinary
theme stage currently leaves explicit `no`; a separate wrapper must establish
and own its outer settings scope if it starts elsewhere.

The fixture snapshots only `theme_mode` and the eight WorkspacePreferences
keys. It preserves both values and key absence, rejects unknown types/enum
values, and binds the private snapshot to its session. It never replaces an
incomplete snapshot from another session. Cold starts require that same
snapshot. The finally path attempts OS policy, font and app restoration even
after a native assertion or partial cleanup error. A fresh restore launch
reinstates the exact nine keys before creating the real theme root and calls
the production saved-mode synchronization. The gate checks raw snapshot digest,
original key absence/mode, actual body/resource state and settings read-back.
Only the explicit successful cleanup button clears the run-owned snapshot and
finishes the fixture. Cleanup errors preserve the original failure and keep the
additional gate incomplete.

The case budget is finite: 15 minutes for four cases, existing bounded native
operations and a separate 3-minute application cleanup allowance. The helper
does not resize the display or change density/navigation/animation settings.

## Limits retained in the receipt

- This preparation is not a build or native pass, and never closes N00 or grants
  the full release gate. Original14 and both full 4096/16384 profiles remain.
- Cold-start checks cover saved forced LIGHT and DARK. Saved SYSTEM is exercised
  through real Apply and both actual OS changes, but a separate cold start under
  saved SYSTEM is not claimed by these four cases.
- Actual onCreate resource and splash-attribute values are observed. The brief
  system-rendered starting-window pixels are not captured or claimed; the JSON
  explicitly records `native_starting_window_pixels_captured=false`.
- Unavailable source behavior belongs to the prepared production helper/JVM
  behavior tests. This native fixture requires a known independent source and
  records `native_unavailable_source_path_exercised=false`.
- Existing navigation mode is preserved. Native bar flags are checked in that
  actual mode; this does not claim a separate gesture/three-button mode matrix.
- The synthetic text proves the existing native editor and its owner survive
  uiMode changes. The production strategy dirty-leave regression remains the
  separate unchanged panels45 native gate.

## Primary API/source references

- UiModeManager public API (saved application mode versus global policy):
  https://developer.android.com/reference/android/app/UiModeManager
- Dark-theme native splash synchronization guidance:
  https://developer.android.com/develop/ui/views/theming/darktheme
- Current AOSP global shell policy output, inspected blob
  `896c9b8d0932a2860acf8250826cd752f87a0428`:
  https://android.googlesource.com/platform/frameworks/base/+/master/services/core/java/com/android/server/UiModeManagerService.java
- AndroidX actual radio-versus-tab accessibility tests:
  https://android.googlesource.com/platform/frameworks/support/+/79353bfe455684ea90e2973087df508359dcecb3/compose/ui/ui/src/androidInstrumentedTest/kotlin/androidx/compose/ui/AndroidAccessibilityTest.kt
- The independent display-area observation and its inspected AOSP blob evidence
  are documented in `context/theme46-assets/LIFECYCLE_PROPOSAL.md`.
