"""Render an administrative-only preview43 workflow. No network/app/test execution."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'context/delivery43'
OLD_WORKFLOW = ROOT / 'admin-transport/.github/workflows/deliver-preview38.yml'
TRANSPORT_WORKFLOW = ROOT / 'context/candidate43/workflow.yml'
BUILD_REPORT = ROOT / 'context/candidate43-verified-build/windows-development.json'
TARGET = '.github/workflows/deliver-preview43.yml'
PIN = 'cd1866ee944ccea2259669f4293379241fd4ee02'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def render():
    verified_raw = BUILD_REPORT.read_bytes()
    assert sha(verified_raw) == 'c3e9281b4dfe9128a87b4cb7679675ecb2926774672ecb59f5825be46c214225'
    build = json.loads(verified_raw)
    assert build['github']['run_id'] == 40277268871 and build['github']['run_attempt'] == 1
    assert build['status'] == 'passed_check_and_build_only'
    assert build['check']['status'] == build['build']['status'] == 'passed'
    assert build['source_sha256'] == build['source_sha256_after'] == '269b6755933d6504082a9ee4bc86dbbf458beb22abcb51918c852cccddefd11b'
    native_provenance = json.loads((ROOT / 'context/native43/build-provenance.json').read_bytes())
    assert native_provenance['source_backup_commit'] == '859c067198e52927df1b66983d02841e3fa6ff6a'
    assert native_provenance['build_report_sha256'] == sha(verified_raw)
    install_path = ROOT / 'context/native43-original14/omni-cio-gateway/omni-cio-gateway/windows-development-40278915893-1/app/build/outputs/apk/preview/install-api37-16384/install-results.json'
    install_raw = install_path.read_bytes()
    assert sha(install_raw) == 'c4f7655fdc99d24752845ba44509dbcd574954113b2457dce508a462022604ff'
    install_rows = json.loads(install_raw)
    tests = {row['test']: row for row in install_rows}
    assert len(tests) == len(install_rows)
    for name in ('kernel_page_size', 'upgrade_to_candidate', 'upgrade_bootstrap_launch', 'candidate_clean_install', 'bootstrap_activity_launch'):
        assert tests[name]['success'] is True
        assert tests[name]['apk_sha256'] == '4e9bf0a2fd54d8ab4b9d49ef9ddf96bc14a274ac4c145585fcfdb88d6ae774b6'
    assert tests['kernel_page_size']['android_api'] == 37
    assert tests['kernel_page_size']['page_size_bytes'] == 16384
    assert tests['kernel_page_size']['abi'] == 'x86_64'
    assert tests['previous_clean_install']['success'] is True
    assert tests['previous_clean_install']['apk_sha256'] == '058e307855cad135a30bccc8a4a5bafc96638fd8400ba31fda0af07f255d0bef'
    assert tests['profile_ui']['success'] is False
    workflow = yaml.safe_load(OLD_WORKFLOW.read_text())
    transport = yaml.safe_load(TRANSPORT_WORKFLOW.read_text())
    step = next(value for value in transport['jobs']['collect']['steps']
                if value.get('name') == 'Save verified evidence on Timeweb without publishing')
    script = step['run']
    assert script.startswith("python3 - <<'PY'\n") and script.endswith('PY\n')
    script = script[len("python3 - <<'PY'\n"):-len('PY\n')]
    tree = ast.parse(script)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'with_ams')
    prefix = ''.join(script.splitlines(keepends=True)[:function.end_lineno]) + '\n\n'
    assert 'sid=9417611;' in prefix and 'sid=9415007' not in prefix
    assert 'Analyst AI runtime 20261025' in prefix and 'project_id"]==2941515' in prefix
    assert 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILN7hxzg6D6GjaE9OYQ19wH86tSm10pTnv+s81eqOfIU runner@runnervmtai0g' in prefix
    old_step = workflow['jobs']['deliver']['steps'][0]
    assert old_step['with']['ref'] == PIN and old_step['with']['persist-credentials'] is False
    payload = (OUT / 'publish-preview43.py').read_text()
    verify = (OUT / 'verify-public43.py').read_text()
    ast.parse(payload)
    ast.parse(verify)
    remote = ('import subprocess\n'
              "result=subprocess.run(['/opt/analyst-ai/venv/bin/python','-c'," + repr(payload) + '],'
              'stdin=subprocess.DEVNULL,timeout=180)\n'
              'raise SystemExit(result.returncode)\n')
    ast.parse(remote)
    hosted = prefix + 'remote = ' + repr(remote) + '\n' + verify
    ast.parse(hosted)
    workflow['name'] = 'Deliver exact preview43 at the owner request'
    workflow['on']['push']['paths'] = [TARGET]
    workflow['concurrency'] = {'group': 'owner-preview-release-publication', 'cancel-in-progress': False}
    job = workflow['jobs']['deliver']
    job['if'] = "github.repository == 'MishaGameHacking/omni-cio-gateway' && github.ref == 'refs/heads/codex/timeweb-owner-prepare-2026-10-23' && github.event_name == 'push'"
    job['timeout-minutes'] = 12
    job['steps'][1]['name'] = 'Publish authorized preview43 and verify policy entire APK and health'
    job['steps'][1]['run'] = "python3 - <<'PY'\n" + hosted + '\nPY\n'
    job['steps'].append({
        'name': 'Preserve non-secret delivery receipt',
        'if': 'always()',
        'uses': 'actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9',
        'with': {
            'name': 'owner-preview43-public-verification-${{ github.run_id }}-${{ github.run_attempt }}',
            'path': '${{ runner.temp }}/owner-preview43-public-verification.json',
            'if-no-files-found': 'warn', 'retention-days': 3,
        },
    })
    rendered = yaml.safe_dump(workflow, allow_unicode=True, sort_keys=False, width=120)
    assert yaml.safe_load(rendered) == workflow
    (OUT / 'workflow.yml').write_text(rendered)
    (OUT / 'remote-wrapper.py').write_text(remote)
    (OUT / 'hosted-delivery.py').write_text(hosted)
    preparation = {
        'target_workflow': TARGET,
        'preparation_only': True, 'server_execution_performed': False,
        'app_or_test_execution_performed': False, 'github_write_performed': False,
        'server': {'id': 9417611, 'name': 'Analyst AI runtime 20261025', 'ipv4': '83.217.195.29',
                   'project_id': 2941515, 'availability_zone': 'ams-1'},
        'pinned_administrative_checkout': PIN,
        'transport_source_sha256': sha(TRANSPORT_WORKFLOW.read_bytes()),
        'transport_prefix_sha256': sha(prefix.encode()),
        'build_report_sha256': sha(verified_raw),
        'source_backup_commit': native_provenance['source_backup_commit'],
        'phone_evidence': 'Read-only aggregates of active authenticated preview sessions; compatibility claims only.',
        'runtime_state': 'Original14 run40278915893 failed incomplete; full15 matrix and physical phone unverified.',
        'files': {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha((OUT / name).read_bytes())}
                  for name in ('publish-preview43.py', 'verify-public43.py', 'remote-wrapper.py', 'hosted-delivery.py', 'workflow.yml')},
    }
    (OUT / 'preparation.json').write_text(json.dumps(preparation, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'prepared': str(OUT / 'workflow.yml'), 'workflow_sha256': preparation['files']['workflow.yml']['sha256']}))


if __name__ == '__main__':
    render()
