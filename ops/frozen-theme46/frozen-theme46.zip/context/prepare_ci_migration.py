"""Prepare a separate, reviewable CI-only Windows transport; never dispatch it.

Inputs are the real backed-up application base identity and a reviewed manifest
containing exact old/new file identities and UTF-8 candidate content. This
generator writes only a new output directory. It does not change any checkout,
execute application/tests, contact GitHub/Timeweb, create commits, or dispatch CI.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import json
from pathlib import Path
import re
import zlib

import yaml


ROOT = Path(__file__).resolve().parents[1]
PROVEN_BOOTSTRAP_SHA256 = '986cebe48cf4d499aa71d12a491a595bfcaa279adf2cc191b38cd994636bf02d'
PROVEN_COMPONENTS = {
    'preflight': '737c37ddb3196ad710b681965a14e5815f80b614f5b6891fdcbc3f59b517696d',
    'collect': 'f06238f93bdc195e2c0b9dfdf1573e3410290a71dcfa98377bea0f81f800d299',
    'cleanup': '7541f70d437c18179bad0c9e97390f5a5263c38c4ea1b855c4079d26629d6dc0',
    'evidence_prepare': 'e87ab4a50c73c088bb55df4475f6e30d37a72458e056d8c5a5fad24090bb3fe2',
    'evidence_upload': 'c2eb44e2891fdc4dcf55e6d02d2b63860498fd05d156220c77156be859e3119e',
}
REVIEWED_PATHS = frozenset({
    '.github/workflows/backend-ci.yml',
    '.github/workflows/android-ci.yml',
    '.github/workflows/android-apk.yml',
    '.github/scripts/laptop_backend_ci.py',
    '.github/scripts/laptop_backend_guest.py',
    '.github/scripts/windows_android_ci.py',
    '.github/scripts/tests/test_laptop_backend_ci.py',
    '.github/scripts/tests/test_windows_android_ci.py',
    '.github/scripts/tests/test_distributable_apk_workflow.py',
    '.github/scripts/tests/test_android_release_concurrency.py',
    '.github/scripts/tests/test_private_apk_review.py',
    '.github/scripts/tests/test_spectrum_fixture.py',
    '.github/scripts/tests/test_spectrum_research_integration.py',
})
PROVEN_HELPERS = ('need', 'stamp', 'digest', 'git_blob', 'sha', 'save', 'checked', 'git', 'inventory', 'OwnedJob')
WORKFLOW_PATH = '.github/workflows/windows-ci-migration.yml'
CHECKOUT_ACTION = 'actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1'
UPLOAD_ACTION = 'actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9'


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode('utf-8')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def candidate_payload(path, base_commit, base_source):
    raw = path.read_bytes()
    need(0 < len(raw) <= 16 * 1024**2, 'Candidate manifest size is outside the reviewed bound')
    manifest = json.loads(raw, object_pairs_hook=unique_object)
    need(manifest.get('schema') == 1 and manifest.get('base_commit') == base_commit
         and manifest.get('base_source_sha256') == base_source, 'Candidate manifest base identity does not match arguments')
    files = manifest.get('files')
    need(isinstance(files, list) and len(files) == len(REVIEWED_PATHS), 'Exactly thirteen reviewed files are required')
    need(all(isinstance(row, dict) for row in files), 'Candidate manifest file rows must be objects')
    need({row.get('path') for row in files} == REVIEWED_PATHS, 'Manifest path is missing, duplicated or outside the whitelist')
    normalized = []
    for row in files:
        required = {'path', 'old_git_blob', 'old_sha256', 'old_bytes', 'new_sha256', 'new_bytes', 'content'}
        need(set(row) == required, 'Unexpected candidate file fields: ' + str(row.get('path')))
        need(isinstance(row['content'], str) and '\0' not in row['content'], 'Candidate content must be UTF-8 text')
        data = row['content'].encode('utf-8')
        need(type(row['new_bytes']) is int and 0 < len(data) == row['new_bytes'] <= 2 * 1024**2,
             'Candidate new size does not match reviewed bytes')
        need(isinstance(row['new_sha256'], str) and digest(data) == row['new_sha256'], 'Candidate new SHA-256 mismatch')
        if row['old_git_blob'] is None:
            need(row['old_sha256'] is None and row['old_bytes'] is None, 'New-file original identity is inconsistent')
        else:
            need(isinstance(row['old_git_blob'], str) and re.fullmatch(r'[a-f0-9]{40}', row['old_git_blob'])
                 and isinstance(row['old_sha256'], str) and re.fullmatch(r'[a-f0-9]{64}', row['old_sha256'])
                 and type(row['old_bytes']) is int and row['old_bytes'] >= 0, 'Invalid original file identity')
            need(row['old_sha256'] != row['new_sha256'], 'Unchanged file must not be presented as a migration edit')
        if row['path'] == '.github/workflows/android-apk.yml':
            need(row['old_git_blob'] is not None, 'Reusable-workflow caller must already exist')
            exact_mapping = '    secrets:\n      TIMEWEB_CLOUD_TOKEN: ${{ secrets.TIMEWEB_CLOUD_TOKEN }}\n'
            need(row['content'].count(exact_mapping) == 1 and 'secrets: inherit' not in row['content'],
                 'Only the explicit single-secret caller mapping is authorized')
        normalized.append(dict(row))
    return {'schema': 1, 'kind': 'reviewed_ci_migration', 'base_commit': base_commit,
            'base_source_sha256': base_source, 'files': sorted(normalized, key=lambda row: row['path'])}, digest(raw)


def proven_helpers(path):
    raw = path.read_bytes()
    need(digest(raw) == PROVEN_BOOTSTRAP_SHA256, 'Proven bootstrap changed; review its provenance before continuing')
    text = raw.decode('utf-8')
    lines = text.splitlines(keepends=True)
    parsed = ast.parse(text)
    definitions = {node.name: node for node in parsed.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    result = []
    identities = {}
    for name in PROVEN_HELPERS:
        node = definitions[name]
        fragment = ''.join(lines[node.lineno - 1:node.end_lineno])
        result.append(fragment)
        identities[name] = digest(fragment.encode('utf-8'))
    return '\n\n'.join(result), identities


def reviewed_transport(path):
    raw = path.read_bytes()
    workflow = yaml.safe_load(raw)
    result = {key: copy.deepcopy(workflow['jobs'][key]) for key in ('preflight', 'collect', 'cleanup')}
    for key in ('evidence_prepare', 'evidence_upload'):
        matches = [row for row in workflow['jobs']['develop']['steps'] if row.get('id') == key]
        need(len(matches) == 1, 'Proven private transport step is missing or duplicated: ' + key)
        result[key] = copy.deepcopy(matches[0])
    for key, value in result.items():
        need(digest(json_bytes(value)) == PROVEN_COMPONENTS[key], 'Proven transport component changed: ' + key)
    return result, digest(raw)


def stage(name, content):
    need(re.fullmatch(r'[A-Za-z0-9_.-]+', name), 'Unsafe administrative transport filename')
    encoded = base64.b64encode(zlib.compress(content, 9)).decode('ascii')
    lines = []
    for offset in range(0, len(encoded), 6000):
        mode = 'w' if offset == 0 else 'a'
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'PATCH_DIR\'])/\'' + name +
                     '.b64\'; p.open(\'' + mode + '\',encoding=\'ascii\').write(\'' + encoded[offset:offset + 6000] + '\')"')
        lines.append('if errorlevel 1 exit /b 1')
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'PATCH_DIR\']); '
                 'b=zlib.decompress(base64.b64decode((p/\'' + name + '.b64\').read_text())); '
                 'assert __debug__ and len(b)==' + str(len(content)) + ' and hashlib.sha256(b).hexdigest()==\'' + digest(content) +
                 '\'; (p/\'' + name + '\').open(\'xb\').write(b)"')
    lines.append('if errorlevel 1 exit /b 1')
    return {'name': 'Stage verified CI administrative transport: ' + name, 'shell': 'cmd', 'run': '\n'.join(lines)}


def workflow(base_commit, bootstrap, payload, transport):
    source = '${{ github.workspace }}/windows-ci-migration-${{ github.run_id }}-${{ github.run_attempt }}'
    patches = '${{ github.workspace }}/windows-ci-migration-patches-${{ github.run_id }}-${{ github.run_attempt }}'
    state = '${{ runner.temp }}/analyst-ci-migration-${{ github.run_id }}-${{ github.run_attempt }}'
    setup = stage('reviewed-ci-payload.json', payload)
    setup['id'] = 'setup'
    steps = [
        {'name': 'Require the laptop and a new owned checkout', 'shell': 'cmd',
         'run': 'py -3 -c "import os,sys,pathlib; assert __debug__ and sys.platform==\'win32\' and os.environ.get(\'COMPUTERNAME\')==\'LAPTOP-NPSGA016\'; assert sys.version_info[:3]==(3,14,6); p=pathlib.Path(os.environ[\'SOURCE_ROOT\']); assert not p.exists() and not p.is_symlink()"\nif errorlevel 1 exit /b 1'},
        {'name': 'Checkout the exact backed-up application base', 'uses': CHECKOUT_ACTION,
         'with': {'ref': base_commit, 'path': 'windows-ci-migration-${{ github.run_id }}-${{ github.run_attempt }}',
                  'persist-credentials': False, 'clean': False, 'fetch-depth': 1}},
        {'name': 'Create the new run-owned administrative transport directory', 'shell': 'cmd',
         'run': 'if exist "%PATCH_DIR%" exit /b 1\nmkdir "%PATCH_DIR%"\nif errorlevel 1 exit /b 1'},
        stage('windows-ci-migration.py', bootstrap), setup,
        {'name': 'Apply only reviewed CI paths and run full host, tools and Node checks on Windows',
         'id': 'work', 'timeout-minutes': 82, 'shell': 'cmd',
         'run': 'py -3 "%PATCH_DIR%\\windows-ci-migration.py" control --payload "%PATCH_DIR%\\reviewed-ci-payload.json"\nif errorlevel 1 exit /b 1'},
        {'name': 'Export exact applied bytes, source inventories and check logs without an acceptance claim',
         'id': 'export', 'if': "always() && steps.setup.outcome == 'success'", 'shell': 'cmd',
         'run': 'py -3 "%PATCH_DIR%\\windows-ci-migration.py" export\nif errorlevel 1 exit /b 1'},
        {'name': 'Retain synthetic source/check reports and logs for diagnosis', 'if': 'always()', 'uses': UPLOAD_ACTION,
         'with': {'name': 'n00-ci-migration-source-checks-${{ github.run_id }}-${{ github.run_attempt }}',
                  'path': '\n'.join(state + '/' + suffix for suffix in
                                    ('ci-migration-checks.json', 'controller.json', 'applied-patches.json',
                                     'source-before.json', 'source-after-patches.json', 'source-final.json',
                                     'export-receipt.json', '*.log')),
                  'retention-days': 3, 'if-no-files-found': 'error'}},
        transport['evidence_prepare'], transport['evidence_upload'],
    ]
    develop = {'name': 'Apply reviewed CI source on the laptop and validate contracts only', 'needs': 'preflight',
               'runs-on': ['self-hosted', 'Windows', 'X64', 'omni-cio-ci'], 'timeout-minutes': 100,
               'permissions': {'contents': 'write'},
               'outputs': {'archive_sha256': '${{ steps.evidence_upload.outputs.archive_sha256 }}'},
               'env': {'SOURCE_ROOT': source, 'PATCH_DIR': patches,
                       'ANDROID_SDK_ROOT': 'C:/actions-runner-2/_work/_tool/AndroidSdk/sdk',
                       'ANDROID_HOME': 'C:/actions-runner-2/_work/_tool/AndroidSdk/sdk',
                       'PYTHONUNBUFFERED': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONUTF8': '1',
                       'GIT_CONFIG_COUNT': '2', 'GIT_CONFIG_KEY_0': 'core.autocrlf', 'GIT_CONFIG_VALUE_0': 'false',
                       'GIT_CONFIG_KEY_1': 'core.longpaths', 'GIT_CONFIG_VALUE_1': 'true'}, 'steps': steps}
    collect = transport['collect']
    collect['name'] = 'Preserve CI source/check evidence on 9417611 without executing application code'
    return {'name': 'N00 apply reviewed ordinary CI migration; Windows source contracts only',
            'on': {'push': {'branches': ['codex/timeweb-owner-prepare-2026-10-23'], 'paths': [WORKFLOW_PATH]}},
            'permissions': {'contents': 'read'},
            'concurrency': {'group': 'analyst-windows-ci-migration-n00', 'cancel-in-progress': False},
            'jobs': {'preflight': transport['preflight'], 'develop': develop,
                     'collect': collect, 'cleanup': transport['cleanup']}}


def prepare(args):
    need(re.fullmatch(r'[a-f0-9]{40}', args.base_commit), 'An exact backed-up base commit is required')
    need(re.fullmatch(r'[a-f0-9]{64}', args.base_source_sha256), 'An exact backed-up code inventory is required')
    context_root = (ROOT / 'context').resolve(strict=True)
    args.output = args.output.resolve(strict=False)
    need(args.output != context_root and args.output.is_relative_to(context_root),
         'Prepared output must stay in a new directory under this workspace context folder')
    need(not args.output.exists() and not args.output.is_symlink(), 'Output directory must be new')
    payload, input_manifest_hash = candidate_payload(args.manifest, args.base_commit, args.base_source_sha256)
    payload_bytes = json_bytes(payload)
    helpers, helper_hashes = proven_helpers(args.proven_bootstrap)
    transport, transport_hash = reviewed_transport(args.transport_workflow)
    template = args.template.read_text(encoding='utf-8')
    replacements = {'@@BASE_COMMIT@@': repr(args.base_commit), '@@BASE_SOURCE@@': repr(args.base_source_sha256),
                    '@@PAYLOAD_SHA256@@': repr(digest(payload_bytes)), '@@REVIEWED_PATHS@@': repr(tuple(sorted(REVIEWED_PATHS))),
                    '@@PROVEN_HELPERS@@': helpers}
    for marker, replacement in replacements.items():
        need(template.count(marker) == 1, 'Missing or duplicated bootstrap template marker: ' + marker)
        template = template.replace(marker, replacement)
    need('@@' not in template, 'Unexpanded bootstrap marker')
    ast.parse(template)  # Administrative source syntax only; never execute the generated bootstrap here.
    bootstrap = template.encode('utf-8')
    result = workflow(args.base_commit, bootstrap, payload_bytes, transport)
    serialized = yaml.safe_dump(result, allow_unicode=True, sort_keys=False, width=120).encode('utf-8')
    args.output.mkdir(parents=True)
    (args.output / 'reviewed-ci-payload.json').write_bytes(payload_bytes)
    (args.output / 'windows-ci-migration.py').write_bytes(bootstrap)
    (args.output / 'workflow.yml').write_bytes(serialized)
    summary = {'schema': 1, 'state': 'prepared_only_not_dispatched_or_executed',
               'base_commit': args.base_commit, 'base_source_sha256': args.base_source_sha256,
               'input_manifest_sha256': input_manifest_hash, 'payload_sha256': digest(payload_bytes),
               'bootstrap_sha256': digest(bootstrap), 'workflow_sha256': digest(serialized),
               'proven_bootstrap_sha256': PROVEN_BOOTSTRAP_SHA256,
               'proven_transport_workflow_sha256': transport_hash, 'copied_helper_sha256': helper_hashes,
               'transport_components_sha256': PROVEN_COMPONENTS,
               'files': [{key: value for key, value in row.items() if key != 'content'} for row in payload['files']],
               'ordinary_ci_executed': False, 'application_build_performed': False,
               'full_backend_suite_executed': False, 'native_matrix_executed': False,
               'external_sonar_verified': False, 'n00_completed': False, 'publication_authorized': False,
               'next_action_requires_root_review': True, 'administrative_workflow_path': WORKFLOW_PATH}
    (args.output / 'manifest-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    (args.output / 'NOT_ACCEPTANCE.md').write_text(
        '# Prepared administrative transport — not ordinary CI acceptance\n\n'
        'This package has not been dispatched or executed. Its later Windows phase applies only the thirteen reviewed CI paths '
        'and runs source audit, diff check, full host/workspace/tools/Node regression suites. It does not run Gradle, '
        'the complete backend suite, either native profile, ordinary CI entry points, external Sonar, or publication.\n\n'
        'The Windows tree intentionally remains an uncommitted patch on the real backed-up base. No Git provenance is forged. '
        'Only fixture/contract tests of the new helpers run here. Keep the exact successful applied bytes and returned private '
        'archive receipt before backing up source in GitHub; the real new PR merge/head/base workflows and external Sonar '
        'must then run independently. No existing main/PR or update channel is changed by this generator.\n', encoding='utf-8')
    print(json.dumps({key: summary[key] for key in ('state', 'base_commit', 'payload_sha256', 'bootstrap_sha256', 'workflow_sha256')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--base-commit', required=True)
    parser.add_argument('--base-source-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--proven-bootstrap', type=Path,
                        default=ROOT / 'context/full-build-baseline/windows-full-development.py')
    parser.add_argument('--transport-workflow', type=Path,
                        default=ROOT / 'admin-transport/.github/workflows/windows-development.yml')
    parser.add_argument('--template', type=Path,
                        default=ROOT / 'context/ci-migration-transport/windows-ci-migration.py.in')
    prepare(parser.parse_args())
