"""Prepare original14 transport44 from actual successful Windows build evidence.

Administrative preparation only: no application/test imports or execution,
emulator launch, repository edit, network operation, push or dispatch.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
import zlib

import yaml


ROOT = Path(__file__).resolve().parents[1]
CONTEXT = ROOT / "context"
TARGET_WORKFLOW = ".github/workflows/windows-n00-portfolio44.yml"
BUILD_BASE = "043e1da910da2fcf952cc00c46d0e81a761076ea"
BUILD_BASE_SOURCE = "4fcf1b15db4d40c249966d072e22d31f286515fc0e84974364cb71e07f282aaf"
CERTIFICATE = "bbce9534fd4cfee8f3bdcaf51a31cce384a4f303f090c8cae9ec558227d59eb1"
BASELINE43_SHA256 = "4e9bf0a2fd54d8ab4b9d49ef9ddf96bc14a274ac4c145585fcfdb88d6ae774b6"
BASELINE43_BYTES = 29771254
BASELINE43_ROOT = r"C:\actions-runner-3\_work\omni-cio-gateway\omni-cio-gateway\windows-development-40277268871-1"
PINS = {
    "native43/n00-runtime.py": "f2d1f6695c306eb3b7246bfa816d19ddd25adc0366e9b8c239f8cd6b46ce2ce0",
    "native43/n00-portfolio-focused-hook.py": "ddff3bb7c57670141b9e5f0ce02994fb0d8ed7748b781776a284460614f2276e",
    "native43/workflow.yml": "0f55d43c98c9535c3d1f37a67e86178657004cfcf0d4a5193b923278e12f76e0",
    "native43/build-provenance.json": "8743bbb7305ba374add1f94660e29420da87bb645bc6b2b3f210cb6273cdfe96",
    "candidate44/reviewed-files.json": "6a040de2507769095b162da1fab3d39e613e833dcc107b9edd149636d64ae6e5",
    "full-build-baseline/windows-full-development.py": "986cebe48cf4d499aa71d12a491a595bfcaa279adf2cc191b38cd994636bf02d",
}
APK_PATHS = {
    "preview": "app/build/outputs/apk/preview/app-preview.apk",
    "debug": "app/build/outputs/apk/debug/app-debug.apk",
    "driver": "ci-ui-driver/build/outputs/apk/debug/ci-ui-driver-debug.apk",
}
REVIEWED_PATHS = {
    "app/src/main/java/ru/omnicio/app/ui/workspace/ResearchLibraryScreen.kt",
    "app/build.gradle.kts",
    ".github/scripts/tests/test_android17_live_spectrum.py",
    ".github/scripts/tests/test_spectrum_brand_identity.py",
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha256(value):
    return hashlib.sha256(value).hexdigest()


def hash_value(value, length, label):
    need(isinstance(value, str) and re.fullmatch(r"[a-f0-9]{" + str(length) + "}", value), label)
    return value


def read_checked(path, expected, limit=8 * 1024**2):
    path = path.absolute()
    need(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
         "Input must be a canonical regular file: " + str(path))
    need(path.stat().st_nlink == 1 and 0 < path.stat().st_size <= limit, "Invalid input file size or links")
    raw = path.read_bytes()
    need(sha256(raw) == expected, "Input bytes differ from the independently verified SHA: " + str(path))
    return raw


def pinned(relative):
    return read_checked(CONTEXT / relative, PINS[relative])


def decode(raw):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            need(key not in value, "Duplicate JSON key")
            value[key] = item
        return value
    result = json.loads(raw, object_pairs_hook=unique)
    need(isinstance(result, dict), "JSON object required")
    return result


def replace_once(text, old, new):
    need(text.count(old) == 1, "Template anchor changed: " + old[:100])
    return text.replace(old, new, 1)


def assignment(text, name, value):
    lines = [line for line in text.splitlines() if line.startswith(name + " = ")]
    need(len(lines) == 1, "Missing unique template assignment: " + name)
    return replace_once(text, lines[0], name + " = " + repr(value))


def candidate_sources(report):
    review = decode(pinned("candidate44/reviewed-files.json"))
    rows = review.get("files")
    need(isinstance(rows, list) and len(rows) == 4 and {row["path"] for row in rows} == REVIEWED_PATHS,
         "Candidate44 must contain only the reviewed four files")
    expected = {}
    for row in rows:
        data = row["content"].encode("utf-8")
        need(len(data) == row["new_bytes"] and sha256(data) == row["new_sha256"], "Candidate44 bytes changed")
        expected[row["path"]] = {"bytes": len(data), "sha256": row["new_sha256"]}
    observed = report.get("patch_files")
    need(isinstance(observed, list) and len(observed) == 4, "Build44 did not apply exactly four reviewed files")
    need({row["path"] for row in observed} == REVIEWED_PATHS, "Build44 patch scope differs")
    originals = {row["path"]: row for row in rows}
    for row in observed:
        original = originals[row["path"]]
        need(row.get("old_sha256") == original["old_sha256"] and
             row.get("new_sha256") == original["new_sha256"], "Build44 source differs from reviewed bytes")
    gradle = originals["app/build.gradle.kts"]["content"]
    need(re.search(r'^\s*versionCode = 44\s*$', gradle, re.M) and
         re.search(r'^\s*versionName = "0\.13\.6"\s*$', gradle, re.M), "Wrong candidate44 identity")
    # Preserve the verified43 probe repairs and their source proofs, replacing
    # only the three version identities and adding the one real library fix.
    previous = decode(pinned("native43/build-provenance.json"))["candidate_source_files"]
    need(len(previous) == 14, "Verified43 source evidence changed")
    evidence = {**previous, **expected}
    need(len(evidence) == 15, "Unexpected44 source evidence overlap")
    return dict(sorted(evidence.items()))


def build_evidence(args):
    source_commit = hash_value(args.source_commit, 40, "Exact source backup commit required")
    source_hash = hash_value(args.source_sha256, 64, "Exact source inventory required")
    report_sha = hash_value(args.build_report_sha256, 64, "Exact successful build report SHA required")
    export_sha = hash_value(args.build_export_receipt_sha256, 64, "Exact export receipt SHA required")
    archive_sha = hash_value(args.build_archive_sha256, 64, "Exact archived build SHA required")
    need(0 < args.build_archive_bytes <= 512 * 1024**2, "Exact archived build size required")
    report_raw = read_checked(args.build_report, report_sha)
    export_raw = read_checked(args.build_export_receipt, export_sha)
    report, exported = decode(report_raw), decode(export_raw)
    need(report.get("schema") == 1 and report.get("kind") == "windows_development_check_build" and
         report.get("host") == "LAPTOP-NPSGA016" and report.get("origin") == "Windows laptop",
         "Wrong build report origin")
    need(report.get("base_commit") == BUILD_BASE and report.get("base_source_sha256") == BUILD_BASE_SOURCE,
         "Build44 must use the verified CI backup043e1da and source4fcf1b15")
    need(report.get("status") == "passed_check_and_build_only", "Complete Windows build44 has not passed")
    for phase in ("check", "build"):
        need(report.get(phase, {}).get("status") == "passed" and
             report[phase].get("source_sha256") == source_hash, "Build phase failed or used another source")
    need(report.get("source_sha256") == source_hash == report.get("source_sha256_after"),
         "Build44 source differs from explicit input")
    complete = hash_value(report.get("complete_source_sha256"), 64, "Invalid complete source inventory")
    need(report.get("complete_source_sha256_after") == complete, "Complete source changed during build")
    need(report.get("publication_authorized") is False and report.get("phone_verified") is False and
         report.get("timeweb_execution") is False and report.get("runtime", {}).get("status") == "not_run",
         "Build must not claim native runtime, phone or publication")
    need(report.get("certificate_sha256") == CERTIFICATE, "Signing identity changed")
    steps = report.get("steps")
    need(isinstance(steps, list) and steps and
         all(type(row.get("exit_code")) is int and row["exit_code"] == 0 for row in steps),
         "A complete build/check command failed")
    need({"host-tests", "tools-tests", "node-tests", "backend-tests", "gradle", "apk-verification"}
         <= {row.get("label") for row in steps}, "Required full build gates are missing")
    #44 intentionally uses the original full bootstrap with two BASE constants;
    # the old43 RED-only interpreter injection must not become a new requirement.
    bootstrap = pinned("full-build-baseline/windows-full-development.py")
    bootstrap = bootstrap.replace(b'd5a5763fbd85ab2d2c1a9f1734ce24a5083a739e', BUILD_BASE.encode())
    bootstrap = bootstrap.replace(b'dd762dde5a301bf972cc72794171ea3e3f0e04a3751ddaf833d0a0f003ed2066',
                                  BUILD_BASE_SOURCE.encode())
    need(report.get("bootstrap_sha256") == sha256(bootstrap), "Build44 bootstrap differs from reviewed full build")
    need(exported.get("status") == "passed_check_and_build_only" and
         exported.get("source_sha256") == source_hash and exported.get("complete_source_sha256") == complete,
         "Export receipt does not bind the successful source44")
    need(type(exported.get("bytes")) is int and exported["bytes"] == args.build_archive_bytes and
         exported.get("sha256") == archive_sha and exported.get("runtime_pass") is False and
         exported.get("publication_authorized") is False, "Export receipt differs from the exact archived bytes")
    github = report.get("github", {})
    run, attempt = github.get("run_id"), github.get("run_attempt")
    need(type(run) is int and run > 0 and type(attempt) is int and attempt > 0, "Invalid build run identity")
    hash_value(github.get("workflow_sha"), 40, "Missing actual build workflow commit")
    retained = PureWindowsPath(report["root"])
    need(retained.is_absolute() and retained.drive.upper() == "C:" and len(retained.parts) == 6 and
         retained.parts[1] in ("actions-runner", "actions-runner-2", "actions-runner-3", "actions-runner-4") and
         retained.parts[2:] == ("_work", "omni-cio-gateway", "omni-cio-gateway", f"windows-development-{run}-{attempt}"),
         "Build APK root is not owned by the reported run")
    state = retained.parents[2] / "_temp" / f"analyst-development-{run}-{attempt}"
    need(PureWindowsPath(report["state"]) == state, "Wrong retained build state")
    files = {}
    for role, relative in APK_PATHS.items():
        size = getattr(args, role + "_bytes")
        digest = hash_value(getattr(args, role + "_sha256"), 64, "Exact " + role + " APK SHA required")
        need(0 < size <= 512 * 1024**2 and report.get("apks", {}).get(relative) == {"bytes": size, "sha256": digest},
             "Explicit " + role + " APK identity differs from successful build44")
        files[relative] = [size, digest]
    need(report["build"].get("apk_sha256") == files[APK_PATHS["preview"]][1], "Preview SHA differs")
    need(files[APK_PATHS["preview"]][1] != BASELINE43_SHA256, "Candidate44 cannot reuse previous43 APK bytes")
    evidence = candidate_sources(report)
    provenance = {
        "build_report_sha256": report_sha, "build_run_id": run, "build_run_attempt": attempt,
        "build_workflow_sha": github["workflow_sha"], "build_status": report["status"],
        "host": "LAPTOP-NPSGA016", "root": str(retained), "state": str(state),
        "build_base_commit": BUILD_BASE, "source_backup_commit": source_commit,
        "source_sha256": source_hash, "complete_build_source_sha256": complete,
        "build_export_receipt_sha256": export_sha,
        "build_archive": {"bytes": args.build_archive_bytes, "sha256": archive_sha},
        "preview_version_code": 44, "preview_version_name": "0.13.6-preview",
        "input_apks": files, "candidate_source_files": evidence,
        "baseline": {"version_code": 43, "version_name": "0.13.5-preview",
                     "bytes": BASELINE43_BYTES, "sha256": BASELINE43_SHA256,
                     "retained_build_run_id": 40277268871, "publication_run_id": 40280610534},
        "original_portfolio_cases_required": 14, "full_ui_stage_count": 15,
        "diagnostic_only": True, "release_gate_pass": False,
        "full_ui_suite_executed": False, "publication_authorized": False, "phone_verified": False,
    }
    return files, evidence, provenance, report_raw, export_raw


def make_runtime(files, evidence, provenance):
    original = pinned("native43/n00-runtime.py").decode("utf-8")
    text = original
    for name, value in (("BASE_COMMIT", provenance["source_backup_commit"]), ("SOURCE_HASH", provenance["source_sha256"]),
                        ("SOURCE_EVIDENCE", evidence), ("BUILD_PROVENANCE", provenance), ("FILES", files)):
        text = assignment(text, name, value)
    text = replace_once(text, "PREVIOUS_HASH='058e307855cad135a30bccc8a4a5bafc96638fd8400ba31fda0af07f255d0bef'",
                        "PREVIOUS_HASH=" + repr(BASELINE43_SHA256))
    baseline_line = next(line for line in text.splitlines() if line.startswith("BASELINE = "))
    baseline_path = str(PureWindowsPath(BASELINE43_ROOT) / PureWindowsPath(APK_PATHS["preview"]))
    text = replace_once(text, baseline_line, "BASELINE = pathlib.Path(" + repr(baseline_path) + ")")
    need(text.count(".st_size==29754870") == 2, "Old baseline size checks changed")
    text = text.replace(".st_size==29754870", ".st_size==" + str(BASELINE43_BYTES))
    text = text.replace("previous38.apk", "previous43.apk").replace("published_baseline38_changed", "published_baseline43_changed")
    text = text.replace("n00-native43-focused-", "n00-native44-focused-")
    text = text.replace("native43-build-provenance.json", "native44-build-provenance.json")
    text = text.replace("native43-evidence-envelope.json", "native44-evidence-envelope.json")
    text = text.replace("n00_candidate43_portfolio_focused", "n00_candidate44_portfolio_focused")
    anchor = "    regular(report);need(sha(report)==BUILD_PROVENANCE['build_report_sha256'],'successful_build_report_changed')\n"
    extra = """    exported=pathlib.Path(os.environ['RUNNER_TEMP'])/'n00-build-export-receipt.json'
    regular(exported);need(sha(exported)==BUILD_PROVENANCE['build_export_receipt_sha256'],'successful_build_export_receipt_changed')
    archive=json.loads(exported.read_text(encoding='utf-8'))
    need(archive['bytes']==BUILD_PROVENANCE['build_archive']['bytes'] and archive['sha256']==BUILD_PROVENANCE['build_archive']['sha256'],'successful_build_archive_changed')
    need(archive['source_sha256']==SOURCE_HASH and archive['complete_source_sha256']==BUILD_PROVENANCE['complete_build_source_sha256'] and archive['status']=='passed_check_and_build_only','successful_build_export_source_changed')
    need(archive['runtime_pass'] is False and archive['publication_authorized'] is False,'unexpected_build_export_acceptance_claim')
"""
    text = replace_once(text, anchor, anchor + extra)
    # Only identities, diagnostic filenames and additional receipt checks vary.
    # Actual SDK/lease/emulator execution and its limits remain the proven43 code.
    for start, end in (("def environment():", "\ndef export():"), ("class OwnedJob:", "\ndef prepare():"),
                       ("    import emulator_lease,prepare_android_sdk", "\n    unchanged()")):
        need(text.split(start, 1)[1].split(end, 1)[0] == original.split(start, 1)[1].split(end, 1)[0],
             "Native process, timeout, lease or environment code changed")
    ast.parse(text)
    return text.encode("utf-8")


def stage(name, content):
    need(re.fullmatch(r"[a-z0-9-]+\.(?:py|json)", name), "Invalid staged transport name")
    encoded = base64.b64encode(zlib.compress(content, 9)).decode("ascii")
    lines = []
    for offset in range(0, len(encoded), 6000):
        mode = "w" if offset == 0 else "a"
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'RUNNER_TEMP\'])/\'' + name +
                     '.b64\'; p.open(\'' + mode + '\',encoding=\'ascii\').write(\'' + encoded[offset:offset + 6000] + '\')"')
        lines.append("if errorlevel 1 exit /b 1")
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'RUNNER_TEMP\']); '
                 'b=zlib.decompress(base64.b64decode((p/\'' + name + '.b64\').read_text())); '
                 'assert hashlib.sha256(b).hexdigest()==\'' + sha256(content) + '\'; (p/\'' + name + '\').write_bytes(b)"')
    lines.append("if errorlevel 1 exit /b 1")
    need(max(map(len, lines)) < 8000, "Staging exceeds Windows command length")
    return {"name": "Stage verified focused transport " + name, "shell": "cmd", "run": "\n".join(lines)}


def make_workflow(runtime, hook, report, exported, provenance):
    original = yaml.safe_load(pinned("native43/workflow.yml"))
    workflow = copy.deepcopy(original)
    workflow["name"] = "N00 candidate44 original fourteen portfolio cases after library scroll repair"
    need(workflow["on"]["push"]["branches"] == ["codex/timeweb-owner-prepare-2026-10-23"], "Admin branch changed")
    workflow["on"]["push"]["paths"] = [TARGET_WORKFLOW]
    workflow["concurrency"]["group"] = "analyst-n00-candidate44-portfolio-focused"
    need(workflow["concurrency"]["cancel-in-progress"] is False, "Native cancellation policy changed")
    develop = workflow["jobs"]["develop"]
    develop["name"] = "Run all fourteen original portfolio cases on exact candidate44"
    need(develop["runs-on"] == ["self-hosted", "Windows", "X64", "omni-cio-ci"] and develop["timeout-minutes"] == 100,
         "Native host or outer timeout changed")
    steps, old_stages = [], []
    checkout = observation = artifact = preparation = 0
    for step in develop["steps"]:
        name = step.get("name", "")
        if name.startswith("Stage verified focused transport "):
            if not old_stages:
                staged = [stage("n00-runtime.py", runtime), stage("n00-portfolio-focused-hook.py", hook),
                          stage("n00-successful-build-report.json", report), stage("n00-build-export-receipt.json", exported)]
                staged[-1]["id"] = "setup"
                steps.extend(staged)
            old_stages.append(name.removeprefix("Stage verified focused transport "))
            continue
        if step.get("uses", "").startswith("actions/checkout@"):
            need(step["with"]["ref"] == "859c067198e52927df1b66983d02841e3fa6ff6a" and
                 step["with"]["persist-credentials"] is False, "Native checkout boundary changed")
            step["with"]["ref"] = provenance["source_backup_commit"]
            checkout += 1
        if step.get("id") == "prepare":
            need(name == "Verify exact tested source candidate and published baseline38", "Prepare step changed")
            step["name"] = "Verify exact tested source44 and published baseline43"
            preparation += 1
        if step.get("id") == "focused_report":
            script = step["with"]["script"]
            old_header = next(line for line in script.splitlines() if line.startswith("const identity="))
            identity = {"source_commit": provenance["source_backup_commit"], "source_sha256": provenance["source_sha256"],
                        "build_run_id": provenance["build_run_id"], "build_run_attempt": provenance["build_run_attempt"],
                        "build_report_sha256": provenance["build_report_sha256"]}
            script = replace_once(script, old_header, "const identity=" + json.dumps(identity, separators=(",", ":")) + ";")
            script = script.replace("n00-native43-focused-", "n00-native44-focused-")
            script = script.replace("native43-original14-summary.json", "native44-original14-summary.json")
            script = script.replace("N00 candidate43 original14 observations", "N00 candidate44 original14 observations")
            step["with"]["script"] = script
            observation += 1
        if step.get("uses", "").startswith("actions/upload-artifact@"):
            need(step["uses"] == "actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9", "Artifact action changed")
            step["with"]["name"] = "n00-candidate44-original14-native-16384"
            step["with"]["path"] = step["with"]["path"].replace("n00-native43-focused-", "n00-native44-focused-")
            artifact += 1
        need(not step.get("continue-on-error"), "Diagnostic failure semantics changed")
        steps.append(step)
    need(old_stages == ["n00-runtime.py", "n00-portfolio-focused-hook.py", "n00-successful-build-report.json"],
         "Verified43 staged transport changed")
    need(checkout == observation == artifact == preparation == 1, "Missing native workflow step")
    develop["steps"] = steps
    for job in ("preflight", "collect", "cleanup", "result"):
        need(workflow["jobs"][job] == original["jobs"][job], "Private9417611 transport or diagnostic result gate changed")
    return yaml.safe_dump(workflow, allow_unicode=True, sort_keys=False, width=120).encode("utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("source-commit", "source-sha256", "build-report-sha256", "build-export-receipt-sha256", "build-archive-sha256"):
        parser.add_argument("--" + flag, required=True)
    parser.add_argument("--build-report", type=Path, required=True)
    parser.add_argument("--build-export-receipt", type=Path, required=True)
    parser.add_argument("--build-archive-bytes", type=int, required=True)
    for role in APK_PATHS:
        parser.add_argument("--" + role + "-bytes", type=int, required=True)
        parser.add_argument("--" + role + "-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    destination = args.output.absolute()
    need(CONTEXT in destination.parents and not destination.exists() and not destination.is_symlink() and
         destination.parent.is_dir() and destination.parent.resolve(strict=True) == destination.parent,
         "Output must be a new directory below context")
    files, evidence, provenance, report, exported = build_evidence(args)
    runtime = make_runtime(files, evidence, provenance)
    hook = pinned("native43/n00-portfolio-focused-hook.py")
    workflow = make_workflow(runtime, hook, report, exported, provenance)
    outputs = {"n00-runtime.py": runtime, "n00-portfolio-focused-hook.py": hook,
               "n00-successful-build-report.json": report, "n00-build-export-receipt.json": exported,
               "build-provenance.json": (json.dumps(provenance, indent=2) + "\n").encode("utf-8"),
               "workflow.yml": workflow}
    receipt = {"state": "prepared_only_no_native_execution", "target_workflow_path": TARGET_WORKFLOW,
               "source_backup_commit": provenance["source_backup_commit"], "source_sha256": provenance["source_sha256"],
               "build_report_sha256": provenance["build_report_sha256"],
               "build_export_receipt_sha256": provenance["build_export_receipt_sha256"],
               "build_archive": provenance["build_archive"], "input_apks": files,
               "candidate44_applied_file_count": 4, "candidate_source_evidence_count": len(evidence),
               "hook_unchanged_sha256": sha256(hook), "original14_is_diagnostic_only": True,
               "full15_acceptance_claimed": False, "native_execution": False, "publication_authorized": False,
               "phone_verified": False, "baseline": provenance["baseline"],
               "files": {name: {"bytes": len(data), "sha256": sha256(data)} for name, data in outputs.items()}}
    outputs["preparation.json"] = (json.dumps(receipt, indent=2) + "\n").encode("utf-8")
    destination.mkdir()
    for name, data in outputs.items():
        with (destination / name).open("xb") as output:
            output.write(data)
    print(json.dumps({"output": str(destination), "state": receipt["state"],
                      "source_backup_commit": provenance["source_backup_commit"],
                      "workflow_sha256": sha256(workflow), "runtime_sha256": sha256(runtime)}))


if __name__ == "__main__":
    main()
