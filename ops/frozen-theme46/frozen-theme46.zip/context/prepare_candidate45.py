"""Prepare candidate45 administrative transport bound to a confirmed candidate44 backup.

Only reviewed source bytes, inventory metadata and administrative files are read
or written. No checkout edits, application/test/compiler execution, network,
commit, push, dispatch, publication or device actions occur in this generator.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zlib

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONTEXT = ROOT / "context"
CANDIDATE = CONTEXT / "candidate45"
PANELS = CONTEXT / "side-bottom-panels"
DETAIL = CONTEXT / "panels-detail-extension"
GENERATOR44_SHA256 = "34de235114817713500bb73bbc48f1f61f0012de402155ecc23678ecd623f2c7"
REVIEWED_FILES_SHA256 = "5b38c63c09e578088965f93dbc6a44fc0a79953d63d6e6bb34a83a67c9320ca8"
PANELS_MANIFEST_SHA256 = "ef844a7e29af3313ad2367f383a974e7870784d1d840646ac016fd6aaa9fb318"
DETAIL_MANIFEST_SHA256 = "c8009c13e8f86101c756a87c2a2c8cef9334b05523a42b5dde3bb7350cfab349"
BASE44_COMMIT = "1cc05586b6874bfdd0cdb80131d178de9f95870c"
BASE44_SOURCE_SHA256 = "e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9"
BASE44_INVENTORY_SHA256 = "632690ecf7bca6a54b6f569567c6b6dbf7bfe0dab22b999e8bfa70ee74e94e67"
CANDIDATE44_REVIEW_SHA256 = "6a040de2507769095b162da1fab3d39e613e833dcc107b9edd149636d64ae6e5"
BASELINE_BOOTSTRAP_SHA256 = "986cebe48cf4d499aa71d12a491a595bfcaa279adf2cc191b38cd994636bf02d"
BASELINE_GUEST_SHA256 = "9c92c16d88a9e69a6e9b73b61f0e1eff8cd6b1b457451ee104c07bd17a7e29f0"
WORKFLOW_TEMPLATE_SHA256 = "f0e80b7fa64e98f01a090ed171111fccba184752d79950aa25ad0a3a830d0524"
ENTRY_KEYS = frozenset({
    "path", "old_git_blob", "old_sha256", "old_bytes", "new_sha256", "new_bytes", "content",
})
SOURCE_PATHS = frozenset({
    ".github/scripts/automation_ui_probe.py",
    ".github/scripts/navigation_detail_probe.py",
    ".github/scripts/persistent_ui.py",
    ".github/scripts/profile_scroll.py",
    ".github/scripts/tests/fixtures/NavigationBackFixtureTest.java",
    ".github/scripts/tests/test_android17_live_spectrum.py",
    ".github/scripts/tests/test_automation_ui_probe.py",
    ".github/scripts/tests/test_navigation_detail_probe.py",
    ".github/scripts/tests/test_predictive_back_input.py",
    ".github/scripts/tests/test_spectrum_brand_identity.py",
    "app/build.gradle.kts",
    "app/src/debug/java/ru/omnicio/app/AutomationWorkspaceProbe.kt",
    "app/src/debug/java/ru/omnicio/app/BusinessWorkspaceProbe.kt",
    "app/src/main/java/ru/omnicio/app/MainActivity.kt",
    "app/src/main/java/ru/omnicio/app/ui/AnalystBottomBar.kt",
    "app/src/main/java/ru/omnicio/app/ui/AnalystNavigationPanels.kt",
    "app/src/main/java/ru/omnicio/app/ui/workspace/AppearanceScreen.kt",
    "app/src/main/java/ru/omnicio/app/ui/workspace/LiveStrategyScreen.kt",
    "app/src/main/java/ru/omnicio/app/ui/workspace/WorkspaceUi.kt",
    "app/src/test/java/ru/omnicio/app/ui/PanelNavigationGuardTest.kt",
    "ci-ui-driver/src/main/java/ru/omnicio/ciframe/BackGestureInput.java",
    "ci-ui-driver/src/main/java/ru/omnicio/ciframe/FrameInstrumentation.java",
    "ci-ui-driver/src/main/java/ru/omnicio/ciframe/NavigationBackFixture.java",
})
OVERLAP_PATHS = frozenset({
    ".github/scripts/automation_ui_probe.py",
    "app/src/main/java/ru/omnicio/app/ui/AnalystBottomBar.kt",
    "app/src/main/java/ru/omnicio/app/ui/AnalystNavigationPanels.kt",
})
VERSION_REPLACEMENTS = {
    "app/build.gradle.kts": (
        (b'versionCode = 44', b'versionCode = 45'),
        (b'versionName = "0.13.6"', b'versionName = "0.13.7"'),
    ),
    ".github/scripts/tests/test_android17_live_spectrum.py": (
        (b'versionCode = 44', b'versionCode = 45'),
        (b'versionName = "0.13.6"', b'versionName = "0.13.7"'),
    ),
    ".github/scripts/tests/test_spectrum_brand_identity.py": (
        (b'self.assertEqual(int(version.group(1)), 44)', b'self.assertEqual(int(version.group(1)), 45)'),
        (b'versionName = "0.13.6"', b'versionName = "0.13.7"'),
    ),
}
WORKFLOW_METADATA_REPLACEMENTS = (
    ("N00 saved-research scroll repair; verify candidate44", "Side and bottom panels; verify candidate45"),
    ("Apply four reviewed candidate44 files on the laptop and perform the full build",
     "Apply twenty-three reviewed candidate45 files on the laptop and perform the full build"),
    ("n00-native44", "n00-native45"),
    ("n00-candidate44-build-checks", "n00-candidate45-build-checks"),
    # Root separately authorized retaining these original inventories before
    # RUNNER_TEMP cleanup. The full private archive remains byte-for-byte logic.
    ('step["with"]["path"] = "\\n".join(path for path in old_paths if path not in red_only)',
     'inventory_paths = ["${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/" + name\n'
     '                               for name in ("source-before.json", "source-final.json")]\n'
     '            need(not set(inventory_paths).intersection(old_paths), "inventory evidence was already present")\n'
     '            step["with"]["path"] = "\\n".join([*(path for path in old_paths if path not in red_only), *inventory_paths])'),
)


def need(value, message):
    if not value:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def json_bytes(value, *, compact=False):
    if compact:
        return json.dumps(value, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    return (json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode("utf-8")

def read_pinned(path, expected):
    need(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
         "reviewed input is not a canonical regular file: " + str(path))
    data = path.read_bytes()
    need(digest(data) == expected, "reviewed input changed: " + str(path))
    return data

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()


def parse_json(raw):
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=unique_pairs)


def verify_transport_source():
    """Require the proven generator44 transport functions byte for byte."""
    old = read_pinned(CONTEXT / "prepare_candidate44.py", GENERATOR44_SHA256).decode("utf-8")
    new = Path(__file__).read_text(encoding="utf-8")
    functions = []
    for source in (old, new):
        functions.append({node.name: ast.get_source_segment(source, node)
                          for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)})
    before, after = functions
    for name in ("need", "digest", "json_bytes", "read_pinned", "bootstrap", "stage"):
        need(before[name] == after[name], "proven transport function changed: " + name)
    expected = before["workflow"]
    for original, replacement in WORKFLOW_METADATA_REPLACEMENTS:
        need(expected.count(original) == 1, "proven workflow metadata anchor changed")
        expected = expected.replace(original, replacement, 1)
    need(after["workflow"] == expected, "workflow changed beyond reviewed45 metadata and two inventory artifact paths")


def reviewed_files():
    review = parse_json(read_pinned(CANDIDATE / "reviewed-files.json", REVIEWED_FILES_SHA256))
    panels = parse_json(read_pinned(PANELS / "manifest.json", PANELS_MANIFEST_SHA256))
    extension = parse_json(read_pinned(DETAIL / "manifest.json", DETAIL_MANIFEST_SHA256))
    previous = parse_json(read_pinned(CONTEXT / "candidate44/reviewed-files.json",
                                      CANDIDATE44_REVIEW_SHA256))
    need(review.get("schema") == 1 and
         review.get("kind") == "reviewed_candidate45_sources_unbound_to_future_base" and
         review.get("panels_manifest_sha256") == PANELS_MANIFEST_SHA256 and
         review.get("detail_extension_manifest_sha256") == DETAIL_MANIFEST_SHA256 and
         review.get("candidate44_reviewed_files_sha256") == CANDIDATE44_REVIEW_SHA256 and
         review.get("version_before") == {"code": 44, "name": "0.13.6"} and
         review.get("version_after") == {"code": 45, "name": "0.13.7"} and
         review.get("confirmed_base44_backup_commit") == BASE44_COMMIT and
         review.get("base44_source_inventory_sha256") == BASE44_INVENTORY_SHA256 and
         review.get("base44_code_inventory_sha256") == BASE44_SOURCE_SHA256 and
         review.get("overlap_paths") == sorted(OVERLAP_PATHS) and
         (review.get("source_file_count"), review.get("existing_files"), review.get("new_files")) == (23, 17, 6),
         "unexpected reviewed45 union identity")
    need(panels.get("schema") == 1 and panels.get("candidate_version") == 45 and
         len(panels.get("source_files", [])) == 13, "unexpected frozen panel review")
    need(extension.get("schema") == 1 and
         extension.get("kind") == "prepared_candidate45_detail_menu_extension" and
         extension.get("frozen45_manifest_sha256") == PANELS_MANIFEST_SHA256 and
         len(extension.get("source_files", [])) == 10, "unexpected frozen detail/wide extension")
    need(previous.get("schema") == 1 and
         previous.get("kind") == "reviewed_candidate44_sources_unbound_to_future_base" and
         len(previous.get("files", [])) == 4, "unexpected reviewed44 identity")
    panel_rows = {row["path"]: row for row in panels["source_files"]}
    detail_rows = {row["path"]: row for row in extension["source_files"]}
    previous_rows = {row["path"]: row for row in previous["files"]}
    need(len(panel_rows) == 13 and len(detail_rows) == 10 and len(previous_rows) == 4 and
         set(panel_rows).intersection(detail_rows) == OVERLAP_PATHS and
         not (set(panel_rows) | set(detail_rows)).intersection(VERSION_REPLACEMENTS),
         "reviewed union overlap or version paths changed")
    expected_paths = set(panel_rows) | set(detail_rows) | set(VERSION_REPLACEMENTS)
    need(expected_paths == SOURCE_PATHS and len(SOURCE_PATHS) == 23, "frozen union allowlist differs")
    rows = review.get("files")
    need(isinstance(rows, list) and len(rows) == 23, "exactly twenty-three reviewed45 files are required")
    seen = set()
    for row in rows:
        need(isinstance(row, dict) and set(row) == ENTRY_KEYS, "unexpected file entry")
        relative = row["path"]
        need(relative in expected_paths and relative not in seen, "unreviewed or repeated source path")
        seen.add(relative)
        need(isinstance(row["content"], str) and "\0" not in row["content"], "invalid reviewed source text")
        data = row["content"].encode("utf-8")
        need(type(row["new_bytes"]) is int and len(data) == row["new_bytes"] and
             digest(data) == row["new_sha256"], "reviewed45 source size or hash differs")
        need(read_pinned(CANDIDATE / "source" / relative, row["new_sha256"]) == data,
             "candidate45 source copy differs")
        intermediate = None
        if relative in panel_rows:
            frozen = panel_rows[relative]
            intermediate = read_pinned(PANELS / relative, frozen["new_sha256"])
            need(len(intermediate) == frozen["bytes"] and git_blob(intermediate) == frozen["new_git_blob"] and
                 row["old_sha256"] == frozen["old_sha256"] and row["old_git_blob"] == frozen["old_git_blob"],
                 "frozen panel intermediate or original identity differs")
        if relative in detail_rows:
            detail = detail_rows[relative]
            need(read_pinned(DETAIL / "source" / relative, detail["new_sha256"]) == data and
                 row["new_sha256"] == detail["new_sha256"] and row["new_bytes"] == detail["bytes"] and
                 git_blob(data) == detail["new_git_blob"], "final detail/wide source bytes differ")
            if detail["base_scope"] == "frozen45":
                need(relative in OVERLAP_PATHS and intermediate is not None and
                     digest(intermediate) == detail["base_sha256"] and
                     row["old_sha256"] == detail["upstream_original_sha256"],
                     "extension does not consume the exact frozen panel intermediate")
            elif detail["base_scope"] == "verified_CI_source":
                need(relative not in panel_rows and row["old_sha256"] == detail["base_sha256"] ==
                     detail["upstream_original_sha256"], "extension original source identity differs")
            else:
                need(detail["base_scope"] == "new" and relative not in panel_rows and
                     detail["base_sha256"] is None and detail["upstream_original_sha256"] is None and
                     row["old_sha256"] is None and row["old_git_blob"] is None,
                     "unexpected extension source provenance")
        elif relative in panel_rows:
            need(data == intermediate, "untouched frozen panel bytes were changed")
        else:
            prior = previous_rows[relative]
            old = read_pinned(CONTEXT / "candidate44/source" / relative, prior["new_sha256"])
            need(len(old) == prior["new_bytes"] and old == prior["content"].encode("utf-8"),
                 "reviewed44 version source bytes differ")
            expected = old
            for original, replacement in VERSION_REPLACEMENTS[relative]:
                need(expected.count(original) == 1 and replacement not in expected,
                     "exact44 version assignment changed")
                expected = expected.replace(original, replacement, 1)
            need(data == expected, "version candidate contains changes beyond44 to45")
            restored = data
            for original, replacement in reversed(VERSION_REPLACEMENTS[relative]):
                need(restored.count(replacement) == 1, "generated45 version is ambiguous")
                restored = restored.replace(replacement, original, 1)
            need(restored == old, "strict version assertions were changed")
        if row["old_git_blob"] is None:
            need(row["old_sha256"] is None and row["old_bytes"] is None,
                 "new union file has an original identity")
            continue
        if relative not in VERSION_REPLACEMENTS:
            # This is the tested43 compact-frame source, also unchanged in the
            # actual44 inventory; the local49 checkout predates that repair.
            original_root = CONTEXT / "candidate43/source" if relative == \
                "app/src/debug/java/ru/omnicio/app/BusinessWorkspaceProbe.kt" else ROOT / "analyst-ai"
            old = read_pinned(original_root / relative, row["old_sha256"])
        need(type(row["old_bytes"]) is int and row["old_bytes"] == len(old) and
             row["old_sha256"] == digest(old) and row["old_git_blob"] == git_blob(old),
             "old source bytes or Git blob differ")
        need(row["old_sha256"] != row["new_sha256"], "unchanged candidate source file")
    need(seen == expected_paths and sum(row["old_git_blob"] is None for row in rows) == 6,
         "candidate45 reviewed path or new-file count differs")
    return rows, previous_rows


def verify_base_inventory(path, expected_source, rows, previous_rows):
    """Check the real44 build inventory; the Windows bootstrap also checks HEAD blobs."""
    path = path.absolute()
    need(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
         "base44 inventory must be a canonical regular file")
    need(0 < path.stat().st_size <= 8 * 1024 ** 2, "base44 inventory size is invalid")
    raw = read_pinned(path, BASE44_INVENTORY_SHA256)
    inventory = parse_json(raw)
    need(isinstance(inventory, dict) and set(inventory) == {
        "source_sha256", "complete_source_sha256", "files"}, "unexpected base44 inventory format")
    files = inventory["files"]
    need(isinstance(files, dict) and 1 <= len(files) <= 20000, "invalid base44 file inventory")
    source = hashlib.sha256()
    complete = hashlib.sha256()
    seen = set()
    for relative in sorted(files, key=lambda value: value.encode("utf-8")):
        parts = PurePosixPath(relative)
        need(relative and ":" not in relative and "\\" not in relative and "\0" not in relative and
             "\n" not in relative and "\r" not in relative and
             not parts.is_absolute() and parts.as_posix() == relative and
             all(part not in (".", "..") for part in parts.parts) and
             relative.casefold() not in seen, "unsafe or repeated base44 inventory path")
        seen.add(relative.casefold())
        identity = files[relative]
        need(isinstance(identity, dict) and set(identity) == {"bytes", "sha256"} and
             type(identity["bytes"]) is int and identity["bytes"] >= 0 and
             isinstance(identity["sha256"], str) and re.fullmatch(r"[a-f0-9]{64}", identity["sha256"]),
             "invalid base44 file identity")
        encoded = relative.encode("utf-8") + b"\0" + identity["sha256"].encode("ascii") + b"\0"
        complete.update(encoded)
        if relative not in ("AGENTS.md", "README.md") and not relative.startswith("docs/"):
            source.update(encoded)
    need(source.hexdigest() == expected_source == inventory["source_sha256"],
         "provided44 source hash does not match its file inventory")
    need(complete.hexdigest() == inventory["complete_source_sha256"],
         "provided44 complete inventory hash differs")
    for row in rows:
        relative = row["path"]
        if row["old_git_blob"] is None:
            need(relative not in files and relative.casefold() not in seen,
                 "new45 source path already exists in44")
        else:
            need(files.get(relative) == {"bytes": row["old_bytes"], "sha256": row["old_sha256"]},
                 "base44 original source identity differs: " + relative)
    # This also binds the saved-library repair, which candidate45 does not edit.
    for relative, row in previous_rows.items():
        need(files.get(relative) == {"bytes": row["new_bytes"], "sha256": row["new_sha256"]},
             "base inventory does not contain the exact reviewed44 result: " + relative)
    return raw, {"inventory_sha256": digest(raw), "files": len(files),
                 "source_sha256": source.hexdigest(), "complete_source_sha256": complete.hexdigest()}

def bootstrap(base_commit, base_source):
    original = read_pinned(CONTEXT / "full-build-baseline/windows-full-development.py",
                           BASELINE_BOOTSTRAP_SHA256)
    replacements = (
        (b'BASE_COMMIT = "d5a5763fbd85ab2d2c1a9f1734ce24a5083a739e"',
         ('BASE_COMMIT = "' + base_commit + '"').encode("ascii")),
        (b'BASE_SOURCE = "dd762dde5a301bf972cc72794171ea3e3f0e04a3751ddaf833d0a0f003ed2066"',
         ('BASE_SOURCE = "' + base_source + '"').encode("ascii")),
    )
    result = original
    for old, new in replacements:
        need(result.count(old) == 1, "baseline identity assignment changed")
        result = result.replace(old, new, 1)
    # A reversible byte comparison proves that the existing workflow-mutation
    # guard, lease, OwnedJob, tests and full-build commands were not altered.
    restored = result
    for old, new in reversed(replacements):
        need(restored.count(new) == 1, "generated identity assignment is ambiguous")
        restored = restored.replace(new, old, 1)
    need(restored == original, "bootstrap changed beyond its two base constants")
    ast.parse(result.decode("utf-8"), filename="windows-full-development.py")
    return result

def stage(name, content):
    need(re.fullmatch(r"[a-z0-9_.-]+", name), "invalid staged transport name")
    encoded = base64.b64encode(zlib.compress(content, 9)).decode("ascii")
    lines = []
    for offset in range(0, len(encoded), 6000):
        mode = "w" if offset == 0 else "a"
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'PATCH_DIR\'])/\'' +
                     name + '.b64\'; p.open(\'' + mode + '\',encoding=\'ascii\').write(\'' +
                     encoded[offset:offset + 6000] + '\')"')
        lines.append("if errorlevel 1 exit /b 1")
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'PATCH_DIR\']); '
                 'b=zlib.decompress(base64.b64decode((p/\'' + name + '.b64\').read_text())); '
                 'assert hashlib.sha256(b).hexdigest()==\'' + digest(content) + '\'; '
                 '(p/\'' + name + '\').write_bytes(b)"')
    lines.append("if errorlevel 1 exit /b 1")
    return {"name": "Stage verified administrative transport: " + name,
            "shell": "cmd", "run": "\n".join(lines)}

def workflow(base_commit, script, guest, transport, manifest):
    raw = read_pinned(CONTEXT / "candidate43/workflow.yml", WORKFLOW_TEMPLATE_SHA256)
    original = yaml.safe_load(raw)
    result = copy.deepcopy(original)
    need(set(result["jobs"]) == {"preflight", "develop", "collect", "cleanup", "result"},
         "candidate43 administrative job graph changed")
    result["name"] = "Side and bottom panels; verify candidate45"
    develop = result["jobs"]["develop"]
    develop["name"] = "Apply twenty-three reviewed candidate45 files on the laptop and perform the full build"
    need(develop["timeout-minutes"] == 150, "unexpected previous outer job timeout")
    # Root reviewed this administrative nesting correction: the unchanged
    # 180-minute worker and 20-minute lease wait fit the existing 210-minute
    # work step, with time left for export/private return in the outer job.
    develop["timeout-minutes"] = 245
    new_steps = [stage("windows-full-development.py", script), stage("n00-linux-guest.py", guest),
                 stage("n00-native45.b64", transport), stage("patch-manifest.json", manifest)]
    new_steps[-1]["id"] = "setup"
    old_staged = []
    steps = []
    base_steps = work_steps = artifact_steps = 0
    for step in develop["steps"]:
        name = step.get("name", "")
        if name.startswith("Stage verified administrative transport: "):
            if not old_staged:
                steps.extend(new_steps)
            old_staged.append(name.removeprefix("Stage verified administrative transport: "))
            continue
        if name == "Checkout the exact base source with LF bytes":
            need(step["with"]["ref"] == "49d6a75da6aed643b66ef6807e2370fd7c896ff5",
                 "candidate43 source checkout changed")
            step["with"]["ref"] = base_commit
            base_steps += 1
        if step.get("id") == "work":
            need(step["timeout-minutes"] == 210, "existing work step timeout changed")
            work_steps += 1
        if step.get("uses", "").startswith("actions/upload-artifact@"):
            need(step["with"]["name"] == "n00-candidate43-build-checks", "unexpected evidence artifact")
            step["with"]["name"] = "n00-candidate45-build-checks"
            old_paths = step["with"]["path"].splitlines()
            red_only = {
                "${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/*original*.log",
                "${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/original-*-result.json",
            }
            need(red_only <= set(old_paths), "candidate43 RED evidence paths changed")
            inventory_paths = ["${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/" + name
                               for name in ("source-before.json", "source-final.json")]
            need(not set(inventory_paths).intersection(old_paths), "inventory evidence was already present")
            step["with"]["path"] = "\n".join([*(path for path in old_paths if path not in red_only), *inventory_paths])
            artifact_steps += 1
        steps.append(step)
    need(old_staged == ["windows-full-development.py", "n00-linux-guest.py", "n00-red-regressions.py",
                        "n00-native43.b64", "patch-manifest.json"], "unexpected candidate43 staged transport")
    need(base_steps == work_steps == artifact_steps == 1, "required administrative steps changed")
    develop["steps"] = steps
    for job in ("preflight", "collect", "cleanup", "result"):
        need(result["jobs"][job] == original["jobs"][job], "private return infrastructure changed")
    for key in original.keys() - {"name", "jobs"}:
        need(result[key] == original[key], "administrative trigger or permissions changed")
    text = yaml.safe_dump(result, allow_unicode=True, sort_keys=False, width=120)
    need("n00-red-regressions" not in text and "n00-native43" not in text,
         "old candidate43 RED transport was retained")
    return text.encode("utf-8")


def prepare(args):
    need(re.fullmatch(r"[a-f0-9]{40}", args.base_commit), "confirmed exact backup44 commit is required")
    need(re.fullmatch(r"[a-f0-9]{64}", args.base_source_sha256), "verified44 code inventory hash is required")
    need(args.base_commit == BASE44_COMMIT and args.base_source_sha256 == BASE44_SOURCE_SHA256,
         "candidate45 must use the independently confirmed exact44 source backup")
    destination = args.output.absolute()
    need(CONTEXT in destination.parents and not destination.exists() and not destination.is_symlink(),
         "output must be a new directory under context")
    need(destination.parent.is_dir() and destination.parent.resolve(strict=True) == destination.parent,
         "output parent must already be a canonical directory")
    verify_transport_source()
    rows, previous_rows = reviewed_files()
    inventory_raw, inventory_summary = verify_base_inventory(
        args.base_inventory, args.base_source_sha256, rows, previous_rows)
    bundle = json_bytes({"reference_commit": args.base_commit, "files": rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = json_bytes({"schema": 1, "base_commit": args.base_commit, "bundles": [{
        "name": "n00-native45", "transport_sha256": digest(transport), "decoded_sha256": digest(bundle),
    }]}, compact=True)
    script = bootstrap(args.base_commit, args.base_source_sha256)
    guest = read_pinned(CONTEXT / "full-build-baseline/n00-linux-guest.py", BASELINE_GUEST_SHA256)
    generated_workflow = workflow(args.base_commit, script, guest, transport, manifest)
    summary = {
        "state": "prepared_only_no_application_or_test_execution",
        "base_commit": args.base_commit, "base_source_sha256": args.base_source_sha256,
        "base44_inventory": inventory_summary,
        "base44_backup_commit_confirmation": "required_external_owner_workflow_evidence_not_proven_offline",
        "base44_build_success": "must_be_verified_separately_before_dispatch",
        "windows_source_preflight": "exact HEAD, code inventory and committed original Git blobs required",
        "reviewed_files_sha256": REVIEWED_FILES_SHA256,
        "panels_manifest_sha256": PANELS_MANIFEST_SHA256,
        "detail_extension_manifest_sha256": DETAIL_MANIFEST_SHA256,
        "candidate44_reviewed_files_sha256": CANDIDATE44_REVIEW_SHA256,
        "proven_generator44_sha256": GENERATOR44_SHA256,
        "version_before": {"code": 44, "name": "0.13.6"},
        "version_after": {"code": 45, "name": "0.13.7"},
        "union": {"source_paths": 23, "existing_files": 17, "new_files": 6,
                  "frozen_panel_paths": 13, "extension_paths": 10,
                  "overlap_paths": sorted(OVERLAP_PATHS), "exact_version_paths": 3},
        "files": [{key: value for key, value in row.items() if key != "content"} for row in rows],
        "bundle_sha256": digest(bundle), "transport_sha256": digest(transport),
        "patch_manifest_sha256": digest(manifest), "bootstrap_sha256": digest(script),
        "linux_guest_sha256": digest(guest), "workflow_sha256": digest(generated_workflow),
        "baseline_bootstrap_sha256": BASELINE_BOOTSTRAP_SHA256,
        "workflow_template_sha256": WORKFLOW_TEMPLATE_SHA256,
        "bootstrap_changes": ["BASE_COMMIT", "BASE_SOURCE"],
        "administrative_timeouts": {"job_minutes": 245, "work_step_minutes": 210,
                                    "worker_seconds": 10800, "shared_lease_wait_seconds": 1200},
        "transport_core_functions_match44": True,
        "additional_small_artifact_paths": ["source-before.json", "source-final.json"],
        "native_prepared_cases": {"original_automation": 26, "original_panel_receipts": 4,
                                  "phone_detail_fonts": 2, "routes_per_phone_font": 6, "wide_fonts": 2},
        "wide_environment": {"width": 960, "height": 1600, "density_dpi": 160,
                             "owned_emulator_only": True, "exact_original_restore_required": True},
        "old_red_regression_transport_removed": True,
        "private_return_infrastructure_modified": False,
        "native_original14_probe_modified": False, "workflow_mutation_guard_modified": False,
        "source_applied_on_windows": False, "ordinary_ci_verified": False,
        "build_passed": False, "runtime_passed": False, "phone_verified": False,
        "publication_performed": False, "n00_complete": False,
        "workflow_destination_for_later_review": ".github/workflows/windows-development.yml",
    }
    files = {"bundle.json": bundle, "n00-native45.b64": transport, "patch-manifest.json": manifest,
             "windows-full-development.py": script, "n00-linux-guest.py": guest,
             "workflow.yml": generated_workflow, "manifest-summary.json": json_bytes(summary),
             "base44-source-inventory.json": inventory_raw}
    files["NOT_ACCEPTANCE.md"] = (
        "# Candidate45 administrative preparation only\n\n"
        "These files have not been applied or executed. Root must independently confirm that the supplied "
        "backup44 commit is the committed result of the successful Windows44 build and the provided code "
        "inventory. This generator validates the real inventory and exact reviewed44 file identities; "
        "it cannot authenticate the GitHub backup or build outcome offline. Windows rechecks the exact "
        "HEAD, source inventory and every existing committed Git blob before applying any candidate file.\n\n"
        "The23 unique files merge the immutable13-file side/bottom navigation candidate with the reviewed "
        "ten-file detail/wide extension, resolving its three overlaps, plus exactly three version "
        "changes from44 /0.13.6 to45 /0.13.7. Strict version assertions remain strict. The saved-library "
        "repair in44 must already be present and is not changed by this candidate.\n\n"
        "The phone keeps its existing three bottom tabs and adds a menu button and real existing routes. "
        "The drawer closes by its explicit button or native predictive Back. Sheet swipe and scrim-tap "
        "dismissal are disabled. Six detail screens can reopen their menu in the existing header or compact "
        "input gutter. The drawer and wide three-entry rail use the same route-bound Strategy dirty exit "
        "and Appearance preview rollback, with once-only owner-bound continuation. Existing saved detail state "
        "is retained. App branding, real orders, paid AI, owner binding and backend data are unchanged.\n\n"
        "The proven full-build bootstrap differs only in BASE_COMMIT and BASE_SOURCE. Its tests, guards, "
        "lease and OwnedJob logic remain unchanged. The job245 /work210 /worker180 /lease20 minute limits "
        "and the existing private return infrastructure match candidate44. No RED regression transport "
        "is added. The small administrative artifact additionally retains original source-before.json and "
        "source-final.json before RUNNER_TEMP cleanup; the full private archive/export logic is unchanged. "
        "Administrative workflows are staged separately and never included in the source patch.\n\n"
        "Windows host, WSL backend, JVM, lint and APK builds remain required, followed by native validation. "
        "All26 original automation cases and the existing full native matrix remain required; four separate "
        "navigation receipts additionally verify phone controls at100% and200%, selection and real "
        "hold/cancel/commit Back behavior. Separate phone-detail evidence requires all six actual routes at "
        "both font scales, the real dirty confirmation cancel/discard and Appearance preview rollback. "
        "Two separate wide cases then require the actual production rail at960x1600px/160dpi, real dirty "
        "confirmation and exact original size/density/font restoration. Only the current process's owned "
        "API37 emulator under the existing host lease may use that reversible display override. Original "
        "phone26/portfolio14 viewports are unchanged; no forced-wide application flag is used. "
        "Build success alone is not native acceptance, physical-phone "
        "installation, external Sonar success, ordinary CI success or N00 completion.\n"
    ).encode("utf-8")
    destination.mkdir()
    for name, data in files.items():
        with (destination / name).open("xb") as output:
            output.write(data)
    print(json.dumps({"output": str(destination), "base_commit": args.base_commit,
                      "base_source_sha256": args.base_source_sha256, "files": len(rows),
                      "bundle_sha256": digest(bundle), "workflow_sha256": digest(generated_workflow),
                      "state": summary["state"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-commit", required=True,
                        help="Externally confirmed exact backup commit of the verified44 source")
    parser.add_argument("--base-source-sha256", required=True,
                        help="Code inventory SHA256 from the verified44 Windows build")
    parser.add_argument("--base-inventory", type=Path, required=True,
                        help="Actual44 source-final.json whose code and complete inventories will be recomputed")
    parser.add_argument("--output", type=Path, required=True)
    prepare(parser.parse_args())


if __name__ == "__main__":
    main()
