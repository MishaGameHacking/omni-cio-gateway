"""Prepare two exact repairs for the real candidate45 Windows host failures.

Only candidate bytes and administrative transport are written under context.
The production checkout and all application/test execution stay on Windows.
"""
from __future__ import annotations

import argparse
import ast
import base64
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

import yaml

CONTEXT = Path(__file__).resolve().parent
ORIGINAL_GENERATOR_SHA = "69bfb8dbefd2cb3ce7bbf03dbd3bbbaf90c66b8b6fb5d38873a6f27e878ecf9a"
ORIGINAL_REVIEW_SHA = "5b38c63c09e578088965f93dbc6a44fc0a79953d63d6e6bb34a83a67c9320ca8"
BASE = "1cc05586b6874bfdd0cdb80131d178de9f95870c"
BASE_SOURCE = "e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9"
BAR = "app/src/main/java/ru/omnicio/app/ui/AnalystBottomBar.kt"
TEST = ".github/scripts/tests/test_portfolio_semantic_scroll.py"


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def replace_once(raw, old, new):
    need(raw.count(old) == 1 and new not in raw, "Exact repair anchor changed")
    return raw.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    destination = args.output.absolute()
    need(CONTEXT in destination.parents and not destination.exists()
         and destination.parent.resolve(strict=True) == destination.parent, "New context output required")
    path = CONTEXT / "prepare_candidate45.py"
    need(path.resolve(strict=True) == path and sha(path.read_bytes()) == ORIGINAL_GENERATOR_SHA,
         "Reviewed generator45 changed")
    spec = importlib.util.spec_from_file_location("reviewed_administrative45", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.verify_transport_source()
    original_rows, previous_rows = helper.reviewed_files()
    need(sha((CONTEXT / "candidate45/reviewed-files.json").read_bytes()) == ORIGINAL_REVIEW_SHA,
         "Original reviewed23 union changed")
    inventory_path = CONTEXT / "candidate44-original-evidence/source-final.json"
    inventory_raw, inventory_summary = helper.verify_base_inventory(
        inventory_path, BASE_SOURCE, original_rows, previous_rows)
    inventory = json.loads(inventory_raw)
    rows = [dict(row) for row in original_rows]
    bar = next(row for row in rows if row["path"] == BAR)
    before_bar = bar["content"].encode()
    after_bar = replace_once(before_bar,
        b'modifier.fillMaxWidth().testTag("analyst-bottom-bar").zIndex(1f).clipToBounds()',
        b'modifier.fillMaxWidth().zIndex(1f).clipToBounds().testTag("analyst-bottom-bar")')
    bar.update(content=after_bar.decode(), new_sha256=sha(after_bar), new_bytes=len(after_bar))
    # Include the real callers of the new list; keep the complete list admission
    # assertion and strengthen the no-coordinate-scroll guard across all callers.
    test_path = CONTEXT.parent / "analyst-ai" / TEST
    need(test_path.resolve(strict=True) == test_path and test_path.stat().st_nlink == 1,
         "Semantic-scroll test input is not canonical")
    before_test = test_path.read_bytes()
    need(inventory["files"][TEST] == {"bytes": len(before_test), "sha256": sha(before_test)},
         "Semantic-scroll test is not the actual44 base")
    after_test = replace_once(before_test,
        b'        callers = source + (SCRIPTS / "business_ui_probe.py").read_text(encoding="utf-8")\n',
        b'        callers = source + "".join(\n'
        b'            (SCRIPTS / name).read_text(encoding="utf-8")\n'
        b'            for name in ("business_ui_probe.py", "automation_ui_probe.py", "navigation_detail_probe.py")\n'
        b'        )\n'
        b'        self.assertNotIn(\'"input", "swipe"\', callers)\n')
    ast.parse(after_test)
    need(TEST not in {row["path"] for row in rows}, "Caller test already exists in candidate union")
    rows.append({"path": TEST, "old_git_blob": helper.git_blob(before_test),
        "old_sha256": sha(before_test), "old_bytes": len(before_test),
        "new_sha256": sha(after_test), "new_bytes": len(after_test), "content": after_test.decode()})
    rows.sort(key=lambda row: row["path"])
    need(len(rows) == 24 and sum(row["old_git_blob"] is None for row in rows) == 6,
         "Retry45 source scope changed")
    for row in original_rows:
        result = next(item for item in rows if item["path"] == row["path"])
        if row["path"] != BAR:
            need(result == row, "An unrelated original45 source changed")
        else:
            need(all(result[key] == row[key] for key in ("path", "old_git_blob", "old_sha256", "old_bytes")),
                 "Retry45 original source identity changed")
    helper.verify_base_inventory(inventory_path, BASE_SOURCE, rows, previous_rows)
    review = {"schema": 1, "kind": "reviewed_candidate45_retry_after_actual_windows_host_failures",
        "version_before": {"code": 44, "name": "0.13.6"}, "version_after": {"code": 45, "name": "0.13.7"},
        "confirmed_base44_backup_commit": BASE, "base44_source_inventory_sha256": sha(inventory_raw),
        "base44_code_inventory_sha256": BASE_SOURCE, "prior_reviewed_files_sha256": ORIGINAL_REVIEW_SHA,
        "red_evidence": {"run_id": 40290796480, "artifact_id": 12636700180,
            "artifact_sha256": "a665eef9276f0d1b5c8a51ba8ef7d9d475efab4c92f370905fb45a5092898449",
            "host_tests": 1158, "failures": 2, "skips": 3, "build_executed": False},
        "repair_paths": [BAR, TEST], "source_file_count": 24, "existing_files": 18, "new_files": 6,
        "files": rows}
    review_raw = helper.json_bytes(review)
    bundle = helper.json_bytes({"reference_commit": BASE, "files": rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = helper.json_bytes({"schema": 1, "base_commit": BASE, "bundles": [{"name": "n00-native45",
        "transport_sha256": sha(transport), "decoded_sha256": sha(bundle)}]}, compact=True)
    bootstrap = helper.bootstrap(BASE, BASE_SOURCE)
    guest = helper.read_pinned(CONTEXT / "full-build-baseline/n00-linux-guest.py", helper.BASELINE_GUEST_SHA256)
    original_workflow = helper.workflow(BASE, bootstrap, guest, transport, manifest)
    workflow = yaml.safe_load(original_workflow)
    need(workflow["jobs"]["develop"]["name"] ==
         "Apply twenty-three reviewed candidate45 files on the laptop and perform the full build", "Workflow label changed")
    workflow["jobs"]["develop"]["name"] = "Apply twenty-four reviewed candidate45 files on the laptop and perform the full build"
    workflow["name"] = "Side and bottom panels; candidate45 source-contract repair"
    workflow_raw = yaml.safe_dump(workflow, allow_unicode=True, sort_keys=False, width=120).encode()
    summary = {"state": "prepared_only_no_application_or_test_execution", "base_commit": BASE,
        "base_source_sha256": BASE_SOURCE, "base44_inventory": inventory_summary,
        "reviewed_files_sha256": sha(review_raw), "bootstrap_sha256": sha(bootstrap),
        "patch_manifest_sha256": sha(manifest), "workflow_sha256": sha(workflow_raw),
        "bundle_sha256": sha(bundle), "transport_sha256": sha(transport), "source_paths": 24,
        "original45_frozen_union_sha256": ORIGINAL_REVIEW_SHA, "repairs": [BAR, TEST],
        "source_applied_on_windows": False, "build_passed": False, "runtime_passed": False,
        "phone_verified": False, "publication_performed": False, "n00_complete": False}
    repair_diff = "".join("".join(difflib.unified_diff(before.decode().splitlines(keepends=True),
        after.decode().splitlines(keepends=True), fromfile="a/" + name, tofile="b/" + name))
        for name, before, after in ((BAR, before_bar, after_bar), (TEST, before_test, after_test)))
    outputs = {"reviewed-files.json": review_raw, "bundle.json": bundle, "n00-native45.b64": transport,
        "patch-manifest.json": manifest, "windows-full-development.py": bootstrap,
        "n00-linux-guest.py": guest, "workflow.yml": workflow_raw,
        "manifest-summary.json": helper.json_bytes(summary), "repair.patch": repair_diff.encode()}
    destination.mkdir()
    for name, raw in outputs.items():
        with (destination / name).open("xb") as stream:
            stream.write(raw)
    for row in rows:
        path = destination / "source" / row["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(row["content"].encode())
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
