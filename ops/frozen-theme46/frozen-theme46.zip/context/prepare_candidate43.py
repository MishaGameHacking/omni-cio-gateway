"""Prepare reviewed transport bytes; application code executes only on the laptop."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import zlib
import yaml

ROOT = Path('/workspace/scratch/137de25203f5')
REPO = ROOT / 'analyst-ai'
OUT = ROOT / 'context/candidate43'
OUT.mkdir(exist_ok=True)
BASE = '49d6a75da6aed643b66ef6807e2370fd7c896ff5'
SOURCE = 'eea2c47dfc8707312eb7efba66d087d831907da8b087bf9421bec597ffe74e5b'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def stage(name, content):
    encoded = base64.b64encode(zlib.compress(content, 9)).decode('ascii')
    lines = []
    for index in range(0, len(encoded), 6000):
        mode = 'w' if index == 0 else 'a'
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'PATCH_DIR\'])/\''+name+'.b64\'; p.open(\''+mode+'\',encoding=\'ascii\').write(\''+encoded[index:index+6000]+'\')"')
        lines.append('if errorlevel 1 exit /b 1')
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'PATCH_DIR\']); b=zlib.decompress(base64.b64decode((p/\''+name+'.b64\').read_text())); assert hashlib.sha256(b).hexdigest()==\''+digest(content)+'\'; (p/\''+name+'\').write_bytes(b)"')
    lines.append('if errorlevel 1 exit /b 1')
    return {'name':'Stage verified administrative transport: '+name,'shell':'cmd','run':'\n'.join(lines)}

def candidates():
    files = {
        '.github/scripts/portfolio_chart_probe.py': (ROOT/'context/quote-repair/portfolio_chart_probe.py').read_bytes(),
        '.github/scripts/tests/test_portfolio_controls_evidence.py': (ROOT/'context/quote-repair/test_portfolio_controls_evidence.py').read_bytes(),
    }
    for folder in ('context/font200-input-history', 'context/font200-repair', 'context/candidate43-version-fix'):
        directory = ROOT / folder
        for p in directory.rglob('*'):
            if p.is_file() and p.suffix in ('.kt', '.py') and p.relative_to(directory).parts[0] in ('app','.github'):
                rel = p.relative_to(directory).as_posix()
                assert rel not in files, rel
                files[rel] = p.read_bytes()
    gradle = (REPO/'app/build.gradle.kts').read_text()
    assert 'versionCode = 42' in gradle and 'versionName = "0.13.4"' in gradle
    files['app/build.gradle.kts'] = gradle.replace('versionCode = 42','versionCode = 43').replace('versionName = "0.13.4"','versionName = "0.13.5"').encode()
    return files

def red_script():
    cases = {
        'quote': ['portfolio_chart_probe', 'test_portfolio_controls_evidence',
            'QuoteIntervalMotionTests.test_backward_scroll_settles_before_the_single_hour_tap',
            'Candle interval did not acquire its actual native selected state'],
        'appearance': ['portfolio_preferences_probe', 'test_portfolio_appearance_reset_state',
            'AppearanceResetCommitTests.test_reset_reveals_native_owner_and_confirms_defaults_were_applied',
            'Reset Apply attempted without a usable enabled native owner'],
        'dossier': ['portfolio_research_probe', 'test_portfolio_dossier_long_metrics',
            'LongMetricsEventTraversalTests.test_reopened_dossier_reaches_event_after_both_full_conflict_observations',
            'List target not reachable: Календарь отчётности'],
    }
    for row in cases.values():
        original = (REPO / ('.github/scripts/'+row[0]+'.py')).read_bytes()
        row.extend((digest(original), blob(original)))
    header = 'BASE = '+repr(BASE)+'\nCASES = '+repr(cases)+'\n'
    body = '''import hashlib,importlib,json,os,pathlib,subprocess,sys,types,unittest
assert __debug__ and sys.platform=='win32' and os.environ.get('COMPUTERNAME')=='LAPTOP-NPSGA016'
root=pathlib.Path(sys.argv[1]).resolve(strict=True)
state=pathlib.Path(sys.argv[2]).resolve(strict=True)
case=sys.argv[3]
module_name,test_module_name,test_name,expected,old_sha,old_blob=CASES[case]
original=subprocess.check_output(['git','show',BASE+':.github/scripts/'+module_name+'.py'],cwd=root,timeout=45)
assert hashlib.sha256(original).hexdigest()==old_sha
assert hashlib.sha1(b'blob '+str(len(original)).encode()+b'\\0'+original).hexdigest()==old_blob
stored=state/('original-'+case+'-source.log')
with stored.open('xb') as stream:stream.write(original)
sys.path[:0]=[str(root/'.github/scripts/tests'),str(root/'.github/scripts'),str(root)]
module=types.ModuleType(module_name)
module.__file__=str(stored)
sys.modules[module_name]=module
exec(compile(original,str(stored),'exec'),module.__dict__)
tests=importlib.import_module(test_module_name)
suite=unittest.TestLoader().loadTestsFromName(test_name,tests)
log=state/('original-'+case+'-unittest.log')
with log.open('x',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
valid=(result.testsRun==1 and len(result.failures)==2 and not result.errors
    and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses
    and all(expected in failure for _,failure in result.failures))
receipt={'base_commit':BASE,'module':module_name,'original_sha256':old_sha,'original_git_blob':old_blob,
    'test':test_name,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
    'skips':len(result.skipped),'expected_original_failure_reproduced':valid,
    'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(state/('original-'+case+'-result.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print('ORIGINAL_REGRESSION='+json.dumps(receipt),flush=True)
if not valid:
    print(log.read_text(encoding='utf-8'),flush=True)
    raise AssertionError('The original defect was not reproduced exactly: '+case)
'''
    return (header+body).encode()

def prepare():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==BASE
    files = candidates()
    required = {'.github/scripts/portfolio_research_probe.py','.github/scripts/portfolio_preferences_probe.py'}
    assert required <= files.keys(), 'Font200 candidates have not arrived'
    entries = []
    for rel, new in sorted(files.items()):
        original = REPO/rel
        old = original.read_bytes() if original.exists() else None
        assert old != new, rel
        entries.append({'path':rel, 'old_git_blob':blob(old) if old is not None else None,
            'old_sha256':digest(old) if old is not None else None, 'old_bytes':len(old) if old is not None else None,
            'new_sha256':digest(new),'new_bytes':len(new),'content':new.decode('utf-8')})
        p = OUT/'source'/rel
        p.parent.mkdir(exist_ok=True, parents=True)
        p.write_bytes(new)
    bundle = json.dumps({'reference_commit':BASE,'files':entries},ensure_ascii=True,separators=(',',':')).encode()
    transport = base64.b64encode(zlib.compress(bundle,9))
    manifest = json.dumps({'schema':1,'base_commit':BASE,'bundles':[{'name':'n00-native43','transport_sha256':digest(transport),'decoded_sha256':digest(bundle)}]},separators=(',',':')).encode()
    (OUT/'bundle.json').write_bytes(bundle)
    (OUT/'patch-manifest.json').write_bytes(manifest)
    (OUT/'n00-native43.b64').write_bytes(transport)

    script = (ROOT/'context/full-build-baseline/windows-full-development.py').read_text()
    script = script.replace('d5a5763fbd85ab2d2c1a9f1734ce24a5083a739e',BASE)
    script = script.replace('dd762dde5a301bf972cc72794171ea3e3f0e04a3751ddaf833d0a0f003ed2066',SOURCE)
    insertion = '''        # Run exact original modules only in isolated regression interpreters.
        # The candidate checkout stays unchanged, including if a child times out.
        report['original_regressions']={}
        for case in ('quote','appearance','dossier'):
            run('original-'+case+'-regression',[py,pathlib.Path(os.environ['PATCH_DIR'])/'n00-red-regressions.py',root,state,case],180,env=env)
            report['original_regressions'][case]=json.loads((state/('original-'+case+'-result.json')).read_text(encoding='utf-8'))
        need(inventory(root,state)[0]==expected,'sources_changed_after_red_checks')
        persist()
'''
    anchor = '        checks=[("diff-check",["git","diff","--check"]),'
    assert script.count(anchor)==1
    script = script.replace(anchor,insertion+anchor)
    (OUT/'windows-full-development.py').write_text(script)
    workflow_path=ROOT/'admin-transport/.github/workflows/windows-development.yml'
    workflow=yaml.safe_load(workflow_path.read_text())
    workflow['name']='N00 repair native quote actions and large-font UI; verify candidate43'
    develop=workflow['jobs']['develop']
    develop['name']='Apply confirmed N00 repairs on the laptop and check candidate43'
    steps=[]
    staged=False
    for s in develop['steps']:
        if s.get('name','').startswith('Stage verified administrative transport:'):
            if not staged:
                red=red_script()
                (OUT/'n00-red-regressions.py').write_bytes(red)
                new_steps=[stage('windows-full-development.py',script.encode()),stage('n00-linux-guest.py',(ROOT/'context/full-build-baseline/n00-linux-guest.py').read_bytes()),stage('n00-red-regressions.py',red),stage('n00-native43.b64',transport),stage('patch-manifest.json',manifest)]
                new_steps[-1]['id']='setup'
                steps.extend(new_steps)
                staged=True
            continue
        if s.get('name')=='Checkout the exact base source with LF bytes':
            s['with']['ref']=BASE
        if s.get('uses','').startswith('actions/upload-artifact@'):
            s['with']['name']='n00-candidate43-build-checks'
            s['with']['path']='\n'.join(dict.fromkeys((s['with']['path']+'\n${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/*original*.log\n${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/original-*-result.json').splitlines()))
        steps.append(s)
    develop['steps']=steps
    assert staged
    text=yaml.safe_dump(workflow,allow_unicode=True,sort_keys=False,width=120)
    workflow_path.write_text(text)
    (OUT/'workflow.yml').write_text(text)
    (OUT/'manifest-summary.json').write_text(json.dumps({'base':BASE,'base_source_sha256':SOURCE,'files':[{k:v for k,v in row.items() if k!='content'} for row in entries],'workflow_sha256':digest(text.encode()),'bootstrap_sha256':digest(script.encode())},indent=2))
    print(json.dumps({'files':len(entries),'paths':[r['path'] for r in entries],'workflow_bytes':len(text.encode()),'bundle_sha256':digest(bundle),'bootstrap_sha256':digest(script.encode())}))

if __name__=='__main__':
    prepare()
