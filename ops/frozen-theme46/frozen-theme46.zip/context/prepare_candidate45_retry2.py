"""Prepare candidate45 retry2: only the reviewed navigation caller-limit repair.

This administrative renderer writes context artifacts. It does not apply source,
invoke application/tests, dispatch a workflow, publish or connect to the laptop.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

import yaml

CONTEXT = Path(__file__).resolve().parent
BASE = '1cc05586b6874bfdd0cdb80131d178de9f95870c'
BASE_SOURCE = 'e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9'
ORIGINAL_GENERATOR_SHA = '69bfb8dbefd2cb3ce7bbf03dbd3bbbaf90c66b8b6fb5d38873a6f27e878ecf9a'
RETRY1_GENERATOR_SHA = 'ddb92883db045364945e3c7af48184b4c57f40d091e20ca4bcc18ae3a1d1659e'
RETRY1 = CONTEXT / 'candidate45-retry1-bound'
RETRY1_PINS = {
    'reviewed-files.json': '0a52b20c3374bd78291f847983eca5186a4745f8985cbb0301c8e165d6f450ee',
    'bundle.json': '6a74416270fe4fa8a7c36226dc1c34f98bbe4c40324c8fe08c048c6a8d39a08d',
    'n00-native45.b64': '23f729e64ad2e6cab7b8d182ac06582c99741bfa35559857b4e4847991f438c2',
    'patch-manifest.json': 'fe2ec9662ea99e9b0a63112ba5184b0d659c0ed4bb96e4e1964cbe1d7d9b15a2',
    'windows-full-development.py': '9e4b061008d9596d5a104ea35e080405a3a569508b3f51b9fc7fb802d7adb3fc',
    'n00-linux-guest.py': '9c92c16d88a9e69a6e9b73b61f0e1eff8cd6b1b457451ee104c07bd17a7e29f0',
    'workflow.yml': '74301476c25f46a872ee50f23eb3361bfb7d63bffd953a7158b286d08932092b',
}
REPAIR = CONTEXT / 'navigation45-limit-repair'
REPAIR_MANIFEST_SHA = '8f2004b2f33a349a03fea21e32c38df4d17113016c93c9d25eeab3035c4724bc'
REPAIR_PATCH_SHA = '064a6bd73484e5907cd61f5b1f443f88d81e2348ff515503f58c7ef273d30a5d'
HELPER = '.github/scripts/navigation_detail_probe.py'
TEST = '.github/scripts/tests/test_navigation_detail_probe.py'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None, maximum=8 * 1024**2):
    need(path.is_absolute() and CONTEXT in path.parents and path.resolve(strict=True) == path
         and not path.is_symlink(), 'Canonical context file required')
    before = path.stat()
    need(path.is_file() and before.st_nlink == 1 and 0 < before.st_size <= maximum, 'Invalid context file')
    raw = path.read_bytes()
    after = path.stat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Context file changed while reading')
    need(expected is None or sha(raw) == expected, 'Reviewed context identity changed: ' + path.name)
    return raw


def workflow_from_proven(helper, bootstrap, guest, transport, manifest, name):
    value = yaml.safe_load(helper.workflow(BASE, bootstrap, guest, transport, manifest))
    need(value['jobs']['develop']['name'] ==
         'Apply twenty-three reviewed candidate45 files on the laptop and perform the full build', 'Proven workflow label changed')
    value['jobs']['develop']['name'] = 'Apply twenty-four reviewed candidate45 files on the laptop and perform the full build'
    value['name'] = name
    return yaml.safe_dump(value, allow_unicode=True, sort_keys=False, width=120).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    destination = args.output.absolute()
    need(CONTEXT in destination.parents and not destination.exists()
         and destination.parent.resolve(strict=True) == destination.parent, 'New context output required')
    original_path = CONTEXT / 'prepare_candidate45.py'
    read(original_path, ORIGINAL_GENERATOR_SHA)
    ast.parse(read(CONTEXT / 'prepare_candidate45_retry.py', RETRY1_GENERATOR_SHA))
    spec = importlib.util.spec_from_file_location('reviewed_administrative45_retry2', original_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)  # Hash-pinned administrative definitions, never application code.
    helper.verify_transport_source()
    _, previous44_rows = helper.reviewed_files()
    prior = {name: read(RETRY1 / name, digest) for name, digest in RETRY1_PINS.items()}
    prior_review = json.loads(prior['reviewed-files.json'])
    prior_rows = prior_review['files']
    need(prior_review['confirmed_base44_backup_commit'] == BASE
         and prior_review['base44_code_inventory_sha256'] == BASE_SOURCE
         and prior_review['version_after'] == {'code': 45, 'name': '0.13.7'}
         and len(prior_rows) == 24, 'Unexpected retry1 base/version/source scope')
    need(prior['bundle.json'] == helper.json_bytes({'reference_commit': BASE, 'files': prior_rows}, compact=True),
         'Retry1 bundle differs from its complete reviewed source')
    need(zlib.decompress(base64.b64decode(prior['n00-native45.b64'], validate=True)) == prior['bundle.json'],
         'Retry1 staged transport differs from its reviewed bundle')
    bootstrap = helper.bootstrap(BASE, BASE_SOURCE)
    guest = helper.read_pinned(CONTEXT / 'full-build-baseline/n00-linux-guest.py', helper.BASELINE_GUEST_SHA256)
    need(bootstrap == prior['windows-full-development.py'] and guest == prior['n00-linux-guest.py'],
         'Proven bootstrap/guest bytes changed')
    need(workflow_from_proven(helper, bootstrap, guest, prior['n00-native45.b64'], prior['patch-manifest.json'],
                             'Side and bottom panels; candidate45 source-contract repair') == prior['workflow.yml'],
         'Retry1 workflow is not the proven unchanged build/export transport')
    inventory_path = CONTEXT / 'candidate44-original-evidence/source-final.json'
    inventory_raw, inventory_summary = helper.verify_base_inventory(inventory_path, BASE_SOURCE, prior_rows, previous44_rows)
    repair = json.loads(read(REPAIR / 'manifest.json', REPAIR_MANIFEST_SHA))
    patch = read(REPAIR / 'candidate.patch', REPAIR_PATCH_SHA)
    need(repair['base_reviewed_files_sha256'] == RETRY1_PINS['reviewed-files.json']
         and repair['base_source_commit'] == BASE and repair['source_file_count'] == 2
         and repair['application_or_test_execution'] is False and repair['guard_weakened'] is False
         and {row['path'] for row in repair['source_files']} == {HELPER, TEST}, 'Unexpected approved repair scope')
    rows = copy.deepcopy(prior_rows)
    indexed = {row['path']: row for row in rows}
    need(len(indexed) == 24, 'Duplicate retry1 source paths')
    for item in repair['source_files']:
        row = indexed[item['path']]
        before = row['content'].encode()
        need(len(before) == row['new_bytes'] == item['old_bytes'] and sha(before) == row['new_sha256'] == item['old_sha256']
             and helper.git_blob(before) == item['old_git_blob'], 'Repair old candidate bytes differ')
        need(read(RETRY1 / 'source' / item['path']) == before, 'Retry1 source copy differs from its manifest')
        after = read(REPAIR / 'source' / item['path'], item['new_sha256'])
        need(len(after) == item['new_bytes'] and helper.git_blob(after) == item['new_git_blob'], 'Repair new bytes differ')
        ast.parse(after)
        if item['path'] == HELPER:
            need(before.count(b'max_swipes=24') == 4
                 and after == before.replace(b'max_swipes=24', b'max_swipes=20'), 'Caller repair widened beyond four exact limits')
        row.update(content=after.decode('utf-8'), new_bytes=len(after), new_sha256=sha(after))
    for old, new in zip(prior_rows, rows):
        need(old['path'] == new['path'] and all(old[key] == new[key] for key in
             ('path', 'old_git_blob', 'old_sha256', 'old_bytes')), 'Original base44 source identities changed')
        if old['path'] not in {HELPER, TEST}:
            need(old == new and read(RETRY1 / 'source' / old['path']) == old['content'].encode(), 'Unrelated source changed')
    need(len(rows) == 24 and sum(row['old_git_blob'] is None for row in rows) == 6, 'Retry2 source scope changed')
    need(indexed['.github/scripts/profile_scroll.py']['new_sha256'] == repair['shared_guard_unchanged_sha256'],
         'Shared scroll guard changed')
    helper.verify_base_inventory(inventory_path, BASE_SOURCE, rows, previous44_rows)
    review = {
        'schema': 1, 'kind': 'reviewed_candidate45_retry2_before_native_gate',
        'version_before': {'code': 44, 'name': '0.13.6'}, 'version_after': {'code': 45, 'name': '0.13.7'},
        'confirmed_base44_backup_commit': BASE, 'base44_source_inventory_sha256': sha(inventory_raw),
        'base44_code_inventory_sha256': BASE_SOURCE, 'prior_reviewed_files_sha256': RETRY1_PINS['reviewed-files.json'],
        'prior_full_build': {'run_id': 40292076024, 'conclusion_reported_by_parent': 'success', 'jobs_reported_by_parent': 5},
        'repair_evidence': {'kind': 'statically_proven_caller_guard_mismatch', 'previous_limit': 24, 'admitted_limit': 20,
                            'call_sites': 4, 'new_actual_boundary_regressions': 3,
                            'manifest_sha256': REPAIR_MANIFEST_SHA, 'patch_sha256': REPAIR_PATCH_SHA,
                            'native45_execution_claimed': False},
        'repair_paths': [HELPER, TEST], 'source_file_count': 24, 'existing_files': 18, 'new_files': 6, 'files': rows,
    }
    review_raw = helper.json_bytes(review)
    bundle = helper.json_bytes({'reference_commit': BASE, 'files': rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = helper.json_bytes({'schema': 1, 'base_commit': BASE, 'bundles': [{'name': 'n00-native45',
        'transport_sha256': sha(transport), 'decoded_sha256': sha(bundle)}]}, compact=True)
    workflow_raw = workflow_from_proven(helper, bootstrap, guest, transport, manifest,
                                       'Side and bottom panels; candidate45 native caller-limit repair')
    old_workflow, new_workflow = map(yaml.safe_load, (prior['workflow.yml'], workflow_raw))
    adjusted = copy.deepcopy(new_workflow)
    adjusted['name'] = old_workflow['name']
    changed_steps = []
    for index, (old, new) in enumerate(zip(old_workflow['jobs']['develop']['steps'], adjusted['jobs']['develop']['steps'])):
        if old != new:
            need(index in {5, 6} and set(old) == set(new) and set(old) - {'run'} == set(new) - {'run'}
                 and all(old[key] == new[key] for key in old if key != 'run'), 'Unexpected workflow step mutation')
            new['run'] = old['run']
            changed_steps.append(index)
    need(changed_steps == [5, 6] and adjusted == old_workflow, 'Workflow changed beyond name and staged source/manifest bytes')
    summary = {
        'state': 'prepared_only_no_application_or_test_execution', 'base_commit': BASE, 'base_source_sha256': BASE_SOURCE,
        'base44_inventory': inventory_summary, 'reviewed_files_sha256': sha(review_raw),
        'bootstrap_sha256': sha(bootstrap), 'guest_sha256': sha(guest), 'patch_manifest_sha256': sha(manifest),
        'workflow_sha256': sha(workflow_raw), 'bundle_sha256': sha(bundle), 'transport_sha256': sha(transport),
        'source_paths': 24, 'new_source_paths': 6, 'unchanged_retry1_rows': 22,
        'prior_reviewed_files_sha256': RETRY1_PINS['reviewed-files.json'],
        'approved_repair_manifest_sha256': REPAIR_MANIFEST_SHA, 'approved_repair_patch_sha256': REPAIR_PATCH_SHA,
        'repairs': [HELPER, TEST], 'proven_bootstrap_guest_unchanged': True,
        'workflow_change_scope': ['name', 'jobs.develop.steps[5].run', 'jobs.develop.steps[6].run'],
        'source_applied_on_windows': False, 'build_passed': False, 'runtime_passed': False,
        'phone_verified': False, 'publication_performed': False, 'n00_complete': False,
    }
    outputs = {'reviewed-files.json': review_raw, 'bundle.json': bundle, 'n00-native45.b64': transport,
        'patch-manifest.json': manifest, 'windows-full-development.py': bootstrap, 'n00-linux-guest.py': guest,
        'workflow.yml': workflow_raw, 'manifest-summary.json': helper.json_bytes(summary), 'repair.patch': patch}
    destination.mkdir()
    for name, raw in outputs.items():
        with (destination / name).open('xb') as stream:
            stream.write(raw)
    for row in rows:
        path = destination / 'source' / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(row['content'].encode())
    print(json.dumps(summary, sort_keys=True))


if __name__ == '__main__':
    main()
