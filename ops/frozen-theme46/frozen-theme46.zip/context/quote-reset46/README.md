# Candidate46: keep candle controls visible after Reset

This is a one-file product proposal, prepared after the actual44 native failure.
It has not been compiled, applied or executed. The frozen23-file candidate45,
the original portfolio probe and all its exact assertions remain unchanged.

## Observed evidence

Actual run40287655859 /API37 /16384 passed all seven font100 cases, then
discovery, dossier, history-ready and history-partial at font200. The twelfth
case, quotes/ready at font200, failed in the second `_first_candle` call at
`p.tap("Следующая", AREA)`. Markets and Appearance at font200 were not reached.
The neutral summary retains incomplete status because the complete original14
report was never returned; eleven individual CASE_PASSED log records do not
constitute complete acceptance.

The candidate44 Library return/search repair already passed in the font200
discovery case. This failure is in InstrumentQuotesPanel, not the library.

The failure XML shows actual320x640 portrait geometry, font2.0, density1.0,
owned window60 and a workspace viewport `[56,198][320,508]`. The synthetic
transcript records six requests and zero contract errors; the Hour query was
successful. The last actual Reset tap was `[94,386][248,453]`. The following
Next search performed two successful scroll-end actions, then eight end actions
returning false. The final XML and PNG show the bottom Save Research / Refresh
Quotes controls. There was no Next tap.

All original evidence paths and hashes are recorded in manifest.json, including
the failure XML, PNG and runtime log. The original evidence archive is
context/candidate44-native-original14.zip, SHA256
16e4e8c9bd3f28d8e4faa6f8a36933674f19d68b6f7c264c116350fde8ba1202.

## Code-backed inference and its limit

The production screen preserves selectedTime across the Day→Week→Month→Hour
requests. The prior final Day timestamp selects an actual Hour candle. Reset
then clears selectedTime, removing the tall CandleDetails block above the
unchanged controls; at font200 the exact long OHLC values use the stacked DataRow
layout. The same LazyColumn item retains its scroll position while its content
shrinks. This explains why adjacent controls can move above the current viewport
and an end-only search cannot find Next. The first Day `_first_candle` already
passed at font200, where Reset began with no existing selection.

The archive contains no immediate before/after Reset XML pair, so the exact
post-reset Next rectangle is an inference from the code and observed sequence,
not a measured coordinate. A dedicated observer may capture that pair with the
unchanged44 APK if needed. The proposed46 implementation must be confirmed by
actual native evidence and the unchanged original14 gate.

## Narrow product change

InstrumentQuotesPanel associates a BringIntoViewRequester with the existing
Previous / Reset / Next FlowRow. Only an explicit Reset of an actual selected
candle increments its request. The FlowRow's placement callback acknowledges
the same rendered request after the selected-details layout has changed. A
composition-scoped effect then asks the scrollable parent to keep that real
control group visible. Selection changes or page disposal cancel a pending
effect. No fixed sleep, retap, artificial large placeholder, new bar, forced
selection or altered OHLC text is introduced.

The official Compose API requests that scrollable parents bring the associated
component into view and suspends until completion or interruption:
https://developer.android.com/reference/kotlin/androidx/compose/foundation/relocation/BringIntoViewRequester
The repository already uses that same API for focused native editor visibility.

Labels, order, 48dp targets, quote requests, selectedTime semantics, table,
magnifier and financial values are unchanged. The original `_first_candle`
function and its strict source checks remain byte-for-byte the tested43/44
version. Core46's colors do not touch this file; the extension is kept separate
for the parent to merge after actual45 source backup.

## Required validation

Use the unchanged native quotes/font200 failure as the regression, then the
complete original14 and full4096/16384 matrix. Native evidence must show the
post-reset control geometry, exactly one actual Next tap, exact first OHLC,
the Hour magnifier/native table and the eventual period-to-Assistant checks.
Font100 must still pass. A source-only or callback-only test cannot substitute
for that viewport observation. Windows Kotlin/JVM/lint/build remain mandatory;
none were executed here.
