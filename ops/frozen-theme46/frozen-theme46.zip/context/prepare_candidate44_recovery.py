"""Prepare a read-only archive recovery and fixed Windows path-stat workflow.

Only reads/writes administrative preparation files under context. It does not
contact a server, invoke GitHub, execute the payload, or run application/tests.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'context/candidate44-recovery'
TARGET = '.github/workflows/windows-n00-build44-original-evidence.yml'
PIN = 'cd1866ee944ccea2259669f4293379241fd4ee02'
UPLOAD = 'actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9'
PINS = {
    'context/delivery43/workflow.yml': '7d7b68bba9be045fab274951b8624cac69ab583aee773a117807435f92e1b7ff',
    'context/delivery43/hosted-delivery.py': '67cbb8e1d9c3cadfdf76ea13cee2635a1c5b69defa029903b792b59b4f6f3dd0',
    'context/candidate44-build-evidence/windows-development.json': '808a43afb0585b3cf2cd9519d54c525f51be4d66fa239e3d9c4c4257d2eafd40',
    'context/candidate44-build-evidence/export-receipt.json': 'aea3b2586adf4f62304bb66495e154c0c015b45ebbaed7dca6f04157f7ef6c43',
    'context/candidate44-build-evidence/controller.json': '3e752a8d71d73956901af62cbca2382c60f2e99c8387656c7efcda02df3d7b43',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def render():
    assert __debug__
    for relative, expected in PINS.items():
        assert sha((ROOT / relative).read_bytes()) == expected, relative
    build = json.loads((ROOT / 'context/candidate44-build-evidence/windows-development.json').read_bytes())
    receipt = json.loads((ROOT / 'context/candidate44-build-evidence/export-receipt.json').read_bytes())
    controller = json.loads((ROOT / 'context/candidate44-build-evidence/controller.json').read_bytes())
    assert build['github']['run_id'] == 40282775349 and build['github']['run_attempt'] == 1
    assert build['status'] == 'passed_check_and_build_only'
    assert build['check']['status'] == build['build']['status'] == 'passed'
    assert build['source_sha256'] == build['source_sha256_after'] == receipt['source_sha256'] == 'e34b717fa408fbe377d910a372933c35a2ba1bdddf02263b6daa477df70f93b9'
    assert build['complete_source_sha256'] == build['complete_source_sha256_after'] == receipt['complete_source_sha256'] == '69c10c8d65c0559b58d45231390cd0e84dc681df3f7dbaed3d0a5ee716c20fe6'
    assert receipt['bytes'] == 68927139 and receipt['sha256'] == 'f8dd107e1714fcc1a3aeed4afd25b6d9efa3dca878b7106191f3fd77e4fa1b89' and receipt['files'] == 1045
    assert controller['worker_exit_code'] == controller['owned_processes_after'] == 0 and not controller.get('error') and not controller.get('cleanup_error')
    source = (ROOT / 'context/delivery43/hosted-delivery.py').read_text()
    function = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == 'with_ams')
    prefix = ''.join(source.splitlines(keepends=True)[:function.end_lineno]) + '\n\n'
    assert sha(prefix.encode()) == 'ca6db9c15a6aa2a42ebdaf3f03b6fa0b47b314415adb75d3466daf44fa8e2b84'
    remote = (OUT / 'recover-original-evidence.py').read_text()
    receiver = (OUT / 'hosted-receive.py').read_text()
    windows = (OUT / 'windows-path-stat.py').read_text()
    for payload in (remote, receiver, windows):
        ast.parse(payload)
    hosted = prefix + 'REMOTE_SHA256 = ' + repr(sha(remote.encode())) + '\nremote = ' + repr(remote) + '\n' + receiver
    ast.parse(hosted)
    original = yaml.safe_load((ROOT / 'context/delivery43/workflow.yml').read_text())
    checkout = original['jobs']['deliver']['steps'][0]
    assert checkout['with']['ref'] == PIN and checkout['with']['persist-credentials'] is False
    condition = ("github.repository == 'MishaGameHacking/omni-cio-gateway' && "
                 "github.ref == 'refs/heads/codex/timeweb-owner-prepare-2026-10-23' && github.event_name == 'push'")
    workflow = {
        'name': 'Recover original build44 metadata and observe fixed Windows paths',
        'on': {'push': {'branches': ['codex/timeweb-owner-prepare-2026-10-23'], 'paths': [TARGET]}},
        'permissions': {'contents': 'read'},
        'concurrency': {'group': 'build44-original-evidence-readonly', 'cancel-in-progress': False},
        'jobs': {
            'recover': {
                'if': condition, 'runs-on': 'ubuntu-24.04', 'timeout-minutes': 12,
                'steps': [checkout, {
                    'name': 'Read only exact9417611 archive and recover original metadata bytes',
                    'env': {'TIMEWEB_CLOUD_TOKEN': '${{ secrets.TIMEWEB_CLOUD_TOKEN }}', 'PYTHONUNBUFFERED': '1'},
                    'run': "python3 - <<'PY'\n" + hosted + '\nPY\n',
                }, {
                    'name': 'Preserve verified original inventory and available JVM XML', 'if': 'always()', 'uses': UPLOAD,
                    'with': {'name': 'build44-original-evidence-${{ github.run_id }}-${{ github.run_attempt }}',
                             'path': '${{ runner.temp }}/n00-build44-recovery-${{ github.run_id }}-${{ github.run_attempt }}/',
                             'if-no-files-found': 'warn', 'retention-days': 3},
                }],
            },
            'windows_path_stat': {
                'if': condition, 'runs-on': ['self-hosted', 'Windows', 'X64', 'omni-cio-ci'], 'timeout-minutes': 3,
                'steps': [{
                    'name': 'Observe only fixed retained source and former temp state paths',
                    'shell': 'py -3 {0}',
                    'env': {'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONUNBUFFERED': '1'},
                    'run': windows,
                }, {
                    'name': 'Preserve fixed path existence and stat observations', 'if': 'always()', 'uses': UPLOAD,
                    'with': {'name': 'build44-fixed-path-stat-${{ github.run_id }}-${{ github.run_attempt }}',
                             'path': '${{ runner.temp }}/n00-build44-path-stat-${{ github.run_id }}-${{ github.run_attempt }}/fixed-build44-path-stat.json',
                             'if-no-files-found': 'warn', 'retention-days': 3},
                }],
            },
        },
    }
    rendered = yaml.safe_dump(workflow, allow_unicode=True, sort_keys=False, width=120)
    assert yaml.safe_load(rendered) == workflow
    (OUT / 'hosted-recovery.py').write_text(hosted)
    (OUT / 'workflow.yml').write_text(rendered)
    names = ('recover-original-evidence.py', 'hosted-receive.py', 'hosted-recovery.py', 'windows-path-stat.py', 'workflow.yml')
    preparation = {
        'schema': 1, 'target_workflow': TARGET, 'preparation_only': True,
        'remote_payload_executed': False, 'application_or_tests_executed': False,
        'github_write_performed': False, 'server_or_device_mutation_performed': False,
        'pinned_administrative_checkout': PIN, 'proven_transport_prefix_sha256': sha(prefix.encode()),
        'server': {'id': 9417611, 'name': 'Analyst AI runtime 20261025', 'ipv4': '83.217.195.29',
                   'project_id': 2941515, 'availability_zone': 'ams-1'},
        'transport_boundary': 'Unchanged pinned transport temporarily attaches its SSH key and removes it in finally; the remote recovery payload is file-read-only.',
        'input_pins': PINS, 'original_inventory_bytes_reconstructed': False,
        'archive_bytes': receipt['bytes'], 'archive_sha256': receipt['sha256'],
        'source_sha256': receipt['source_sha256'], 'complete_source_sha256': receipt['complete_source_sha256'],
        'junit_policy': 'Aggregate exact archived XML; export raw originals only when no properties, failure/error/skipped nodes or nonempty diagnostic streams occur. Missing or malformed XML is reported separately and cannot fabricate a count.',
        'output_scope': 'Original inventories, pinned report/controller, original metadata envelope, bounded available JVM XML and derived evidence receipts only; no source contents, APK, database, AVD, device or credentials.',
        'windows_scope': 'lstat on seven exact build44 paths, no directory enumeration/file contents/process commands/ADB; absence does not prove who cleaned a path.',
        'files': {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha((OUT / name).read_bytes())} for name in names},
    }
    (OUT / 'preparation.json').write_text(json.dumps(preparation, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'workflow': str(OUT / 'workflow.yml'), **preparation['files']['workflow.yml'],
                      'remote_payload_sha256': preparation['files']['recover-original-evidence.py']['sha256'],
                      'ast_only_payload_validation': True, 'payload_executed': False}))


if __name__ == '__main__':
    render()
