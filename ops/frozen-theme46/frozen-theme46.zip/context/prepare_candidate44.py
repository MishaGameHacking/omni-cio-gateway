"""Prepare the four reviewed candidate44 files for a future Windows build.

This administrative generator only reads reviewed inputs and writes a new
directory under context. It never edits a checkout, runs app/test code, contacts
a service, commits, pushes or dispatches a workflow.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import json
from pathlib import Path
import re
import zlib

import yaml


ROOT = Path(__file__).resolve().parents[1]
CONTEXT = ROOT / "context"
CANDIDATE = CONTEXT / "candidate44"
REFERENCE_COMMIT = "859c067198e52927df1b66983d02841e3fa6ff6a"
REVIEWED_FILES_SHA256 = "6a040de2507769095b162da1fab3d39e613e833dcc107b9edd149636d64ae6e5"
BASELINE_BOOTSTRAP_SHA256 = "986cebe48cf4d499aa71d12a491a595bfcaa279adf2cc191b38cd994636bf02d"
BASELINE_GUEST_SHA256 = "9c92c16d88a9e69a6e9b73b61f0e1eff8cd6b1b457451ee104c07bd17a7e29f0"
WORKFLOW_TEMPLATE_SHA256 = "f0e80b7fa64e98f01a090ed171111fccba184752d79950aa25ad0a3a830d0524"
REVIEWED_PATHS = frozenset({
    "app/src/main/java/ru/omnicio/app/ui/workspace/ResearchLibraryScreen.kt",
    "app/build.gradle.kts",
    ".github/scripts/tests/test_android17_live_spectrum.py",
    ".github/scripts/tests/test_spectrum_brand_identity.py",
})
ENTRY_KEYS = frozenset({
    "path", "old_git_blob", "old_sha256", "old_bytes", "new_sha256", "new_bytes", "content",
})


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value, *, compact=False):
    if compact:
        return json.dumps(value, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    return (json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode("utf-8")


def read_pinned(path, expected):
    need(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
         "reviewed input is not a canonical regular file: " + str(path))
    data = path.read_bytes()
    need(digest(data) == expected, "reviewed input changed: " + str(path))
    return data


def reviewed_files():
    raw = read_pinned(CANDIDATE / "reviewed-files.json", REVIEWED_FILES_SHA256)
    review = json.loads(raw)
    need(review.get("schema") == 1 and
         review.get("kind") == "reviewed_candidate44_sources_unbound_to_future_base" and
         review.get("source_reference_commit") == REFERENCE_COMMIT, "unexpected source review identity")
    rows = review.get("files")
    need(isinstance(rows, list) and len(rows) == 4, "exactly four reviewed files are required")
    seen = set()
    for row in rows:
        need(isinstance(row, dict) and set(row) == ENTRY_KEYS, "unexpected file entry")
        relative = row["path"]
        need(relative in REVIEWED_PATHS and relative not in seen, "unreviewed or repeated file path")
        seen.add(relative)
        need(isinstance(row["content"], str) and "\0" not in row["content"], "invalid source text")
        data = row["content"].encode("utf-8")
        need(type(row["new_bytes"]) is int and len(data) == row["new_bytes"] and
             digest(data) == row["new_sha256"], "reviewed candidate hash or size differs")
        need(re.fullmatch(r"[a-f0-9]{40}", row["old_git_blob"]) and
             re.fullmatch(r"[a-f0-9]{64}", row["old_sha256"]) and
             type(row["old_bytes"]) is int and row["old_bytes"] > 0, "invalid original file identity")
        need(row["old_sha256"] != row["new_sha256"], "unchanged candidate file")
        need(read_pinned(CANDIDATE / "source" / relative, row["new_sha256"]) == data,
             "source copy differs from reviewed manifest")
    need(seen == REVIEWED_PATHS, "reviewed path set differs")
    return rows


def bootstrap(base_commit, base_source):
    original = read_pinned(CONTEXT / "full-build-baseline/windows-full-development.py",
                           BASELINE_BOOTSTRAP_SHA256)
    replacements = (
        (b'BASE_COMMIT = "d5a5763fbd85ab2d2c1a9f1734ce24a5083a739e"',
         ('BASE_COMMIT = "' + base_commit + '"').encode("ascii")),
        (b'BASE_SOURCE = "dd762dde5a301bf972cc72794171ea3e3f0e04a3751ddaf833d0a0f003ed2066"',
         ('BASE_SOURCE = "' + base_source + '"').encode("ascii")),
    )
    result = original
    for old, new in replacements:
        need(result.count(old) == 1, "baseline identity assignment changed")
        result = result.replace(old, new, 1)
    # A reversible byte comparison proves that the existing workflow-mutation
    # guard, lease, OwnedJob, tests and full-build commands were not altered.
    restored = result
    for old, new in reversed(replacements):
        need(restored.count(new) == 1, "generated identity assignment is ambiguous")
        restored = restored.replace(new, old, 1)
    need(restored == original, "bootstrap changed beyond its two base constants")
    ast.parse(result.decode("utf-8"), filename="windows-full-development.py")
    return result


def stage(name, content):
    need(re.fullmatch(r"[a-z0-9_.-]+", name), "invalid staged transport name")
    encoded = base64.b64encode(zlib.compress(content, 9)).decode("ascii")
    lines = []
    for offset in range(0, len(encoded), 6000):
        mode = "w" if offset == 0 else "a"
        lines.append('py -3 -c "from pathlib import Path; import os; p=Path(os.environ[\'PATCH_DIR\'])/\'' +
                     name + '.b64\'; p.open(\'' + mode + '\',encoding=\'ascii\').write(\'' +
                     encoded[offset:offset + 6000] + '\')"')
        lines.append("if errorlevel 1 exit /b 1")
    lines.append('py -3 -c "from pathlib import Path; import os,zlib,base64,hashlib; p=Path(os.environ[\'PATCH_DIR\']); '
                 'b=zlib.decompress(base64.b64decode((p/\'' + name + '.b64\').read_text())); '
                 'assert hashlib.sha256(b).hexdigest()==\'' + digest(content) + '\'; '
                 '(p/\'' + name + '\').write_bytes(b)"')
    lines.append("if errorlevel 1 exit /b 1")
    return {"name": "Stage verified administrative transport: " + name,
            "shell": "cmd", "run": "\n".join(lines)}


def workflow(base_commit, script, guest, transport, manifest):
    raw = read_pinned(CONTEXT / "candidate43/workflow.yml", WORKFLOW_TEMPLATE_SHA256)
    original = yaml.safe_load(raw)
    result = copy.deepcopy(original)
    need(set(result["jobs"]) == {"preflight", "develop", "collect", "cleanup", "result"},
         "candidate43 administrative job graph changed")
    result["name"] = "N00 saved-research scroll repair; verify candidate44"
    develop = result["jobs"]["develop"]
    develop["name"] = "Apply four reviewed candidate44 files on the laptop and perform the full build"
    need(develop["timeout-minutes"] == 150, "unexpected previous outer job timeout")
    # Root reviewed this administrative nesting correction: the unchanged
    # 180-minute worker and 20-minute lease wait fit the existing 210-minute
    # work step, with time left for export/private return in the outer job.
    develop["timeout-minutes"] = 245
    new_steps = [stage("windows-full-development.py", script), stage("n00-linux-guest.py", guest),
                 stage("n00-native44.b64", transport), stage("patch-manifest.json", manifest)]
    new_steps[-1]["id"] = "setup"
    old_staged = []
    steps = []
    base_steps = work_steps = artifact_steps = 0
    for step in develop["steps"]:
        name = step.get("name", "")
        if name.startswith("Stage verified administrative transport: "):
            if not old_staged:
                steps.extend(new_steps)
            old_staged.append(name.removeprefix("Stage verified administrative transport: "))
            continue
        if name == "Checkout the exact base source with LF bytes":
            need(step["with"]["ref"] == "49d6a75da6aed643b66ef6807e2370fd7c896ff5",
                 "candidate43 source checkout changed")
            step["with"]["ref"] = base_commit
            base_steps += 1
        if step.get("id") == "work":
            need(step["timeout-minutes"] == 210, "existing work step timeout changed")
            work_steps += 1
        if step.get("uses", "").startswith("actions/upload-artifact@"):
            need(step["with"]["name"] == "n00-candidate43-build-checks", "unexpected evidence artifact")
            step["with"]["name"] = "n00-candidate44-build-checks"
            old_paths = step["with"]["path"].splitlines()
            red_only = {
                "${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/*original*.log",
                "${{ runner.temp }}/analyst-development-${{ github.run_id }}-${{ github.run_attempt }}/original-*-result.json",
            }
            need(red_only <= set(old_paths), "candidate43 RED evidence paths changed")
            step["with"]["path"] = "\n".join(path for path in old_paths if path not in red_only)
            artifact_steps += 1
        steps.append(step)
    need(old_staged == ["windows-full-development.py", "n00-linux-guest.py", "n00-red-regressions.py",
                        "n00-native43.b64", "patch-manifest.json"], "unexpected candidate43 staged transport")
    need(base_steps == work_steps == artifact_steps == 1, "required administrative steps changed")
    develop["steps"] = steps
    for job in ("preflight", "collect", "cleanup", "result"):
        need(result["jobs"][job] == original["jobs"][job], "private return infrastructure changed")
    for key in original.keys() - {"name", "jobs"}:
        need(result[key] == original[key], "administrative trigger or permissions changed")
    text = yaml.safe_dump(result, allow_unicode=True, sort_keys=False, width=120)
    need("n00-red-regressions" not in text and "n00-native43" not in text,
         "old candidate43 RED transport was retained")
    return text.encode("utf-8")


def prepare(args):
    need(re.fullmatch(r"[a-f0-9]{40}", args.base_commit), "exact backed-up base commit is required")
    need(re.fullmatch(r"[a-f0-9]{64}", args.base_source_sha256), "exact base source inventory is required")
    destination = args.output.absolute()
    need(CONTEXT in destination.parents and not destination.exists() and not destination.is_symlink(),
         "output must be a new directory under context")
    need(destination.parent.is_dir() and destination.parent.resolve(strict=True) == destination.parent,
         "output parent must already be a canonical directory")
    rows = reviewed_files()
    bundle = json_bytes({"reference_commit": args.base_commit, "files": rows}, compact=True)
    transport = base64.b64encode(zlib.compress(bundle, 9))
    manifest = json_bytes({"schema": 1, "base_commit": args.base_commit, "bundles": [{
        "name": "n00-native44", "transport_sha256": digest(transport), "decoded_sha256": digest(bundle),
    }]}, compact=True)
    script = bootstrap(args.base_commit, args.base_source_sha256)
    guest = read_pinned(CONTEXT / "full-build-baseline/n00-linux-guest.py", BASELINE_GUEST_SHA256)
    generated_workflow = workflow(args.base_commit, script, guest, transport, manifest)
    summary = {
        "state": "prepared_only_no_application_or_test_execution",
        "base_commit": args.base_commit, "base_source_sha256": args.base_source_sha256,
        "source_reference_commit": REFERENCE_COMMIT,
        "reviewed_files_sha256": REVIEWED_FILES_SHA256,
        "files": [{key: value for key, value in row.items() if key != "content"} for row in rows],
        "bundle_sha256": digest(bundle), "transport_sha256": digest(transport),
        "patch_manifest_sha256": digest(manifest), "bootstrap_sha256": digest(script),
        "linux_guest_sha256": digest(guest), "workflow_sha256": digest(generated_workflow),
        "baseline_bootstrap_sha256": BASELINE_BOOTSTRAP_SHA256,
        "workflow_template_sha256": WORKFLOW_TEMPLATE_SHA256,
        "bootstrap_changes": ["BASE_COMMIT", "BASE_SOURCE"],
        "administrative_timeout_change": {"job_before_minutes": 150, "job_after_minutes": 245,
                                          "work_step_minutes_unchanged": 210,
                                          "worker_seconds_unchanged": 10800,
                                          "shared_lease_wait_seconds_unchanged": 1200},
        "old_red_regression_transport_removed": True,
        "native_original14_probe_modified": False, "workflow_mutation_guard_modified": False,
        "source_applied_on_windows": False, "ordinary_ci_verified": False,
        "build_passed": False, "runtime_passed": False, "phone_verified": False,
        "publication_authorized": False, "n00_complete": False,
        "workflow_destination_for_later_review": ".github/workflows/windows-development.yml",
    }
    files = {"bundle.json": bundle, "n00-native44.b64": transport, "patch-manifest.json": manifest,
             "windows-full-development.py": script, "n00-linux-guest.py": guest,
             "workflow.yml": generated_workflow, "manifest-summary.json": json_bytes(summary)}
    files["NOT_ACCEPTANCE.md"] = (
        "# Candidate44 administrative preparation only\n\n"
        "These files have not been applied or executed. Root must verify that the supplied base commit "
        "and code inventory identify the exact new Windows-applied CI backup before dispatch.\n\n"
        "The application change separates saved-library and selected-detail scroll state. The other three "
        "files set version44 / 0.13.6 and preserve its existing strict version assertions. "
        "No UI probe, assertion, timeout, input target or acceptance count is changed.\n\n"
        "The generated bootstrap differs from the proven full-build baseline only in BASE_COMMIT and "
        "BASE_SOURCE. Its original workflow-mutation guard remains intact. The outer administrative "
        "job gets245 minutes; the work step210, worker180 and lease wait20 minutes stay unchanged.\n\n"
        "A Windows check/build success still requires separate unchanged original native validation. "
        "The observed43 font200 discovery failure is the real regression to re-run. Full native matrix, "
        "ordinary CI, external Sonar, physical-phone installation and N00 completion are not claimed.\n"
    ).encode("utf-8")
    destination.mkdir()
    for name, data in files.items():
        with (destination / name).open("xb") as output:
            output.write(data)
    print(json.dumps({"output": str(destination), "base_commit": args.base_commit,
                      "bundle_sha256": digest(bundle), "workflow_sha256": digest(generated_workflow),
                      "state": summary["state"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-commit", required=True)
    parser.add_argument("--base-source-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    prepare(parser.parse_args())


if __name__ == "__main__":
    main()
